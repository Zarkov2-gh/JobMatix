﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("JMxBackupAgent")> 
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("grh")>
<Assembly: AssemblyProduct("JMxBackupAgent")>
<Assembly: AssemblyCopyright("Copyright © 2018..2021 grhaas@outlook.com")>
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("31bbfca7-f59d-4570-bb8e-6fd7da1ed384")>

'==
'==  Background Scheduled task to backup JobMatix Database..
'==     -- Console Application 3501.0821 Started  21Aug2018=  ...
'==

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("6.2.6201.0805")>
'= <Assembly: AssemblyFileVersion("1.0.0.0")> 

'= = = = = = = = = == = = = = = = = = == =
