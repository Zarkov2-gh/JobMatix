﻿Public Class RetaiHost_Class1

    Public Sub New()

        MsgBox("New class1 entered.", MsgBoxStyle.Information)

    End Sub
End Class  '--class1-
'= = = = = = == =
