﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("JMxRetailHost620")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("grh")>
<Assembly: AssemblyProduct("JMxRetailHost")>
<Assembly: AssemblyCopyright("Copyright © 2014..2020, 2021 grhaas@outlook.com")>
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("a8ad2678-3257-4034-af00-03cf774492d5")>


'==
'==  NEW DLL- 4219 VERSION
'==    Created- 4219.1130 22-Nov-2019= 
'==      --  Move Retail Host Interfaces and classes to HERE in JMxRetailHost.dll..
'==      --  Make "modAllFileAndSqlSubs" Public HERE in JMxRetailHost.dll so EVERyONE can use it..
'==      --  move  module  "modBackupRestore35" as Public HERE into JMxRetailHost.dll so EVERyONE can use it..
'==      --  Move module "modCreateJobs3" and Attachments Form and class 
'==                        into HERE JMxRetailHost.dll so EVERyONE  (RAs) can use it.
'==      --  The Functions gsAssembly..." stuff to be private only, as users of this DLL have 
'==              make their own arrangements about assembly infos..
'==    Updated- 4219.1216 16-Dec-2019=  Fixes..
'==
'==  NEW Build 4221.0207  '- 07Feb2020.
'==        -- To Show Customer Tags on Main Form..
'==
'==
'==
'= = = = = = = = = = = = = = == =  = = = = = = = = = == = = = = = = = = == = =  = = = =

'= = = =  = = = = = = = = = = = = = = = = = = = = = = == = = = = = = = = = = == = = = == = = = = = = = = = = = = = 
'==
'==   Target-New-Build-6201 --  (16-June-2021)
'==   Target-New-Build-6201 --  (16-June-2021)
'==
'==  For JobMatix62Main- OPEN SOURCE version...
'==  For JobMatix62Main- OPEN SOURCE version...
'==
'= = = =  = = = = = = = = = = = = = = = = = = = = = = == = = = = = = = = = = == = = = == = = = = = = = = = = = = = 


' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("6.2.6201.0718")>
'= <Assembly: AssemblyFileVersion("1.0.0.0")> 
