<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ucChildStockAdmin
    Inherits System.Windows.Forms.UserControl  '= System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.grpBoxStock = New System.Windows.Forms.GroupBox()
        Me.panelItemHdr = New System.Windows.Forms.Panel()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.txtHdrBarcode = New System.Windows.Forms.TextBox()
        Me.labItemHeader = New System.Windows.Forms.Label()
        Me.btnPrintLabels = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtlabelCount = New System.Windows.Forms.TextBox()
        Me.frameBrowse = New System.Windows.Forms.GroupBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.cmdClearStockSearch = New System.Windows.Forms.Button()
        Me.cmdStockSearch = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtStockSearch = New System.Windows.Forms.TextBox()
        Me.dgvStockList = New System.Windows.Forms.DataGridView()
        Me.txtFind = New System.Windows.Forms.TextBox()
        Me.labRecCount = New System.Windows.Forms.Label()
        Me.LabFind = New System.Windows.Forms.Label()
        Me.panelBanner = New System.Windows.Forms.Panel()
        Me.panelRefence = New System.Windows.Forms.Panel()
        Me.btnNewBrand = New System.Windows.Forms.Button()
        Me.btnNewCat2 = New System.Windows.Forms.Button()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.btnNewCat1 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.labToday = New System.Windows.Forms.Label()
        Me.labStaffName = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tabControlStock = New System.Windows.Forms.TabControl()
        Me.TabPageItemDetail = New System.Windows.Forms.TabPage()
        Me.labItemAction = New System.Windows.Forms.Label()
        Me.panelStockItem = New System.Windows.Forms.Panel()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtSupplierCode = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.chkAutoBarcode = New System.Windows.Forms.CheckBox()
        Me.txtIsNonStockItem = New System.Windows.Forms.TextBox()
        Me.labQtyInStock = New System.Windows.Forms.Label()
        Me.chkIsNonStockItem = New System.Windows.Forms.CheckBox()
        Me.txtReOrderLevel = New System.Windows.Forms.TextBox()
        Me.chkTrackSerials = New System.Windows.Forms.CheckBox()
        Me.txtTrackSerials = New System.Windows.Forms.TextBox()
        Me.labInStockLab = New System.Windows.Forms.Label()
        Me.txtReOrderQty = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.labRates = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtCostIncTax = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtSellIncTax = New System.Windows.Forms.TextBox()
        Me.chkSalesTax = New System.Windows.Forms.CheckBox()
        Me.chkGoodsTax = New System.Windows.Forms.CheckBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.labRequiredFields = New System.Windows.Forms.Label()
        Me.txtInactive = New System.Windows.Forms.TextBox()
        Me.txtRenaming = New System.Windows.Forms.TextBox()
        Me.btnStockCancel = New System.Windows.Forms.Button()
        Me.btnStockCommit = New System.Windows.Forms.Button()
        Me.txtSupplierName = New System.Windows.Forms.TextBox()
        Me.txtBrandName = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtComments = New System.Windows.Forms.TextBox()
        Me.chkRenaming = New System.Windows.Forms.CheckBox()
        Me.txtSalesTaxcode = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtSellExTax = New System.Windows.Forms.TextBox()
        Me.txtGoodsTaxcode = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtCostExTax = New System.Windows.Forms.TextBox()
        Me.cboSupplier = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtSupplier_id = New System.Windows.Forms.TextBox()
        Me.cboBrand = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtBrand_id = New System.Windows.Forms.TextBox()
        Me.chkInactive = New System.Windows.Forms.CheckBox()
        Me.cboCat2 = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtCat2 = New System.Windows.Forms.TextBox()
        Me.cboCat1 = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtCat1 = New System.Windows.Forms.TextBox()
        Me.txtStock_id = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.picProduct = New System.Windows.Forms.PictureBox()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.BarcodeLabel = New System.Windows.Forms.Label()
        Me.DescriptionLabel = New System.Windows.Forms.Label()
        Me.txtBarcode = New System.Windows.Forms.TextBox()
        Me.btnNew = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.TabPageSerials = New System.Windows.Forms.TabPage()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.dgvSerials = New System.Windows.Forms.DataGridView()
        Me.SerialNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SerialStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Trans_History = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.labSerialsDescription = New System.Windows.Forms.Label()
        Me.labSerialsBarcode = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TabPagePurchases = New System.Windows.Forms.TabPage()
        Me.dgvGoods = New System.Windows.Forms.DataGridView()
        Me.Goods_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.goods_date = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.supplier = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.invoice_no = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.quantity = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.labGoodsDescription = New System.Windows.Forms.Label()
        Me.labGoodsBarcode = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TabPageSales = New System.Windows.Forms.TabPage()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.dgvSales = New System.Windows.Forms.DataGridView()
        Me.sale_invoice_no = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.invoice_date = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.invoice_trancode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.customer = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.sale_qty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.sale_value = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.labSalesDescription = New System.Windows.Forms.Label()
        Me.labSalesBarcode = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.openDlg1 = New System.Windows.Forms.OpenFileDialog()
        Me.timerGrid = New System.Windows.Forms.Timer(Me.components)
        Me.grpBoxStock.SuspendLayout()
        Me.panelItemHdr.SuspendLayout()
        Me.frameBrowse.SuspendLayout()
        CType(Me.dgvStockList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBanner.SuspendLayout()
        Me.panelRefence.SuspendLayout()
        Me.tabControlStock.SuspendLayout()
        Me.TabPageItemDetail.SuspendLayout()
        Me.panelStockItem.SuspendLayout()
        CType(Me.picProduct, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPageSerials.SuspendLayout()
        CType(Me.dgvSerials, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPagePurchases.SuspendLayout()
        CType(Me.dgvGoods, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPageSales.SuspendLayout()
        CType(Me.dgvSales, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grpBoxStock
        '
        Me.grpBoxStock.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.grpBoxStock.CausesValidation = False
        Me.grpBoxStock.Controls.Add(Me.panelItemHdr)
        Me.grpBoxStock.Controls.Add(Me.frameBrowse)
        Me.grpBoxStock.Controls.Add(Me.panelBanner)
        Me.grpBoxStock.Controls.Add(Me.tabControlStock)
        Me.grpBoxStock.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpBoxStock.Location = New System.Drawing.Point(1, -1)
        Me.grpBoxStock.Name = "grpBoxStock"
        Me.grpBoxStock.Size = New System.Drawing.Size(990, 627)
        Me.grpBoxStock.TabIndex = 0
        Me.grpBoxStock.TabStop = False
        Me.grpBoxStock.Text = "grpBoxStock"
        '
        'panelItemHdr
        '
        Me.panelItemHdr.BackColor = System.Drawing.Color.WhiteSmoke
        Me.panelItemHdr.CausesValidation = False
        Me.panelItemHdr.Controls.Add(Me.btnClose)
        Me.panelItemHdr.Controls.Add(Me.txtHdrBarcode)
        Me.panelItemHdr.Controls.Add(Me.labItemHeader)
        Me.panelItemHdr.Controls.Add(Me.btnPrintLabels)
        Me.panelItemHdr.Controls.Add(Me.Label14)
        Me.panelItemHdr.Controls.Add(Me.Label27)
        Me.panelItemHdr.Controls.Add(Me.txtlabelCount)
        Me.panelItemHdr.Location = New System.Drawing.Point(444, 7)
        Me.panelItemHdr.Name = "panelItemHdr"
        Me.panelItemHdr.Size = New System.Drawing.Size(541, 53)
        Me.panelItemHdr.TabIndex = 28
        Me.panelItemHdr.TabStop = True
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.Lavender
        Me.btnClose.Location = New System.Drawing.Point(476, 13)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(54, 29)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "Close X"
        Me.ToolTip1.SetToolTip(Me.btnClose, "Close form and Exit")
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'txtHdrBarcode
        '
        Me.txtHdrBarcode.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtHdrBarcode.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtHdrBarcode.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHdrBarcode.Location = New System.Drawing.Point(85, 7)
        Me.txtHdrBarcode.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtHdrBarcode.MaxLength = 15
        Me.txtHdrBarcode.Name = "txtHdrBarcode"
        Me.txtHdrBarcode.ReadOnly = True
        Me.txtHdrBarcode.Size = New System.Drawing.Size(221, 19)
        Me.txtHdrBarcode.TabIndex = 0
        Me.txtHdrBarcode.Text = "txtHdrBarcode"
        '
        'labItemHeader
        '
        Me.labItemHeader.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labItemHeader.Location = New System.Drawing.Point(82, 26)
        Me.labItemHeader.Name = "labItemHeader"
        Me.labItemHeader.Size = New System.Drawing.Size(302, 15)
        Me.labItemHeader.TabIndex = 22
        Me.labItemHeader.Text = "labItemHeader"
        '
        'btnPrintLabels
        '
        Me.btnPrintLabels.Font = New System.Drawing.Font("Comic Sans MS", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPrintLabels.Location = New System.Drawing.Point(430, 15)
        Me.btnPrintLabels.Name = "btnPrintLabels"
        Me.btnPrintLabels.Size = New System.Drawing.Size(34, 22)
        Me.btnPrintLabels.TabIndex = 1
        Me.btnPrintLabels.Text = ">>"
        Me.btnPrintLabels.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(5, 7)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(71, 32)
        Me.Label14.TabIndex = 23
        Me.Label14.Text = "Barcode: " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Description:"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label27
        '
        Me.Label27.Location = New System.Drawing.Point(387, 10)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(37, 31)
        Me.Label27.TabIndex = 26
        Me.Label27.Text = "Print Labels"
        '
        'txtlabelCount
        '
        Me.txtlabelCount.BackColor = System.Drawing.Color.AliceBlue
        Me.txtlabelCount.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtlabelCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlabelCount.Location = New System.Drawing.Point(413, 25)
        Me.txtlabelCount.Name = "txtlabelCount"
        Me.txtlabelCount.Size = New System.Drawing.Size(31, 13)
        Me.txtlabelCount.TabIndex = 25
        Me.txtlabelCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'frameBrowse
        '
        Me.frameBrowse.BackColor = System.Drawing.Color.White
        Me.frameBrowse.CausesValidation = False
        Me.frameBrowse.Controls.Add(Me.Label22)
        Me.frameBrowse.Controls.Add(Me.Label21)
        Me.frameBrowse.Controls.Add(Me.cmdClearStockSearch)
        Me.frameBrowse.Controls.Add(Me.cmdStockSearch)
        Me.frameBrowse.Controls.Add(Me.Label3)
        Me.frameBrowse.Controls.Add(Me.txtStockSearch)
        Me.frameBrowse.Controls.Add(Me.dgvStockList)
        Me.frameBrowse.Controls.Add(Me.txtFind)
        Me.frameBrowse.Controls.Add(Me.labRecCount)
        Me.frameBrowse.Controls.Add(Me.LabFind)
        Me.frameBrowse.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frameBrowse.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frameBrowse.Location = New System.Drawing.Point(5, 64)
        Me.frameBrowse.Name = "frameBrowse"
        Me.frameBrowse.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frameBrowse.Size = New System.Drawing.Size(440, 544)
        Me.frameBrowse.TabIndex = 21
        Me.frameBrowse.TabStop = False
        Me.frameBrowse.Text = "FrameBrowse"
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label22.Font = New System.Drawing.Font("Tahoma", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label22.Location = New System.Drawing.Point(256, 14)
        Me.Label22.Name = "Label22"
        Me.Label22.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label22.Size = New System.Drawing.Size(83, 15)
        Me.Label22.TabIndex = 82
        Me.Label22.Text = "Records found."
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(173, 40)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(121, 12)
        Me.Label21.TabIndex = 81
        Me.Label21.Text = "Full Text Filter (Srch):"
        '
        'cmdClearStockSearch
        '
        Me.cmdClearStockSearch.BackColor = System.Drawing.Color.LavenderBlush
        Me.cmdClearStockSearch.CausesValidation = False
        Me.cmdClearStockSearch.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClearStockSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdClearStockSearch.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClearStockSearch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClearStockSearch.Location = New System.Drawing.Point(375, 25)
        Me.cmdClearStockSearch.Name = "cmdClearStockSearch"
        Me.cmdClearStockSearch.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClearStockSearch.Size = New System.Drawing.Size(53, 23)
        Me.cmdClearStockSearch.TabIndex = 80
        Me.cmdClearStockSearch.Text = "Clear"
        Me.ToolTip1.SetToolTip(Me.cmdClearStockSearch, "Clear Search Text and refresh grid..")
        Me.cmdClearStockSearch.UseVisualStyleBackColor = False
        '
        'cmdStockSearch
        '
        Me.cmdStockSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.cmdStockSearch.CausesValidation = False
        Me.cmdStockSearch.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdStockSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdStockSearch.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdStockSearch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdStockSearch.Location = New System.Drawing.Point(375, 60)
        Me.cmdStockSearch.Name = "cmdStockSearch"
        Me.cmdStockSearch.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdStockSearch.Size = New System.Drawing.Size(53, 23)
        Me.cmdStockSearch.TabIndex = 79
        Me.cmdStockSearch.Text = "Search"
        Me.cmdStockSearch.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolTip1.SetToolTip(Me.cmdStockSearch, "Search/Refresh customer list.")
        Me.cmdStockSearch.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 20)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Stock List"
        '
        'txtStockSearch
        '
        Me.txtStockSearch.AcceptsReturn = True
        Me.txtStockSearch.BackColor = System.Drawing.Color.WhiteSmoke
        Me.txtStockSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStockSearch.CausesValidation = False
        Me.txtStockSearch.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtStockSearch.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStockSearch.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtStockSearch.Location = New System.Drawing.Point(167, 57)
        Me.txtStockSearch.MaxLength = 0
        Me.txtStockSearch.Name = "txtStockSearch"
        Me.txtStockSearch.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtStockSearch.Size = New System.Drawing.Size(195, 26)
        Me.txtStockSearch.TabIndex = 78
        Me.txtStockSearch.Text = "txtStockSearch"
        '
        'dgvStockList
        '
        Me.dgvStockList.AllowUserToAddRows = False
        Me.dgvStockList.AllowUserToDeleteRows = False
        Me.dgvStockList.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.dgvStockList.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvStockList.ColumnHeadersHeight = 18
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvStockList.DefaultCellStyle = DataGridViewCellStyle1
        Me.dgvStockList.GridColor = System.Drawing.SystemColors.ControlLight
        Me.dgvStockList.Location = New System.Drawing.Point(4, 89)
        Me.dgvStockList.MultiSelect = False
        Me.dgvStockList.Name = "dgvStockList"
        Me.dgvStockList.ReadOnly = True
        Me.dgvStockList.RowHeadersWidth = 17
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvStockList.RowsDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvStockList.RowTemplate.Height = 19
        Me.dgvStockList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvStockList.Size = New System.Drawing.Size(430, 390)
        Me.dgvStockList.StandardTab = True
        Me.dgvStockList.TabIndex = 4
        '
        'txtFind
        '
        Me.txtFind.AcceptsReturn = True
        Me.txtFind.BackColor = System.Drawing.Color.Gainsboro
        Me.txtFind.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtFind.CausesValidation = False
        Me.txtFind.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFind.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFind.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFind.Location = New System.Drawing.Point(6, 64)
        Me.txtFind.MaxLength = 0
        Me.txtFind.Name = "txtFind"
        Me.txtFind.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtFind.Size = New System.Drawing.Size(136, 19)
        Me.txtFind.TabIndex = 2
        '
        'labRecCount
        '
        Me.labRecCount.BackColor = System.Drawing.Color.Transparent
        Me.labRecCount.Cursor = System.Windows.Forms.Cursors.Default
        Me.labRecCount.Font = New System.Drawing.Font("Tahoma", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labRecCount.ForeColor = System.Drawing.SystemColors.ControlText
        Me.labRecCount.Location = New System.Drawing.Point(209, 13)
        Me.labRecCount.Name = "labRecCount"
        Me.labRecCount.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.labRecCount.Size = New System.Drawing.Size(44, 17)
        Me.labRecCount.TabIndex = 19
        Me.labRecCount.Text = "labRecCount"
        Me.labRecCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'LabFind
        '
        Me.LabFind.BackColor = System.Drawing.Color.LightGray
        Me.LabFind.Cursor = System.Windows.Forms.Cursors.Default
        Me.LabFind.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabFind.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LabFind.Location = New System.Drawing.Point(7, 37)
        Me.LabFind.Name = "LabFind"
        Me.LabFind.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LabFind.Size = New System.Drawing.Size(135, 25)
        Me.LabFind.TabIndex = 18
        Me.LabFind.Text = "LabFind"
        '
        'panelBanner
        '
        Me.panelBanner.BackColor = System.Drawing.Color.NavajoWhite
        Me.panelBanner.Controls.Add(Me.panelRefence)
        Me.panelBanner.Controls.Add(Me.Label5)
        Me.panelBanner.Controls.Add(Me.labToday)
        Me.panelBanner.Controls.Add(Me.labStaffName)
        Me.panelBanner.Controls.Add(Me.Label1)
        Me.panelBanner.Location = New System.Drawing.Point(4, 7)
        Me.panelBanner.Name = "panelBanner"
        Me.panelBanner.Size = New System.Drawing.Size(434, 54)
        Me.panelBanner.TabIndex = 21
        '
        'panelRefence
        '
        Me.panelRefence.Controls.Add(Me.btnNewBrand)
        Me.panelRefence.Controls.Add(Me.btnNewCat2)
        Me.panelRefence.Controls.Add(Me.Label31)
        Me.panelRefence.Controls.Add(Me.btnNewCat1)
        Me.panelRefence.Location = New System.Drawing.Point(209, 7)
        Me.panelRefence.Name = "panelRefence"
        Me.panelRefence.Size = New System.Drawing.Size(220, 42)
        Me.panelRefence.TabIndex = 8
        '
        'btnNewBrand
        '
        Me.btnNewBrand.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnNewBrand.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNewBrand.Location = New System.Drawing.Point(163, 9)
        Me.btnNewBrand.Name = "btnNewBrand"
        Me.btnNewBrand.Size = New System.Drawing.Size(46, 23)
        Me.btnNewBrand.TabIndex = 3
        Me.btnNewBrand.Text = "Brand"
        Me.ToolTip1.SetToolTip(Me.btnNewBrand, "Add new Stock Brand")
        Me.btnNewBrand.UseVisualStyleBackColor = False
        '
        'btnNewCat2
        '
        Me.btnNewCat2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnNewCat2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNewCat2.Location = New System.Drawing.Point(109, 9)
        Me.btnNewCat2.Name = "btnNewCat2"
        Me.btnNewCat2.Size = New System.Drawing.Size(45, 23)
        Me.btnNewCat2.TabIndex = 2
        Me.btnNewCat2.Text = "Cat2"
        Me.ToolTip1.SetToolTip(Me.btnNewCat2, "Add new Category2 value.")
        Me.btnNewCat2.UseVisualStyleBackColor = False
        '
        'Label31
        '
        Me.Label31.Font = New System.Drawing.Font("Tahoma", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label31.Location = New System.Drawing.Point(13, 14)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(38, 14)
        Me.Label31.TabIndex = 1
        Me.Label31.Text = "New-"
        '
        'btnNewCat1
        '
        Me.btnNewCat1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnNewCat1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNewCat1.Location = New System.Drawing.Point(57, 9)
        Me.btnNewCat1.Name = "btnNewCat1"
        Me.btnNewCat1.Size = New System.Drawing.Size(46, 23)
        Me.btnNewCat1.TabIndex = 0
        Me.btnNewCat1.Text = "Cat1"
        Me.ToolTip1.SetToolTip(Me.btnNewCat1, "Add new Category1 value.")
        Me.btnNewCat1.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(9, 5)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 42)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Stock Admin"
        '
        'labToday
        '
        Me.labToday.AutoSize = True
        Me.labToday.Location = New System.Drawing.Point(79, 10)
        Me.labToday.Name = "labToday"
        Me.labToday.Size = New System.Drawing.Size(51, 13)
        Me.labToday.TabIndex = 6
        Me.labToday.Text = "labToday"
        '
        'labStaffName
        '
        Me.labStaffName.Location = New System.Drawing.Point(119, 33)
        Me.labStaffName.Name = "labStaffName"
        Me.labStaffName.Size = New System.Drawing.Size(72, 13)
        Me.labStaffName.TabIndex = 5
        Me.labStaffName.Text = "labStaffName"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(79, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 14)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Staff: "
        '
        'tabControlStock
        '
        Me.tabControlStock.CausesValidation = False
        Me.tabControlStock.Controls.Add(Me.TabPageItemDetail)
        Me.tabControlStock.Controls.Add(Me.TabPageSerials)
        Me.tabControlStock.Controls.Add(Me.TabPagePurchases)
        Me.tabControlStock.Controls.Add(Me.TabPageSales)
        Me.tabControlStock.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabControlStock.Location = New System.Drawing.Point(447, 64)
        Me.tabControlStock.Name = "tabControlStock"
        Me.tabControlStock.SelectedIndex = 0
        Me.tabControlStock.Size = New System.Drawing.Size(537, 550)
        Me.tabControlStock.TabIndex = 3
        '
        'TabPageItemDetail
        '
        Me.TabPageItemDetail.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPageItemDetail.CausesValidation = False
        Me.TabPageItemDetail.Controls.Add(Me.labItemAction)
        Me.TabPageItemDetail.Controls.Add(Me.panelStockItem)
        Me.TabPageItemDetail.Controls.Add(Me.btnNew)
        Me.TabPageItemDetail.Controls.Add(Me.btnEdit)
        Me.TabPageItemDetail.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPageItemDetail.Location = New System.Drawing.Point(4, 25)
        Me.TabPageItemDetail.Name = "TabPageItemDetail"
        Me.TabPageItemDetail.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageItemDetail.Size = New System.Drawing.Size(529, 521)
        Me.TabPageItemDetail.TabIndex = 0
        Me.TabPageItemDetail.Text = "Stock Item Details"
        Me.TabPageItemDetail.UseVisualStyleBackColor = True
        '
        'labItemAction
        '
        Me.labItemAction.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labItemAction.ForeColor = System.Drawing.Color.DarkGoldenrod
        Me.labItemAction.Location = New System.Drawing.Point(84, 13)
        Me.labItemAction.Name = "labItemAction"
        Me.labItemAction.Size = New System.Drawing.Size(187, 21)
        Me.labItemAction.TabIndex = 17
        Me.labItemAction.Text = "labItemAction"
        Me.labItemAction.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'panelStockItem
        '
        Me.panelStockItem.BackColor = System.Drawing.Color.WhiteSmoke
        Me.panelStockItem.CausesValidation = False
        Me.panelStockItem.Controls.Add(Me.Label30)
        Me.panelStockItem.Controls.Add(Me.txtSupplierCode)
        Me.panelStockItem.Controls.Add(Me.Label29)
        Me.panelStockItem.Controls.Add(Me.Label28)
        Me.panelStockItem.Controls.Add(Me.chkAutoBarcode)
        Me.panelStockItem.Controls.Add(Me.txtIsNonStockItem)
        Me.panelStockItem.Controls.Add(Me.labQtyInStock)
        Me.panelStockItem.Controls.Add(Me.chkIsNonStockItem)
        Me.panelStockItem.Controls.Add(Me.txtReOrderLevel)
        Me.panelStockItem.Controls.Add(Me.chkTrackSerials)
        Me.panelStockItem.Controls.Add(Me.txtTrackSerials)
        Me.panelStockItem.Controls.Add(Me.labInStockLab)
        Me.panelStockItem.Controls.Add(Me.txtReOrderQty)
        Me.panelStockItem.Controls.Add(Me.Label11)
        Me.panelStockItem.Controls.Add(Me.labRates)
        Me.panelStockItem.Controls.Add(Me.Label12)
        Me.panelStockItem.Controls.Add(Me.Label25)
        Me.panelStockItem.Controls.Add(Me.txtCostIncTax)
        Me.panelStockItem.Controls.Add(Me.Label24)
        Me.panelStockItem.Controls.Add(Me.txtSellIncTax)
        Me.panelStockItem.Controls.Add(Me.chkSalesTax)
        Me.panelStockItem.Controls.Add(Me.chkGoodsTax)
        Me.panelStockItem.Controls.Add(Me.Label16)
        Me.panelStockItem.Controls.Add(Me.labRequiredFields)
        Me.panelStockItem.Controls.Add(Me.txtInactive)
        Me.panelStockItem.Controls.Add(Me.txtRenaming)
        Me.panelStockItem.Controls.Add(Me.btnStockCancel)
        Me.panelStockItem.Controls.Add(Me.btnStockCommit)
        Me.panelStockItem.Controls.Add(Me.txtSupplierName)
        Me.panelStockItem.Controls.Add(Me.txtBrandName)
        Me.panelStockItem.Controls.Add(Me.Label15)
        Me.panelStockItem.Controls.Add(Me.txtComments)
        Me.panelStockItem.Controls.Add(Me.chkRenaming)
        Me.panelStockItem.Controls.Add(Me.txtSalesTaxcode)
        Me.panelStockItem.Controls.Add(Me.Label13)
        Me.panelStockItem.Controls.Add(Me.txtSellExTax)
        Me.panelStockItem.Controls.Add(Me.txtGoodsTaxcode)
        Me.panelStockItem.Controls.Add(Me.Label10)
        Me.panelStockItem.Controls.Add(Me.txtCostExTax)
        Me.panelStockItem.Controls.Add(Me.cboSupplier)
        Me.panelStockItem.Controls.Add(Me.Label9)
        Me.panelStockItem.Controls.Add(Me.txtSupplier_id)
        Me.panelStockItem.Controls.Add(Me.cboBrand)
        Me.panelStockItem.Controls.Add(Me.Label8)
        Me.panelStockItem.Controls.Add(Me.txtBrand_id)
        Me.panelStockItem.Controls.Add(Me.chkInactive)
        Me.panelStockItem.Controls.Add(Me.cboCat2)
        Me.panelStockItem.Controls.Add(Me.Label7)
        Me.panelStockItem.Controls.Add(Me.txtCat2)
        Me.panelStockItem.Controls.Add(Me.cboCat1)
        Me.panelStockItem.Controls.Add(Me.Label6)
        Me.panelStockItem.Controls.Add(Me.txtCat1)
        Me.panelStockItem.Controls.Add(Me.txtStock_id)
        Me.panelStockItem.Controls.Add(Me.Label4)
        Me.panelStockItem.Controls.Add(Me.picProduct)
        Me.panelStockItem.Controls.Add(Me.txtDescription)
        Me.panelStockItem.Controls.Add(Me.BarcodeLabel)
        Me.panelStockItem.Controls.Add(Me.DescriptionLabel)
        Me.panelStockItem.Controls.Add(Me.txtBarcode)
        Me.panelStockItem.Location = New System.Drawing.Point(3, 38)
        Me.panelStockItem.Name = "panelStockItem"
        Me.panelStockItem.Size = New System.Drawing.Size(520, 477)
        Me.panelStockItem.TabIndex = 16
        '
        'Label30
        '
        Me.Label30.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(14, 246)
        Me.Label30.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(164, 17)
        Me.Label30.TabIndex = 65
        Me.Label30.Text = "Supplier Code for Product-"
        Me.ToolTip1.SetToolTip(Me.Label30, "Supplier Code for this Product for THIS Supplier")
        '
        'txtSupplierCode
        '
        Me.txtSupplierCode.BackColor = System.Drawing.Color.Lavender
        Me.txtSupplierCode.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSupplierCode.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSupplierCode.Location = New System.Drawing.Point(186, 244)
        Me.txtSupplierCode.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtSupplierCode.MaxLength = 40
        Me.txtSupplierCode.Name = "txtSupplierCode"
        Me.txtSupplierCode.Size = New System.Drawing.Size(321, 19)
        Me.txtSupplierCode.TabIndex = 28
        Me.txtSupplierCode.Text = "txtSupplierCode"
        Me.ToolTip1.SetToolTip(Me.txtSupplierCode, "Supplier Code for this Product for THIS Supplier")
        '
        'Label29
        '
        Me.Label29.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(325, 218)
        Me.Label29.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(23, 17)
        Me.Label29.TabIndex = 63
        Me.Label29.Text = "Id -"
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(325, 186)
        Me.Label28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(23, 17)
        Me.Label28.TabIndex = 62
        Me.Label28.Text = "Id -"
        '
        'chkAutoBarcode
        '
        Me.chkAutoBarcode.CausesValidation = False
        Me.chkAutoBarcode.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkAutoBarcode.Location = New System.Drawing.Point(79, 10)
        Me.chkAutoBarcode.Name = "chkAutoBarcode"
        Me.chkAutoBarcode.Size = New System.Drawing.Size(99, 17)
        Me.chkAutoBarcode.TabIndex = 0
        Me.chkAutoBarcode.Text = "Auto-generate "
        Me.ToolTip1.SetToolTip(Me.chkAutoBarcode, "Check here if system is to generate Barcode..")
        Me.chkAutoBarcode.UseVisualStyleBackColor = True
        '
        'txtIsNonStockItem
        '
        Me.txtIsNonStockItem.BackColor = System.Drawing.Color.Gainsboro
        Me.txtIsNonStockItem.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtIsNonStockItem.Font = New System.Drawing.Font("Tahoma", 5.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIsNonStockItem.Location = New System.Drawing.Point(188, 159)
        Me.txtIsNonStockItem.Name = "txtIsNonStockItem"
        Me.txtIsNonStockItem.ReadOnly = True
        Me.txtIsNonStockItem.Size = New System.Drawing.Size(19, 9)
        Me.txtIsNonStockItem.TabIndex = 16
        Me.txtIsNonStockItem.TabStop = False
        '
        'labQtyInStock
        '
        Me.labQtyInStock.BackColor = System.Drawing.Color.Gainsboro
        Me.labQtyInStock.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labQtyInStock.Location = New System.Drawing.Point(376, 10)
        Me.labQtyInStock.Name = "labQtyInStock"
        Me.labQtyInStock.Size = New System.Drawing.Size(34, 19)
        Me.labQtyInStock.TabIndex = 1
        Me.labQtyInStock.Text = "labQtyInStock"
        Me.labQtyInStock.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'chkIsNonStockItem
        '
        Me.chkIsNonStockItem.AutoSize = True
        Me.chkIsNonStockItem.BackColor = System.Drawing.Color.Lavender
        Me.chkIsNonStockItem.Location = New System.Drawing.Point(78, 154)
        Me.chkIsNonStockItem.Name = "chkIsNonStockItem"
        Me.chkIsNonStockItem.Size = New System.Drawing.Size(100, 17)
        Me.chkIsNonStockItem.TabIndex = 15
        Me.chkIsNonStockItem.Text = "Non-Stock Item"
        Me.ToolTip1.SetToolTip(Me.chkIsNonStockItem, "Check if Not stockable.. ie Service or Labour Item.")
        Me.chkIsNonStockItem.UseVisualStyleBackColor = False
        '
        'txtReOrderLevel
        '
        Me.txtReOrderLevel.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtReOrderLevel.Location = New System.Drawing.Point(377, 34)
        Me.txtReOrderLevel.MaxLength = 40
        Me.txtReOrderLevel.Name = "txtReOrderLevel"
        Me.txtReOrderLevel.Size = New System.Drawing.Size(34, 24)
        Me.txtReOrderLevel.TabIndex = 8
        Me.txtReOrderLevel.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chkTrackSerials
        '
        Me.chkTrackSerials.AutoSize = True
        Me.chkTrackSerials.BackColor = System.Drawing.Color.Lavender
        Me.chkTrackSerials.Location = New System.Drawing.Point(230, 154)
        Me.chkTrackSerials.Name = "chkTrackSerials"
        Me.chkTrackSerials.Size = New System.Drawing.Size(86, 17)
        Me.chkTrackSerials.TabIndex = 17
        Me.chkTrackSerials.Text = "Track Serials"
        Me.chkTrackSerials.UseVisualStyleBackColor = False
        '
        'txtTrackSerials
        '
        Me.txtTrackSerials.BackColor = System.Drawing.Color.Gainsboro
        Me.txtTrackSerials.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtTrackSerials.Font = New System.Drawing.Font("Tahoma", 5.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTrackSerials.Location = New System.Drawing.Point(322, 159)
        Me.txtTrackSerials.Name = "txtTrackSerials"
        Me.txtTrackSerials.ReadOnly = True
        Me.txtTrackSerials.Size = New System.Drawing.Size(19, 9)
        Me.txtTrackSerials.TabIndex = 18
        Me.txtTrackSerials.TabStop = False
        '
        'labInStockLab
        '
        Me.labInStockLab.Font = New System.Drawing.Font("Tahoma", 7.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labInStockLab.Location = New System.Drawing.Point(293, 14)
        Me.labInStockLab.Name = "labInStockLab"
        Me.labInStockLab.Size = New System.Drawing.Size(73, 17)
        Me.labInStockLab.TabIndex = 0
        Me.labInStockLab.Text = "Qty In Stock:"
        '
        'txtReOrderQty
        '
        Me.txtReOrderQty.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtReOrderQty.Location = New System.Drawing.Point(377, 57)
        Me.txtReOrderQty.Name = "txtReOrderQty"
        Me.txtReOrderQty.Size = New System.Drawing.Size(34, 24)
        Me.txtReOrderQty.TabIndex = 9
        Me.txtReOrderQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 7.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(293, 38)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(83, 17)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "Re-order Level:"
        '
        'labRates
        '
        Me.labRates.BackColor = System.Drawing.Color.Gainsboro
        Me.labRates.Font = New System.Drawing.Font("Lucida Sans Unicode", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labRates.ForeColor = System.Drawing.Color.Gray
        Me.labRates.Location = New System.Drawing.Point(83, 280)
        Me.labRates.Name = "labRates"
        Me.labRates.Size = New System.Drawing.Size(210, 12)
        Me.labRates.TabIndex = 61
        Me.labRates.Text = "labRates"
        Me.labRates.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Tahoma", 7.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(294, 59)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(82, 25)
        Me.Label12.TabIndex = 4
        Me.Label12.Text = "Max Qty to hold:"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ToolTip1.SetToolTip(Me.Label12, "This is now interpreted as the Maximum stock level to hold.." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(System will re-ord" & _
        "er up to this level..)")
        '
        'Label25
        '
        Me.Label25.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(312, 300)
        Me.Label25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(69, 17)
        Me.Label25.TabIndex = 60
        Me.Label25.Text = "Cost Inc Tax"
        '
        'txtCostIncTax
        '
        Me.txtCostIncTax.BackColor = System.Drawing.Color.Lavender
        Me.txtCostIncTax.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCostIncTax.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCostIncTax.Location = New System.Drawing.Point(377, 300)
        Me.txtCostIncTax.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtCostIncTax.MaxLength = 9
        Me.txtCostIncTax.Name = "txtCostIncTax"
        Me.txtCostIncTax.Size = New System.Drawing.Size(89, 17)
        Me.txtCostIncTax.TabIndex = 32
        Me.txtCostIncTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(312, 333)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(69, 17)
        Me.Label24.TabIndex = 58
        Me.Label24.Text = "Sell Inc Tax"
        '
        'txtSellIncTax
        '
        Me.txtSellIncTax.BackColor = System.Drawing.Color.Lavender
        Me.txtSellIncTax.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSellIncTax.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSellIncTax.Location = New System.Drawing.Point(377, 333)
        Me.txtSellIncTax.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtSellIncTax.MaxLength = 9
        Me.txtSellIncTax.Name = "txtSellIncTax"
        Me.txtSellIncTax.Size = New System.Drawing.Size(89, 17)
        Me.txtSellIncTax.TabIndex = 36
        Me.txtSellIncTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chkSalesTax
        '
        Me.chkSalesTax.AutoSize = True
        Me.chkSalesTax.Location = New System.Drawing.Point(173, 331)
        Me.chkSalesTax.Name = "chkSalesTax"
        Me.chkSalesTax.Size = New System.Drawing.Size(69, 17)
        Me.chkSalesTax.TabIndex = 34
        Me.chkSalesTax.Text = "SalesTax"
        Me.chkSalesTax.UseVisualStyleBackColor = True
        '
        'chkGoodsTax
        '
        Me.chkGoodsTax.AutoSize = True
        Me.chkGoodsTax.Location = New System.Drawing.Point(173, 299)
        Me.chkGoodsTax.Name = "chkGoodsTax"
        Me.chkGoodsTax.Size = New System.Drawing.Size(74, 17)
        Me.chkGoodsTax.TabIndex = 30
        Me.chkGoodsTax.Text = "GoodsTax"
        Me.chkGoodsTax.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(426, 109)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(85, 15)
        Me.Label16.TabIndex = 55
        Me.Label16.Text = "Product Picture"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'labRequiredFields
        '
        Me.labRequiredFields.Font = New System.Drawing.Font("Lucida Sans Unicode", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labRequiredFields.ForeColor = System.Drawing.Color.DarkMagenta
        Me.labRequiredFields.Location = New System.Drawing.Point(185, 371)
        Me.labRequiredFields.Name = "labRequiredFields"
        Me.labRequiredFields.Size = New System.Drawing.Size(196, 41)
        Me.labRequiredFields.TabIndex = 54
        Me.labRequiredFields.Text = "labRequiredFields"
        '
        'txtInactive
        '
        Me.txtInactive.BackColor = System.Drawing.Color.Gainsboro
        Me.txtInactive.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtInactive.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtInactive.Location = New System.Drawing.Point(253, 62)
        Me.txtInactive.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtInactive.Name = "txtInactive"
        Me.txtInactive.ReadOnly = True
        Me.txtInactive.Size = New System.Drawing.Size(25, 17)
        Me.txtInactive.TabIndex = 53
        Me.txtInactive.TabStop = False
        Me.txtInactive.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtRenaming
        '
        Me.txtRenaming.BackColor = System.Drawing.Color.Gainsboro
        Me.txtRenaming.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtRenaming.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRenaming.ForeColor = System.Drawing.Color.DarkGray
        Me.txtRenaming.Location = New System.Drawing.Point(127, 370)
        Me.txtRenaming.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtRenaming.Name = "txtRenaming"
        Me.txtRenaming.ReadOnly = True
        Me.txtRenaming.Size = New System.Drawing.Size(16, 17)
        Me.txtRenaming.TabIndex = 38
        Me.txtRenaming.TabStop = False
        '
        'btnStockCancel
        '
        Me.btnStockCancel.BackColor = System.Drawing.Color.Thistle
        Me.btnStockCancel.CausesValidation = False
        Me.btnStockCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStockCancel.Location = New System.Drawing.Point(429, 399)
        Me.btnStockCancel.Name = "btnStockCancel"
        Me.btnStockCancel.Size = New System.Drawing.Size(67, 26)
        Me.btnStockCancel.TabIndex = 40
        Me.btnStockCancel.Text = "Cancel"
        Me.btnStockCancel.UseVisualStyleBackColor = False
        '
        'btnStockCommit
        '
        Me.btnStockCommit.BackColor = System.Drawing.Color.GreenYellow
        Me.btnStockCommit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStockCommit.Location = New System.Drawing.Point(429, 439)
        Me.btnStockCommit.Name = "btnStockCommit"
        Me.btnStockCommit.Size = New System.Drawing.Size(67, 26)
        Me.btnStockCommit.TabIndex = 41
        Me.btnStockCommit.Text = "Commit"
        Me.btnStockCommit.UseVisualStyleBackColor = False
        '
        'txtSupplierName
        '
        Me.txtSupplierName.BackColor = System.Drawing.Color.Gainsboro
        Me.txtSupplierName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSupplierName.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSupplierName.ForeColor = System.Drawing.Color.Gray
        Me.txtSupplierName.Location = New System.Drawing.Point(382, 214)
        Me.txtSupplierName.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtSupplierName.Name = "txtSupplierName"
        Me.txtSupplierName.ReadOnly = True
        Me.txtSupplierName.Size = New System.Drawing.Size(125, 17)
        Me.txtSupplierName.TabIndex = 27
        Me.txtSupplierName.TabStop = False
        '
        'txtBrandName
        '
        Me.txtBrandName.BackColor = System.Drawing.Color.Gainsboro
        Me.txtBrandName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtBrandName.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBrandName.ForeColor = System.Drawing.Color.Gray
        Me.txtBrandName.Location = New System.Drawing.Point(382, 184)
        Me.txtBrandName.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtBrandName.Name = "txtBrandName"
        Me.txtBrandName.ReadOnly = True
        Me.txtBrandName.Size = New System.Drawing.Size(122, 17)
        Me.txtBrandName.TabIndex = 24
        Me.txtBrandName.TabStop = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(14, 404)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(61, 13)
        Me.Label15.TabIndex = 44
        Me.Label15.Text = "Comments:"
        '
        'txtComments
        '
        Me.txtComments.BackColor = System.Drawing.Color.Lavender
        Me.txtComments.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtComments.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtComments.Location = New System.Drawing.Point(17, 421)
        Me.txtComments.Multiline = True
        Me.txtComments.Name = "txtComments"
        Me.txtComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtComments.Size = New System.Drawing.Size(276, 48)
        Me.txtComments.TabIndex = 39
        '
        'chkRenaming
        '
        Me.chkRenaming.Location = New System.Drawing.Point(20, 368)
        Me.chkRenaming.Name = "chkRenaming"
        Me.chkRenaming.Size = New System.Drawing.Size(102, 21)
        Me.chkRenaming.TabIndex = 37
        Me.chkRenaming.Text = "Allow Renaming"
        Me.chkRenaming.UseVisualStyleBackColor = True
        '
        'txtSalesTaxcode
        '
        Me.txtSalesTaxcode.BackColor = System.Drawing.Color.Gainsboro
        Me.txtSalesTaxcode.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSalesTaxcode.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSalesTaxcode.Location = New System.Drawing.Point(250, 333)
        Me.txtSalesTaxcode.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtSalesTaxcode.Name = "txtSalesTaxcode"
        Me.txtSalesTaxcode.ReadOnly = True
        Me.txtSalesTaxcode.Size = New System.Drawing.Size(43, 17)
        Me.txtSalesTaxcode.TabIndex = 35
        Me.txtSalesTaxcode.TabStop = False
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(14, 333)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(69, 17)
        Me.Label13.TabIndex = 37
        Me.Label13.Text = "Sell Ex Tax"
        '
        'txtSellExTax
        '
        Me.txtSellExTax.BackColor = System.Drawing.Color.Lavender
        Me.txtSellExTax.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSellExTax.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSellExTax.Location = New System.Drawing.Point(79, 333)
        Me.txtSellExTax.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtSellExTax.MaxLength = 9
        Me.txtSellExTax.Name = "txtSellExTax"
        Me.txtSellExTax.Size = New System.Drawing.Size(89, 17)
        Me.txtSellExTax.TabIndex = 33
        Me.txtSellExTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtGoodsTaxcode
        '
        Me.txtGoodsTaxcode.BackColor = System.Drawing.Color.Gainsboro
        Me.txtGoodsTaxcode.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtGoodsTaxcode.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGoodsTaxcode.Location = New System.Drawing.Point(250, 300)
        Me.txtGoodsTaxcode.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtGoodsTaxcode.MaxLength = 7
        Me.txtGoodsTaxcode.Name = "txtGoodsTaxcode"
        Me.txtGoodsTaxcode.ReadOnly = True
        Me.txtGoodsTaxcode.Size = New System.Drawing.Size(43, 17)
        Me.txtGoodsTaxcode.TabIndex = 31
        Me.txtGoodsTaxcode.TabStop = False
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(13, 301)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(69, 17)
        Me.Label10.TabIndex = 32
        Me.Label10.Text = "Cost Ex Tax"
        '
        'txtCostExTax
        '
        Me.txtCostExTax.BackColor = System.Drawing.Color.Lavender
        Me.txtCostExTax.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCostExTax.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCostExTax.Location = New System.Drawing.Point(79, 300)
        Me.txtCostExTax.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtCostExTax.MaxLength = 9
        Me.txtCostExTax.Name = "txtCostExTax"
        Me.txtCostExTax.Size = New System.Drawing.Size(89, 17)
        Me.txtCostExTax.TabIndex = 29
        Me.txtCostExTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cboSupplier
        '
        Me.cboSupplier.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboSupplier.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboSupplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboSupplier.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboSupplier.FormattingEnabled = True
        Me.cboSupplier.Location = New System.Drawing.Point(79, 214)
        Me.cboSupplier.Name = "cboSupplier"
        Me.cboSupplier.Size = New System.Drawing.Size(237, 23)
        Me.cboSupplier.TabIndex = 25
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(13, 220)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(53, 17)
        Me.Label9.TabIndex = 30
        Me.Label9.Text = "Supplier-"
        '
        'txtSupplier_id
        '
        Me.txtSupplier_id.BackColor = System.Drawing.Color.Gainsboro
        Me.txtSupplier_id.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSupplier_id.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSupplier_id.ForeColor = System.Drawing.Color.Gray
        Me.txtSupplier_id.Location = New System.Drawing.Point(352, 213)
        Me.txtSupplier_id.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtSupplier_id.Name = "txtSupplier_id"
        Me.txtSupplier_id.ReadOnly = True
        Me.txtSupplier_id.Size = New System.Drawing.Size(24, 17)
        Me.txtSupplier_id.TabIndex = 26
        Me.txtSupplier_id.TabStop = False
        Me.txtSupplier_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cboBrand
        '
        Me.cboBrand.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboBrand.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboBrand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBrand.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboBrand.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBrand.FormattingEnabled = True
        Me.cboBrand.Location = New System.Drawing.Point(79, 181)
        Me.cboBrand.Name = "cboBrand"
        Me.cboBrand.Size = New System.Drawing.Size(237, 23)
        Me.cboBrand.TabIndex = 22
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(14, 185)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(52, 17)
        Me.Label8.TabIndex = 27
        Me.Label8.Text = "Brand -"
        '
        'txtBrand_id
        '
        Me.txtBrand_id.BackColor = System.Drawing.Color.Gainsboro
        Me.txtBrand_id.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtBrand_id.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBrand_id.ForeColor = System.Drawing.Color.Gray
        Me.txtBrand_id.Location = New System.Drawing.Point(352, 185)
        Me.txtBrand_id.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtBrand_id.Name = "txtBrand_id"
        Me.txtBrand_id.ReadOnly = True
        Me.txtBrand_id.Size = New System.Drawing.Size(24, 17)
        Me.txtBrand_id.TabIndex = 23
        Me.txtBrand_id.TabStop = False
        Me.txtBrand_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chkInactive
        '
        Me.chkInactive.Location = New System.Drawing.Point(181, 59)
        Me.chkInactive.Name = "chkInactive"
        Me.chkInactive.Size = New System.Drawing.Size(66, 19)
        Me.chkInactive.TabIndex = 10
        Me.chkInactive.Text = "Inactive"
        Me.chkInactive.UseVisualStyleBackColor = True
        '
        'cboCat2
        '
        Me.cboCat2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboCat2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboCat2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCat2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboCat2.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCat2.FormattingEnabled = True
        Me.cboCat2.Location = New System.Drawing.Point(252, 89)
        Me.cboCat2.Name = "cboCat2"
        Me.cboCat2.Size = New System.Drawing.Size(71, 23)
        Me.cboCat2.TabIndex = 11
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(190, 94)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 17)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "Category2"
        '
        'txtCat2
        '
        Me.txtCat2.BackColor = System.Drawing.Color.Gainsboro
        Me.txtCat2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCat2.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCat2.ForeColor = System.Drawing.Color.Gray
        Me.txtCat2.Location = New System.Drawing.Point(328, 95)
        Me.txtCat2.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtCat2.MaxLength = 6
        Me.txtCat2.Name = "txtCat2"
        Me.txtCat2.ReadOnly = True
        Me.txtCat2.Size = New System.Drawing.Size(32, 17)
        Me.txtCat2.TabIndex = 13
        Me.txtCat2.TabStop = False
        '
        'cboCat1
        '
        Me.cboCat1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboCat1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboCat1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCat1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboCat1.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCat1.FormattingEnabled = True
        Me.cboCat1.Location = New System.Drawing.Point(78, 89)
        Me.cboCat1.Name = "cboCat1"
        Me.cboCat1.Size = New System.Drawing.Size(71, 23)
        Me.cboCat1.TabIndex = 10
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(13, 93)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(60, 17)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "Category1"
        '
        'txtCat1
        '
        Me.txtCat1.BackColor = System.Drawing.Color.Gainsboro
        Me.txtCat1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCat1.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCat1.ForeColor = System.Drawing.Color.Gray
        Me.txtCat1.Location = New System.Drawing.Point(154, 95)
        Me.txtCat1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtCat1.MaxLength = 6
        Me.txtCat1.Name = "txtCat1"
        Me.txtCat1.ReadOnly = True
        Me.txtCat1.Size = New System.Drawing.Size(33, 17)
        Me.txtCat1.TabIndex = 12
        Me.txtCat1.TabStop = False
        '
        'txtStock_id
        '
        Me.txtStock_id.BackColor = System.Drawing.Color.LightGray
        Me.txtStock_id.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtStock_id.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStock_id.Location = New System.Drawing.Point(79, 61)
        Me.txtStock_id.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtStock_id.Name = "txtStock_id"
        Me.txtStock_id.ReadOnly = True
        Me.txtStock_id.Size = New System.Drawing.Size(43, 17)
        Me.txtStock_id.TabIndex = 7
        Me.txtStock_id.TabStop = False
        Me.txtStock_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Gray
        Me.Label4.Location = New System.Drawing.Point(14, 61)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 17)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "Stock_id"
        '
        'picProduct
        '
        Me.picProduct.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.picProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picProduct.Location = New System.Drawing.Point(420, 12)
        Me.picProduct.Name = "picProduct"
        Me.picProduct.Size = New System.Drawing.Size(91, 94)
        Me.picProduct.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picProduct.TabIndex = 12
        Me.picProduct.TabStop = False
        Me.ToolTip1.SetToolTip(Me.picProduct, "Click to browse files for Picture")
        '
        'txtDescription
        '
        Me.txtDescription.BackColor = System.Drawing.Color.Lavender
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtDescription.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDescription.Location = New System.Drawing.Point(78, 123)
        Me.txtDescription.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtDescription.MaxLength = 40
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(332, 19)
        Me.txtDescription.TabIndex = 14
        '
        'BarcodeLabel
        '
        Me.BarcodeLabel.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BarcodeLabel.Location = New System.Drawing.Point(13, 11)
        Me.BarcodeLabel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.BarcodeLabel.Name = "BarcodeLabel"
        Me.BarcodeLabel.Size = New System.Drawing.Size(62, 17)
        Me.BarcodeLabel.TabIndex = 9
        Me.BarcodeLabel.Text = "Barcode"
        '
        'DescriptionLabel
        '
        Me.DescriptionLabel.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DescriptionLabel.Location = New System.Drawing.Point(13, 123)
        Me.DescriptionLabel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DescriptionLabel.Name = "DescriptionLabel"
        Me.DescriptionLabel.Size = New System.Drawing.Size(61, 17)
        Me.DescriptionLabel.TabIndex = 13
        Me.DescriptionLabel.Text = "Description"
        '
        'txtBarcode
        '
        Me.txtBarcode.BackColor = System.Drawing.Color.Lavender
        Me.txtBarcode.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtBarcode.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBarcode.Location = New System.Drawing.Point(79, 28)
        Me.txtBarcode.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtBarcode.MaxLength = 40
        Me.txtBarcode.Name = "txtBarcode"
        Me.txtBarcode.Size = New System.Drawing.Size(197, 21)
        Me.txtBarcode.TabIndex = 1
        '
        'btnNew
        '
        Me.btnNew.BackColor = System.Drawing.Color.Lavender
        Me.btnNew.CausesValidation = False
        Me.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNew.Location = New System.Drawing.Point(420, 8)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.Size = New System.Drawing.Size(89, 24)
        Me.btnNew.TabIndex = 5
        Me.btnNew.Text = "New"
        Me.ToolTip1.SetToolTip(Me.btnNew, "Create New Stock Item")
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'btnEdit
        '
        Me.btnEdit.BackColor = System.Drawing.Color.NavajoWhite
        Me.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEdit.Location = New System.Drawing.Point(302, 8)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(89, 24)
        Me.btnEdit.TabIndex = 4
        Me.btnEdit.Text = "Edit"
        Me.ToolTip1.SetToolTip(Me.btnEdit, "Edir Current Item")
        Me.btnEdit.UseVisualStyleBackColor = False
        '
        'TabPageSerials
        '
        Me.TabPageSerials.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPageSerials.Controls.Add(Me.Label19)
        Me.TabPageSerials.Controls.Add(Me.dgvSerials)
        Me.TabPageSerials.Controls.Add(Me.labSerialsDescription)
        Me.TabPageSerials.Controls.Add(Me.labSerialsBarcode)
        Me.TabPageSerials.Controls.Add(Me.Label2)
        Me.TabPageSerials.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPageSerials.Location = New System.Drawing.Point(4, 25)
        Me.TabPageSerials.Name = "TabPageSerials"
        Me.TabPageSerials.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageSerials.Size = New System.Drawing.Size(529, 521)
        Me.TabPageSerials.TabIndex = 1
        Me.TabPageSerials.Text = "Stocked Serials"
        Me.TabPageSerials.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(28, 30)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(47, 13)
        Me.Label19.TabIndex = 6
        Me.Label19.Text = "B/code:"
        '
        'dgvSerials
        '
        Me.dgvSerials.AllowUserToAddRows = False
        Me.dgvSerials.AllowUserToDeleteRows = False
        Me.dgvSerials.BackgroundColor = System.Drawing.Color.WhiteSmoke
        Me.dgvSerials.ColumnHeadersHeight = 22
        Me.dgvSerials.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.SerialNumber, Me.SerialStatus, Me.Trans_History})
        Me.dgvSerials.GridColor = System.Drawing.SystemColors.ControlLight
        Me.dgvSerials.Location = New System.Drawing.Point(3, 52)
        Me.dgvSerials.MultiSelect = False
        Me.dgvSerials.Name = "dgvSerials"
        Me.dgvSerials.ReadOnly = True
        Me.dgvSerials.RowHeadersWidth = 30
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvSerials.RowsDefaultCellStyle = DataGridViewCellStyle3
        Me.dgvSerials.RowTemplate.Height = 17
        Me.dgvSerials.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvSerials.Size = New System.Drawing.Size(520, 477)
        Me.dgvSerials.TabIndex = 3
        '
        'SerialNumber
        '
        Me.SerialNumber.FillWeight = 90.0!
        Me.SerialNumber.HeaderText = "Serial Number"
        Me.SerialNumber.Name = "SerialNumber"
        Me.SerialNumber.ReadOnly = True
        Me.SerialNumber.Width = 130
        '
        'SerialStatus
        '
        Me.SerialStatus.FillWeight = 50.0!
        Me.SerialStatus.HeaderText = "Status"
        Me.SerialStatus.Name = "SerialStatus"
        Me.SerialStatus.ReadOnly = True
        Me.SerialStatus.Width = 61
        '
        'Trans_History
        '
        Me.Trans_History.FillWeight = 260.0!
        Me.Trans_History.HeaderText = "Trans. History"
        Me.Trans_History.Name = "Trans_History"
        Me.Trans_History.ReadOnly = True
        Me.Trans_History.Width = 520
        '
        'labSerialsDescription
        '
        Me.labSerialsDescription.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labSerialsDescription.Location = New System.Drawing.Point(184, 29)
        Me.labSerialsDescription.Name = "labSerialsDescription"
        Me.labSerialsDescription.Size = New System.Drawing.Size(264, 19)
        Me.labSerialsDescription.TabIndex = 2
        Me.labSerialsDescription.Text = "labSerialsDescription"
        '
        'labSerialsBarcode
        '
        Me.labSerialsBarcode.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labSerialsBarcode.Location = New System.Drawing.Point(79, 29)
        Me.labSerialsBarcode.Name = "labSerialsBarcode"
        Me.labSerialsBarcode.Size = New System.Drawing.Size(99, 19)
        Me.labSerialsBarcode.TabIndex = 1
        Me.labSerialsBarcode.Text = "labSerialsBarcode"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.LightYellow
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(11, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(210, 17)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Serial Nos History for Stock Item:"
        '
        'TabPagePurchases
        '
        Me.TabPagePurchases.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPagePurchases.Controls.Add(Me.dgvGoods)
        Me.TabPagePurchases.Controls.Add(Me.Label18)
        Me.TabPagePurchases.Controls.Add(Me.labGoodsDescription)
        Me.TabPagePurchases.Controls.Add(Me.labGoodsBarcode)
        Me.TabPagePurchases.Controls.Add(Me.Label17)
        Me.TabPagePurchases.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPagePurchases.Location = New System.Drawing.Point(4, 25)
        Me.TabPagePurchases.Name = "TabPagePurchases"
        Me.TabPagePurchases.Size = New System.Drawing.Size(529, 521)
        Me.TabPagePurchases.TabIndex = 2
        Me.TabPagePurchases.Text = "Purchases"
        Me.TabPagePurchases.UseVisualStyleBackColor = True
        '
        'dgvGoods
        '
        Me.dgvGoods.AllowUserToAddRows = False
        Me.dgvGoods.AllowUserToDeleteRows = False
        Me.dgvGoods.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvGoods.BackgroundColor = System.Drawing.Color.WhiteSmoke
        Me.dgvGoods.ColumnHeadersHeight = 22
        Me.dgvGoods.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvGoods.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Goods_id, Me.goods_date, Me.supplier, Me.invoice_no, Me.quantity})
        Me.dgvGoods.GridColor = System.Drawing.SystemColors.ControlLight
        Me.dgvGoods.Location = New System.Drawing.Point(3, 52)
        Me.dgvGoods.MultiSelect = False
        Me.dgvGoods.Name = "dgvGoods"
        Me.dgvGoods.ReadOnly = True
        Me.dgvGoods.RowHeadersWidth = 30
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvGoods.RowsDefaultCellStyle = DataGridViewCellStyle6
        Me.dgvGoods.RowTemplate.Height = 17
        Me.dgvGoods.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvGoods.Size = New System.Drawing.Size(520, 477)
        Me.dgvGoods.TabIndex = 6
        '
        'Goods_id
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Goods_id.DefaultCellStyle = DataGridViewCellStyle4
        Me.Goods_id.FillWeight = 50.0!
        Me.Goods_id.HeaderText = "Goods Id"
        Me.Goods_id.Name = "Goods_id"
        Me.Goods_id.ReadOnly = True
        '
        'goods_date
        '
        Me.goods_date.FillWeight = 60.0!
        Me.goods_date.HeaderText = "Goods Date"
        Me.goods_date.Name = "goods_date"
        Me.goods_date.ReadOnly = True
        '
        'supplier
        '
        Me.supplier.FillWeight = 120.0!
        Me.supplier.HeaderText = "Supplier"
        Me.supplier.Name = "supplier"
        Me.supplier.ReadOnly = True
        '
        'invoice_no
        '
        Me.invoice_no.HeaderText = "Invoice No."
        Me.invoice_no.Name = "invoice_no"
        Me.invoice_no.ReadOnly = True
        '
        'quantity
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.quantity.DefaultCellStyle = DataGridViewCellStyle5
        Me.quantity.FillWeight = 40.0!
        Me.quantity.HeaderText = "Qty"
        Me.quantity.Name = "quantity"
        Me.quantity.ReadOnly = True
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(28, 30)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(47, 13)
        Me.Label18.TabIndex = 5
        Me.Label18.Text = "B/code:"
        '
        'labGoodsDescription
        '
        Me.labGoodsDescription.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labGoodsDescription.Location = New System.Drawing.Point(194, 29)
        Me.labGoodsDescription.Name = "labGoodsDescription"
        Me.labGoodsDescription.Size = New System.Drawing.Size(260, 19)
        Me.labGoodsDescription.TabIndex = 4
        Me.labGoodsDescription.Text = "labGoodsDescription"
        '
        'labGoodsBarcode
        '
        Me.labGoodsBarcode.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labGoodsBarcode.Location = New System.Drawing.Point(74, 29)
        Me.labGoodsBarcode.Name = "labGoodsBarcode"
        Me.labGoodsBarcode.Size = New System.Drawing.Size(116, 19)
        Me.labGoodsBarcode.TabIndex = 3
        Me.labGoodsBarcode.Text = "abGoodsBarcode"
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.MistyRose
        Me.Label17.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(11, 9)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(298, 17)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "Purchases (Goods Received) History for Item:"
        '
        'TabPageSales
        '
        Me.TabPageSales.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPageSales.Controls.Add(Me.Label26)
        Me.TabPageSales.Controls.Add(Me.dgvSales)
        Me.TabPageSales.Controls.Add(Me.Label20)
        Me.TabPageSales.Controls.Add(Me.labSalesDescription)
        Me.TabPageSales.Controls.Add(Me.labSalesBarcode)
        Me.TabPageSales.Controls.Add(Me.Label23)
        Me.TabPageSales.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPageSales.Location = New System.Drawing.Point(4, 25)
        Me.TabPageSales.Name = "TabPageSales"
        Me.TabPageSales.Size = New System.Drawing.Size(529, 521)
        Me.TabPageSales.TabIndex = 3
        Me.TabPageSales.Text = "POS Sales"
        '
        'Label26
        '
        Me.Label26.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.SaddleBrown
        Me.Label26.Location = New System.Drawing.Point(338, 31)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(185, 36)
        Me.Label26.TabIndex = 12
        Me.Label26.Text = "To view an invoice," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "   double-click on the Row."
        '
        'dgvSales
        '
        Me.dgvSales.AllowUserToAddRows = False
        Me.dgvSales.AllowUserToDeleteRows = False
        Me.dgvSales.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvSales.BackgroundColor = System.Drawing.Color.WhiteSmoke
        Me.dgvSales.ColumnHeadersHeight = 22
        Me.dgvSales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvSales.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.sale_invoice_no, Me.invoice_date, Me.invoice_trancode, Me.customer, Me.sale_qty, Me.sale_value})
        Me.dgvSales.GridColor = System.Drawing.SystemColors.ControlLight
        Me.dgvSales.Location = New System.Drawing.Point(3, 72)
        Me.dgvSales.Name = "dgvSales"
        Me.dgvSales.ReadOnly = True
        Me.dgvSales.RowHeadersWidth = 30
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvSales.RowsDefaultCellStyle = DataGridViewCellStyle10
        Me.dgvSales.RowTemplate.Height = 17
        Me.dgvSales.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvSales.Size = New System.Drawing.Size(520, 418)
        Me.dgvSales.TabIndex = 11
        '
        'sale_invoice_no
        '
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.sale_invoice_no.DefaultCellStyle = DataGridViewCellStyle7
        Me.sale_invoice_no.FillWeight = 50.0!
        Me.sale_invoice_no.HeaderText = "Invoice No"
        Me.sale_invoice_no.Name = "sale_invoice_no"
        Me.sale_invoice_no.ReadOnly = True
        '
        'invoice_date
        '
        Me.invoice_date.FillWeight = 80.0!
        Me.invoice_date.HeaderText = "Date"
        Me.invoice_date.Name = "invoice_date"
        Me.invoice_date.ReadOnly = True
        '
        'invoice_trancode
        '
        Me.invoice_trancode.FillWeight = 70.0!
        Me.invoice_trancode.HeaderText = "Trancode"
        Me.invoice_trancode.Name = "invoice_trancode"
        Me.invoice_trancode.ReadOnly = True
        '
        'customer
        '
        Me.customer.FillWeight = 120.0!
        Me.customer.HeaderText = "Customer"
        Me.customer.Name = "customer"
        Me.customer.ReadOnly = True
        '
        'sale_qty
        '
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.sale_qty.DefaultCellStyle = DataGridViewCellStyle8
        Me.sale_qty.FillWeight = 40.0!
        Me.sale_qty.HeaderText = "Qty"
        Me.sale_qty.Name = "sale_qty"
        Me.sale_qty.ReadOnly = True
        '
        'sale_value
        '
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.sale_value.DefaultCellStyle = DataGridViewCellStyle9
        Me.sale_value.FillWeight = 70.0!
        Me.sale_value.HeaderText = "Value"
        Me.sale_value.Name = "sale_value"
        Me.sale_value.ReadOnly = True
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(16, 32)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(47, 15)
        Me.Label20.TabIndex = 10
        Me.Label20.Text = "B/code:"
        '
        'labSalesDescription
        '
        Me.labSalesDescription.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labSalesDescription.Location = New System.Drawing.Point(16, 50)
        Me.labSalesDescription.Name = "labSalesDescription"
        Me.labSalesDescription.Size = New System.Drawing.Size(311, 17)
        Me.labSalesDescription.TabIndex = 9
        Me.labSalesDescription.Text = "labSalesDescription"
        '
        'labSalesBarcode
        '
        Me.labSalesBarcode.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labSalesBarcode.Location = New System.Drawing.Point(67, 31)
        Me.labSalesBarcode.Name = "labSalesBarcode"
        Me.labSalesBarcode.Size = New System.Drawing.Size(99, 17)
        Me.labSalesBarcode.TabIndex = 8
        Me.labSalesBarcode.Text = "labSalesBarcode"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Lavender
        Me.Label23.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(11, 9)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(182, 17)
        Me.Label23.TabIndex = 7
        Me.Label23.Text = "Sales History for Stock Item:"
        '
        'openDlg1
        '
        Me.openDlg1.FileName = "OpenFileDialog1"
        '
        'timerGrid
        '
        '
        'ucChildStockAdmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Controls.Add(Me.grpBoxStock)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "ucChildStockAdmin"
        Me.Size = New System.Drawing.Size(1004, 640)
        Me.grpBoxStock.ResumeLayout(False)
        Me.panelItemHdr.ResumeLayout(False)
        Me.panelItemHdr.PerformLayout()
        Me.frameBrowse.ResumeLayout(False)
        Me.frameBrowse.PerformLayout()
        CType(Me.dgvStockList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBanner.ResumeLayout(False)
        Me.panelBanner.PerformLayout()
        Me.panelRefence.ResumeLayout(False)
        Me.tabControlStock.ResumeLayout(False)
        Me.TabPageItemDetail.ResumeLayout(False)
        Me.panelStockItem.ResumeLayout(False)
        Me.panelStockItem.PerformLayout()
        CType(Me.picProduct, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPageSerials.ResumeLayout(False)
        Me.TabPageSerials.PerformLayout()
        CType(Me.dgvSerials, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPagePurchases.ResumeLayout(False)
        CType(Me.dgvGoods, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPageSales.ResumeLayout(False)
        Me.TabPageSales.PerformLayout()
        CType(Me.dgvSales, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grpBoxStock As System.Windows.Forms.GroupBox
    Friend WithEvents labInStockLab As System.Windows.Forms.Label
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents DescriptionLabel As System.Windows.Forms.Label
    Friend WithEvents picProduct As System.Windows.Forms.PictureBox
    Friend WithEvents txtBarcode As System.Windows.Forms.TextBox
    Friend WithEvents BarcodeLabel As System.Windows.Forms.Label
    Friend WithEvents panelStockItem As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnNew As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtStock_id As System.Windows.Forms.TextBox
    Friend WithEvents panelBanner As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents labToday As System.Windows.Forms.Label
    Friend WithEvents labStaffName As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboCat1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtCat1 As System.Windows.Forms.TextBox
    Friend WithEvents cboCat2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtCat2 As System.Windows.Forms.TextBox
    Friend WithEvents openDlg1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents chkInactive As System.Windows.Forms.CheckBox
    Friend WithEvents cboBrand As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtBrand_id As System.Windows.Forms.TextBox
    Friend WithEvents cboSupplier As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtSupplier_id As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtCostExTax As System.Windows.Forms.TextBox
    Friend WithEvents txtGoodsTaxcode As System.Windows.Forms.TextBox
    Friend WithEvents txtSalesTaxcode As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtSellExTax As System.Windows.Forms.TextBox
    Friend WithEvents chkRenaming As System.Windows.Forms.CheckBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtComments As System.Windows.Forms.TextBox
    Friend WithEvents txtSupplierName As System.Windows.Forms.TextBox
    Friend WithEvents txtBrandName As System.Windows.Forms.TextBox
    Friend WithEvents btnStockCancel As System.Windows.Forms.Button
    Friend WithEvents btnStockCommit As System.Windows.Forms.Button
    Friend WithEvents txtRenaming As System.Windows.Forms.TextBox
    Friend WithEvents txtInactive As System.Windows.Forms.TextBox
    Friend WithEvents labRequiredFields As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents tabControlStock As System.Windows.Forms.TabControl
    Friend WithEvents TabPageItemDetail As System.Windows.Forms.TabPage
    Friend WithEvents TabPageSerials As System.Windows.Forms.TabPage
    Friend WithEvents labSerialsDescription As System.Windows.Forms.Label
    Friend WithEvents labSerialsBarcode As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents dgvSerials As System.Windows.Forms.DataGridView
    Friend WithEvents TabPagePurchases As System.Windows.Forms.TabPage
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents labGoodsDescription As System.Windows.Forms.Label
    Friend WithEvents labGoodsBarcode As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TabPageSales As System.Windows.Forms.TabPage
    Friend WithEvents dgvGoods As System.Windows.Forms.DataGridView
    Friend WithEvents dgvSales As System.Windows.Forms.DataGridView
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents labSalesDescription As System.Windows.Forms.Label
    Friend WithEvents labSalesBarcode As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Goods_id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents goods_date As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents supplier As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents invoice_no As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents quantity As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents chkGoodsTax As System.Windows.Forms.CheckBox
    Friend WithEvents chkSalesTax As System.Windows.Forms.CheckBox
    Friend WithEvents labQtyInStock As System.Windows.Forms.Label
    Friend WithEvents txtReOrderLevel As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtReOrderQty As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtTrackSerials As System.Windows.Forms.TextBox
    Friend WithEvents chkTrackSerials As System.Windows.Forms.CheckBox
    Public WithEvents frameBrowse As System.Windows.Forms.GroupBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Public WithEvents cmdClearStockSearch As System.Windows.Forms.Button
    Public WithEvents cmdStockSearch As System.Windows.Forms.Button
    Public WithEvents txtStockSearch As System.Windows.Forms.TextBox
    Friend WithEvents dgvStockList As System.Windows.Forms.DataGridView
    Public WithEvents txtFind As System.Windows.Forms.TextBox
    Public WithEvents labRecCount As System.Windows.Forms.Label
    Public WithEvents LabFind As System.Windows.Forms.Label
    Public WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txtSellIncTax As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtCostIncTax As System.Windows.Forms.TextBox
    Friend WithEvents labItemHeader As System.Windows.Forms.Label
    Friend WithEvents labRates As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtlabelCount As System.Windows.Forms.TextBox
    Friend WithEvents btnPrintLabels As System.Windows.Forms.Button
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents panelItemHdr As System.Windows.Forms.Panel
    Friend WithEvents SerialNumber As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SerialStatus As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Trans_History As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents txtHdrBarcode As System.Windows.Forms.TextBox
    Friend WithEvents chkIsNonStockItem As System.Windows.Forms.CheckBox
    Friend WithEvents txtIsNonStockItem As System.Windows.Forms.TextBox
    Friend WithEvents labItemAction As System.Windows.Forms.Label
    Friend WithEvents chkAutoBarcode As System.Windows.Forms.CheckBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents timerGrid As System.Windows.Forms.Timer
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents sale_invoice_no As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents invoice_date As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents invoice_trancode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents customer As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents sale_qty As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents sale_value As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents txtSupplierCode As System.Windows.Forms.TextBox
    Friend WithEvents panelRefence As System.Windows.Forms.Panel
    Friend WithEvents btnNewBrand As System.Windows.Forms.Button
    Friend WithEvents btnNewCat2 As System.Windows.Forms.Button
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents btnNewCat1 As System.Windows.Forms.Button
End Class
