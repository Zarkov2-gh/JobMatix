<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ucPosSaleChild
    Inherits System.Windows.Forms.UserControl  '=  System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ucPosSaleChild))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.grpboxSale = New System.Windows.Forms.GroupBox()
        Me.panelCommit = New System.Windows.Forms.Panel()
        Me.labSaleAccountSalesInfo = New System.Windows.Forms.Label()
        Me.btnSaleComments = New System.Windows.Forms.Button()
        Me.btnCancelSale = New System.Windows.Forms.Button()
        Me.btnCommitSale = New System.Windows.Forms.Button()
        Me.panelSalesCurrentHdr = New System.Windows.Forms.Panel()
        Me.labShortcuts = New System.Windows.Forms.Label()
        Me.btnMainExit = New System.Windows.Forms.Button()
        Me.picSaleItem = New System.Windows.Forms.PictureBox()
        Me.panelSaleLineEntry = New System.Windows.Forms.Panel()
        Me.btnSaleItemLineClear2 = New System.Windows.Forms.Button()
        Me.btnSaleItemLineClear = New System.Windows.Forms.Button()
        Me.btnSaleLineOk = New System.Windows.Forms.Button()
        Me.txtSaleItemExtension = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtSaleItemQty = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtSaleItemSellPrice = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtSaleItemDescription = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtSaleItemSerialNo = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtSaleItemBarcode = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.panelSaleFooter = New System.Windows.Forms.Panel()
        Me.labSaleHelp2 = New System.Windows.Forms.Label()
        Me.labSaleHelp = New System.Windows.Forms.Label()
        Me.panelPayment = New System.Windows.Forms.Panel()
        Me.grpBoxSalePayments = New System.Windows.Forms.GroupBox()
        Me.txtCreditNoteWdl = New System.Windows.Forms.TextBox()
        Me.dgvSalePaymentDetails = New System.Windows.Forms.DataGridView()
        Me.PaymentType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Amount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PaymentType_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.labCreditNoteLab = New System.Windows.Forms.Label()
        Me.LabSalePayments = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.chkOnAccount = New System.Windows.Forms.CheckBox()
        Me.grpBoxRefundType = New System.Windows.Forms.GroupBox()
        Me.cboRefundOtherDetails = New System.Windows.Forms.ComboBox()
        Me.optRefundOther = New System.Windows.Forms.RadioButton()
        Me.optRefundEftPosCr = New System.Windows.Forms.RadioButton()
        Me.optRefundEftPosDr = New System.Windows.Forms.RadioButton()
        Me.optRefundCredit = New System.Windows.Forms.RadioButton()
        Me.optRefundCash = New System.Windows.Forms.RadioButton()
        Me.labSaleChargeBalance = New System.Windows.Forms.Label()
        Me.labSaleChange = New System.Windows.Forms.Label()
        Me.LabSaleBalance = New System.Windows.Forms.Label()
        Me.txtSaleChange = New System.Windows.Forms.TextBox()
        Me.txtSalePaymentBalance = New System.Windows.Forms.TextBox()
        Me.labSaleCrBal = New System.Windows.Forms.Label()
        Me.panelSaleTotals = New System.Windows.Forms.Panel()
        Me.btnDiscountPC = New System.Windows.Forms.Button()
        Me.cboSaleDiscountPercent = New System.Windows.Forms.ComboBox()
        Me.txtSaleSubTotal2 = New System.Windows.Forms.TextBox()
        Me.LabSaleSubTotal2 = New System.Windows.Forms.Label()
        Me.txtSaleNettTax = New System.Windows.Forms.TextBox()
        Me.LabSaleNettTax = New System.Windows.Forms.Label()
        Me.LabSaleDiscAnalysis = New System.Windows.Forms.Label()
        Me.txtSaleDiscountAnalysis = New System.Windows.Forms.TextBox()
        Me.LabSaleIncludesTax = New System.Windows.Forms.Label()
        Me.txtSaleTotalTax = New System.Windows.Forms.TextBox()
        Me.txtSaleSubTotal = New System.Windows.Forms.TextBox()
        Me.LabSaleSubTotal = New System.Windows.Forms.Label()
        Me.LabSaleDiscount = New System.Windows.Forms.Label()
        Me.txtSaleDiscount = New System.Windows.Forms.TextBox()
        Me.txtSaleRounding = New System.Windows.Forms.TextBox()
        Me.LabSaleRounding = New System.Windows.Forms.Label()
        Me.LabSaleInvTotal = New System.Windows.Forms.Label()
        Me.txtSaleTotal = New System.Windows.Forms.TextBox()
        Me.dgvSaleItems = New System.Windows.Forms.DataGridView()
        Me.panelSaleHdr = New System.Windows.Forms.Panel()
        Me.labSaleCustTags = New System.Windows.Forms.Label()
        Me.chkOnAccount2 = New System.Windows.Forms.CheckBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.labSaleStaffName = New System.Windows.Forms.Label()
        Me.listViewSaleAvailCredit = New System.Windows.Forms.ListView()
        Me.itemLabel = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.itemValue = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.txtSaleStaffBarcode = New System.Windows.Forms.TextBox()
        Me.labSaleStaff = New System.Windows.Forms.Label()
        Me.labSaleTranType = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.btnCancelSale2 = New System.Windows.Forms.Button()
        Me.panelOptTranType = New System.Windows.Forms.Panel()
        Me.labImportQuote = New System.Windows.Forms.Label()
        Me.optSaleLayby = New System.Windows.Forms.RadioButton()
        Me.optSaleQuote = New System.Windows.Forms.RadioButton()
        Me.optSaleRefund = New System.Windows.Forms.RadioButton()
        Me.optSaleSale = New System.Windows.Forms.RadioButton()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.panelSaleInvoiceList = New System.Windows.Forms.Panel()
        Me.btnSaleSelectLayby = New System.Windows.Forms.Button()
        Me.btnSaleSelectQuote = New System.Windows.Forms.Button()
        Me.btnSaleSelectInvoice = New System.Windows.Forms.Button()
        Me.LabSalePrevious = New System.Windows.Forms.Label()
        Me.txtSaleJobNo = New System.Windows.Forms.TextBox()
        Me.labSaleJobDelivery = New System.Windows.Forms.Label()
        Me.txtSaleCustName = New System.Windows.Forms.TextBox()
        Me.LabSaleCust = New System.Windows.Forms.Label()
        Me.txtSaleCustBarcode = New System.Windows.Forms.TextBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Barcode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SerialNo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cat1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cat2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Description = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Tax = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Sell_inc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Sell_Actual_inc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Qty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SellActual_Inc_Extended = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Stock_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Track_serial = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SERIAL_AUDIT_ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.isServiceItem = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cost_Ex = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cost_Inc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Sell_ex = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SellActual_Ex = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SellActual_Tax = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SellActual_Ex_Extended = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SellActual_tax_Extended = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grpboxSale.SuspendLayout()
        Me.panelCommit.SuspendLayout()
        Me.panelSalesCurrentHdr.SuspendLayout()
        CType(Me.picSaleItem, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelSaleLineEntry.SuspendLayout()
        Me.panelSaleFooter.SuspendLayout()
        Me.panelPayment.SuspendLayout()
        Me.grpBoxSalePayments.SuspendLayout()
        CType(Me.dgvSalePaymentDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpBoxRefundType.SuspendLayout()
        Me.panelSaleTotals.SuspendLayout()
        CType(Me.dgvSaleItems, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelSaleHdr.SuspendLayout()
        Me.panelOptTranType.SuspendLayout()
        Me.panelSaleInvoiceList.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpboxSale
        '
        Me.grpboxSale.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.grpboxSale.CausesValidation = False
        Me.grpboxSale.Controls.Add(Me.panelCommit)
        Me.grpboxSale.Controls.Add(Me.panelSalesCurrentHdr)
        Me.grpboxSale.Controls.Add(Me.panelSaleLineEntry)
        Me.grpboxSale.Controls.Add(Me.panelSaleFooter)
        Me.grpboxSale.Controls.Add(Me.dgvSaleItems)
        Me.grpboxSale.Controls.Add(Me.panelSaleHdr)
        Me.grpboxSale.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpboxSale.Location = New System.Drawing.Point(2, 2)
        Me.grpboxSale.Name = "grpboxSale"
        Me.grpboxSale.Size = New System.Drawing.Size(994, 633)
        Me.grpboxSale.TabIndex = 0
        Me.grpboxSale.TabStop = False
        Me.grpboxSale.Text = "grpboxSale"
        '
        'panelCommit
        '
        Me.panelCommit.BackColor = System.Drawing.Color.WhiteSmoke
        Me.panelCommit.CausesValidation = False
        Me.panelCommit.Controls.Add(Me.labSaleAccountSalesInfo)
        Me.panelCommit.Controls.Add(Me.btnSaleComments)
        Me.panelCommit.Controls.Add(Me.btnCancelSale)
        Me.panelCommit.Controls.Add(Me.btnCommitSale)
        Me.panelCommit.Location = New System.Drawing.Point(861, 230)
        Me.panelCommit.Name = "panelCommit"
        Me.panelCommit.Size = New System.Drawing.Size(125, 394)
        Me.panelCommit.TabIndex = 7
        Me.panelCommit.TabStop = True
        '
        'labSaleAccountSalesInfo
        '
        Me.labSaleAccountSalesInfo.CausesValidation = False
        Me.labSaleAccountSalesInfo.Location = New System.Drawing.Point(4, 10)
        Me.labSaleAccountSalesInfo.Name = "labSaleAccountSalesInfo"
        Me.labSaleAccountSalesInfo.Padding = New System.Windows.Forms.Padding(3, 3, 0, 0)
        Me.labSaleAccountSalesInfo.Size = New System.Drawing.Size(116, 137)
        Me.labSaleAccountSalesInfo.TabIndex = 53
        Me.labSaleAccountSalesInfo.Text = "Note:  Account Sales are in all cases iinvoiced and charged to the Account..  " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "A" & _
    "ny acompanying Payment is treated as an Account Payment, and a separate receipt " & _
    "will be issued."
        '
        'btnSaleComments
        '
        Me.btnSaleComments.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnSaleComments.CausesValidation = False
        Me.btnSaleComments.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSaleComments.Location = New System.Drawing.Point(18, 181)
        Me.btnSaleComments.Name = "btnSaleComments"
        Me.btnSaleComments.Size = New System.Drawing.Size(87, 39)
        Me.btnSaleComments.TabIndex = 6
        Me.btnSaleComments.Text = "Comments"
        Me.ToolTip1.SetToolTip(Me.btnSaleComments, "Enter/Update Comments/Delivery")
        Me.btnSaleComments.UseVisualStyleBackColor = False
        '
        'btnCancelSale
        '
        Me.btnCancelSale.BackColor = System.Drawing.Color.LavenderBlush
        Me.btnCancelSale.CausesValidation = False
        Me.btnCancelSale.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.btnCancelSale.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCancelSale.Location = New System.Drawing.Point(18, 261)
        Me.btnCancelSale.Name = "btnCancelSale"
        Me.btnCancelSale.Size = New System.Drawing.Size(87, 39)
        Me.btnCancelSale.TabIndex = 7
        Me.btnCancelSale.TabStop = False
        Me.btnCancelSale.Text = "X  Cancel"
        Me.ToolTip1.SetToolTip(Me.btnCancelSale, "Cancel this Sale and Clear..")
        Me.btnCancelSale.UseVisualStyleBackColor = False
        '
        'btnCommitSale
        '
        Me.btnCommitSale.BackColor = System.Drawing.Color.YellowGreen
        Me.btnCommitSale.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.btnCommitSale.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCommitSale.Location = New System.Drawing.Point(18, 327)
        Me.btnCommitSale.Name = "btnCommitSale"
        Me.btnCommitSale.Size = New System.Drawing.Size(87, 39)
        Me.btnCommitSale.TabIndex = 8
        Me.btnCommitSale.Text = "ok- Commit"
        Me.btnCommitSale.UseVisualStyleBackColor = False
        '
        'panelSalesCurrentHdr
        '
        Me.panelSalesCurrentHdr.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.panelSalesCurrentHdr.CausesValidation = False
        Me.panelSalesCurrentHdr.Controls.Add(Me.labShortcuts)
        Me.panelSalesCurrentHdr.Controls.Add(Me.btnMainExit)
        Me.panelSalesCurrentHdr.Controls.Add(Me.picSaleItem)
        Me.panelSalesCurrentHdr.Location = New System.Drawing.Point(861, 5)
        Me.panelSalesCurrentHdr.Name = "panelSalesCurrentHdr"
        Me.panelSalesCurrentHdr.Size = New System.Drawing.Size(125, 220)
        Me.panelSalesCurrentHdr.TabIndex = 0
        Me.panelSalesCurrentHdr.TabStop = True
        '
        'labShortcuts
        '
        Me.labShortcuts.BackColor = System.Drawing.Color.LightYellow
        Me.labShortcuts.CausesValidation = False
        Me.labShortcuts.Font = New System.Drawing.Font("Tahoma", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labShortcuts.ForeColor = System.Drawing.SystemColors.GrayText
        Me.labShortcuts.Location = New System.Drawing.Point(25, 49)
        Me.labShortcuts.Name = "labShortcuts"
        Me.labShortcuts.Padding = New System.Windows.Forms.Padding(3, 3, 0, 0)
        Me.labShortcuts.Size = New System.Drawing.Size(80, 39)
        Me.labShortcuts.TabIndex = 27
        Me.labShortcuts.Text = "Keyboard       Shortcuts..."
        Me.labShortcuts.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.labShortcuts, resources.GetString("labShortcuts.ToolTip"))
        '
        'btnMainExit
        '
        Me.btnMainExit.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnMainExit.CausesValidation = False
        Me.btnMainExit.Location = New System.Drawing.Point(49, 8)
        Me.btnMainExit.Name = "btnMainExit"
        Me.btnMainExit.Size = New System.Drawing.Size(56, 25)
        Me.btnMainExit.TabIndex = 2
        Me.btnMainExit.TabStop = False
        Me.btnMainExit.Text = "Exit"
        Me.btnMainExit.UseVisualStyleBackColor = False
        '
        'picSaleItem
        '
        Me.picSaleItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.picSaleItem.Location = New System.Drawing.Point(22, 117)
        Me.picSaleItem.Name = "picSaleItem"
        Me.picSaleItem.Size = New System.Drawing.Size(83, 85)
        Me.picSaleItem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picSaleItem.TabIndex = 26
        Me.picSaleItem.TabStop = False
        '
        'panelSaleLineEntry
        '
        Me.panelSaleLineEntry.BackColor = System.Drawing.Color.WhiteSmoke
        Me.panelSaleLineEntry.CausesValidation = False
        Me.panelSaleLineEntry.Controls.Add(Me.btnSaleItemLineClear2)
        Me.panelSaleLineEntry.Controls.Add(Me.btnSaleItemLineClear)
        Me.panelSaleLineEntry.Controls.Add(Me.btnSaleLineOk)
        Me.panelSaleLineEntry.Controls.Add(Me.txtSaleItemExtension)
        Me.panelSaleLineEntry.Controls.Add(Me.Label9)
        Me.panelSaleLineEntry.Controls.Add(Me.txtSaleItemQty)
        Me.panelSaleLineEntry.Controls.Add(Me.Label8)
        Me.panelSaleLineEntry.Controls.Add(Me.txtSaleItemSellPrice)
        Me.panelSaleLineEntry.Controls.Add(Me.Label7)
        Me.panelSaleLineEntry.Controls.Add(Me.txtSaleItemDescription)
        Me.panelSaleLineEntry.Controls.Add(Me.Label6)
        Me.panelSaleLineEntry.Controls.Add(Me.txtSaleItemSerialNo)
        Me.panelSaleLineEntry.Controls.Add(Me.Label5)
        Me.panelSaleLineEntry.Controls.Add(Me.txtSaleItemBarcode)
        Me.panelSaleLineEntry.Controls.Add(Me.Label14)
        Me.panelSaleLineEntry.Location = New System.Drawing.Point(5, 154)
        Me.panelSaleLineEntry.Name = "panelSaleLineEntry"
        Me.panelSaleLineEntry.Size = New System.Drawing.Size(850, 53)
        Me.panelSaleLineEntry.TabIndex = 2
        Me.panelSaleLineEntry.TabStop = True
        '
        'btnSaleItemLineClear2
        '
        Me.btnSaleItemLineClear2.BackColor = System.Drawing.Color.LavenderBlush
        Me.btnSaleItemLineClear2.CausesValidation = False
        Me.btnSaleItemLineClear2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSaleItemLineClear2.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaleItemLineClear2.ForeColor = System.Drawing.Color.Black
        Me.btnSaleItemLineClear2.Location = New System.Drawing.Point(805, 7)
        Me.btnSaleItemLineClear2.Name = "btnSaleItemLineClear2"
        Me.btnSaleItemLineClear2.Size = New System.Drawing.Size(33, 40)
        Me.btnSaleItemLineClear2.TabIndex = 44
        Me.btnSaleItemLineClear2.Text = "X"
        Me.ToolTip1.SetToolTip(Me.btnSaleItemLineClear2, "Clear this Item Line..")
        Me.btnSaleItemLineClear2.UseVisualStyleBackColor = False
        '
        'btnSaleItemLineClear
        '
        Me.btnSaleItemLineClear.BackColor = System.Drawing.Color.LavenderBlush
        Me.btnSaleItemLineClear.CausesValidation = False
        Me.btnSaleItemLineClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSaleItemLineClear.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaleItemLineClear.ForeColor = System.Drawing.Color.Black
        Me.btnSaleItemLineClear.Location = New System.Drawing.Point(4, 7)
        Me.btnSaleItemLineClear.Name = "btnSaleItemLineClear"
        Me.btnSaleItemLineClear.Size = New System.Drawing.Size(27, 40)
        Me.btnSaleItemLineClear.TabIndex = 0
        Me.btnSaleItemLineClear.TabStop = False
        Me.btnSaleItemLineClear.Text = "X"
        Me.ToolTip1.SetToolTip(Me.btnSaleItemLineClear, "Clear this Item Line..")
        Me.btnSaleItemLineClear.UseVisualStyleBackColor = False
        '
        'btnSaleLineOk
        '
        Me.btnSaleLineOk.BackColor = System.Drawing.Color.Honeydew
        Me.btnSaleLineOk.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSaleLineOk.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaleLineOk.ForeColor = System.Drawing.Color.DarkBlue
        Me.btnSaleLineOk.Location = New System.Drawing.Point(764, 7)
        Me.btnSaleLineOk.Name = "btnSaleLineOk"
        Me.btnSaleLineOk.Size = New System.Drawing.Size(33, 40)
        Me.btnSaleLineOk.TabIndex = 38
        Me.btnSaleLineOk.Text = "OK"
        Me.btnSaleLineOk.UseVisualStyleBackColor = False
        '
        'txtSaleItemExtension
        '
        Me.txtSaleItemExtension.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.txtSaleItemExtension.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSaleItemExtension.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleItemExtension.Location = New System.Drawing.Point(654, 24)
        Me.txtSaleItemExtension.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtSaleItemExtension.MaxLength = 9
        Me.txtSaleItemExtension.Name = "txtSaleItemExtension"
        Me.txtSaleItemExtension.ReadOnly = True
        Me.txtSaleItemExtension.Size = New System.Drawing.Size(100, 26)
        Me.txtSaleItemExtension.TabIndex = 36
        Me.txtSaleItemExtension.TabStop = False
        Me.txtSaleItemExtension.Text = "txtSaleItemExtension"
        Me.txtSaleItemExtension.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(653, 6)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(95, 18)
        Me.Label9.TabIndex = 40
        Me.Label9.Text = "Extension:"
        '
        'txtSaleItemQty
        '
        Me.txtSaleItemQty.BackColor = System.Drawing.Color.White
        Me.txtSaleItemQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSaleItemQty.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleItemQty.Location = New System.Drawing.Point(590, 24)
        Me.txtSaleItemQty.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtSaleItemQty.MaxLength = 4
        Me.txtSaleItemQty.Name = "txtSaleItemQty"
        Me.txtSaleItemQty.Size = New System.Drawing.Size(56, 26)
        Me.txtSaleItemQty.TabIndex = 35
        Me.txtSaleItemQty.Text = "txtSaleItemQty"
        Me.txtSaleItemQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(591, 6)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(55, 18)
        Me.Label8.TabIndex = 38
        Me.Label8.Text = "Qty:"
        '
        'txtSaleItemSellPrice
        '
        Me.txtSaleItemSellPrice.BackColor = System.Drawing.Color.White
        Me.txtSaleItemSellPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSaleItemSellPrice.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleItemSellPrice.Location = New System.Drawing.Point(509, 24)
        Me.txtSaleItemSellPrice.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtSaleItemSellPrice.MaxLength = 9
        Me.txtSaleItemSellPrice.Name = "txtSaleItemSellPrice"
        Me.txtSaleItemSellPrice.Size = New System.Drawing.Size(75, 26)
        Me.txtSaleItemSellPrice.TabIndex = 34
        Me.txtSaleItemSellPrice.Text = "txtSaleItemSellPrice"
        Me.txtSaleItemSellPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(509, 6)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(75, 18)
        Me.Label7.TabIndex = 36
        Me.Label7.Text = "Sell:"
        '
        'txtSaleItemDescription
        '
        Me.txtSaleItemDescription.BackColor = System.Drawing.Color.White
        Me.txtSaleItemDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSaleItemDescription.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleItemDescription.Location = New System.Drawing.Point(283, 24)
        Me.txtSaleItemDescription.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtSaleItemDescription.MaxLength = 60
        Me.txtSaleItemDescription.Name = "txtSaleItemDescription"
        Me.txtSaleItemDescription.ReadOnly = True
        Me.txtSaleItemDescription.Size = New System.Drawing.Size(219, 26)
        Me.txtSaleItemDescription.TabIndex = 33
        Me.txtSaleItemDescription.TabStop = False
        Me.txtSaleItemDescription.Text = "txtSaleItemDescription"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(280, 6)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(175, 18)
        Me.Label6.TabIndex = 33
        Me.Label6.Text = "Description:"
        '
        'txtSaleItemSerialNo
        '
        Me.txtSaleItemSerialNo.BackColor = System.Drawing.Color.White
        Me.txtSaleItemSerialNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSaleItemSerialNo.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleItemSerialNo.Location = New System.Drawing.Point(164, 24)
        Me.txtSaleItemSerialNo.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtSaleItemSerialNo.MaxLength = 40
        Me.txtSaleItemSerialNo.Name = "txtSaleItemSerialNo"
        Me.txtSaleItemSerialNo.Size = New System.Drawing.Size(115, 26)
        Me.txtSaleItemSerialNo.TabIndex = 31
        Me.txtSaleItemSerialNo.Text = "txtSaleItemSerialNo"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(161, 6)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(118, 18)
        Me.Label5.TabIndex = 31
        Me.Label5.Text = "Serial No:"
        '
        'txtSaleItemBarcode
        '
        Me.txtSaleItemBarcode.BackColor = System.Drawing.Color.White
        Me.txtSaleItemBarcode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSaleItemBarcode.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleItemBarcode.Location = New System.Drawing.Point(40, 24)
        Me.txtSaleItemBarcode.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtSaleItemBarcode.MaxLength = 40
        Me.txtSaleItemBarcode.Name = "txtSaleItemBarcode"
        Me.txtSaleItemBarcode.Size = New System.Drawing.Size(118, 26)
        Me.txtSaleItemBarcode.TabIndex = 30
        Me.txtSaleItemBarcode.Text = "txtSaleItemBarcode"
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(41, 6)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(117, 18)
        Me.Label14.TabIndex = 29
        Me.Label14.Text = "Item Barcode: "
        '
        'panelSaleFooter
        '
        Me.panelSaleFooter.BackColor = System.Drawing.Color.WhiteSmoke
        Me.panelSaleFooter.Controls.Add(Me.labSaleHelp2)
        Me.panelSaleFooter.Controls.Add(Me.labSaleHelp)
        Me.panelSaleFooter.Controls.Add(Me.panelPayment)
        Me.panelSaleFooter.Controls.Add(Me.panelSaleTotals)
        Me.panelSaleFooter.Location = New System.Drawing.Point(4, 388)
        Me.panelSaleFooter.Name = "panelSaleFooter"
        Me.panelSaleFooter.Size = New System.Drawing.Size(851, 236)
        Me.panelSaleFooter.TabIndex = 4
        Me.panelSaleFooter.TabStop = True
        '
        'labSaleHelp2
        '
        Me.labSaleHelp2.BackColor = System.Drawing.Color.Transparent
        Me.labSaleHelp2.Location = New System.Drawing.Point(548, 2)
        Me.labSaleHelp2.Name = "labSaleHelp2"
        Me.labSaleHelp2.Padding = New System.Windows.Forms.Padding(3, 3, 0, 0)
        Me.labSaleHelp2.Size = New System.Drawing.Size(129, 30)
        Me.labSaleHelp2.TabIndex = 32
        Me.labSaleHelp2.Text = "labHelp2"
        '
        'labSaleHelp
        '
        Me.labSaleHelp.BackColor = System.Drawing.Color.Transparent
        Me.labSaleHelp.Location = New System.Drawing.Point(702, 2)
        Me.labSaleHelp.Name = "labSaleHelp"
        Me.labSaleHelp.Size = New System.Drawing.Size(138, 30)
        Me.labSaleHelp.TabIndex = 31
        Me.labSaleHelp.Text = "labHelp"
        '
        'panelPayment
        '
        Me.panelPayment.BackColor = System.Drawing.Color.WhiteSmoke
        Me.panelPayment.Controls.Add(Me.grpBoxSalePayments)
        Me.panelPayment.Controls.Add(Me.chkOnAccount)
        Me.panelPayment.Controls.Add(Me.grpBoxRefundType)
        Me.panelPayment.Controls.Add(Me.labSaleChargeBalance)
        Me.panelPayment.Controls.Add(Me.labSaleChange)
        Me.panelPayment.Controls.Add(Me.LabSaleBalance)
        Me.panelPayment.Controls.Add(Me.txtSaleChange)
        Me.panelPayment.Controls.Add(Me.txtSalePaymentBalance)
        Me.panelPayment.Controls.Add(Me.labSaleCrBal)
        Me.panelPayment.Location = New System.Drawing.Point(3, 3)
        Me.panelPayment.Name = "panelPayment"
        Me.panelPayment.Size = New System.Drawing.Size(539, 222)
        Me.panelPayment.TabIndex = 1
        Me.panelPayment.TabStop = True
        '
        'grpBoxSalePayments
        '
        Me.grpBoxSalePayments.BackColor = System.Drawing.Color.AliceBlue
        Me.grpBoxSalePayments.Controls.Add(Me.txtCreditNoteWdl)
        Me.grpBoxSalePayments.Controls.Add(Me.dgvSalePaymentDetails)
        Me.grpBoxSalePayments.Controls.Add(Me.labCreditNoteLab)
        Me.grpBoxSalePayments.Controls.Add(Me.LabSalePayments)
        Me.grpBoxSalePayments.Controls.Add(Me.Label2)
        Me.grpBoxSalePayments.Location = New System.Drawing.Point(7, 1)
        Me.grpBoxSalePayments.Name = "grpBoxSalePayments"
        Me.grpBoxSalePayments.Size = New System.Drawing.Size(247, 215)
        Me.grpBoxSalePayments.TabIndex = 0
        Me.grpBoxSalePayments.TabStop = False
        Me.grpBoxSalePayments.Text = "Sale Paymnts"
        '
        'txtCreditNoteWdl
        '
        Me.txtCreditNoteWdl.BackColor = System.Drawing.SystemColors.Window
        Me.txtCreditNoteWdl.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCreditNoteWdl.Location = New System.Drawing.Point(150, 12)
        Me.txtCreditNoteWdl.MaxLength = 10
        Me.txtCreditNoteWdl.Name = "txtCreditNoteWdl"
        Me.txtCreditNoteWdl.Size = New System.Drawing.Size(86, 26)
        Me.txtCreditNoteWdl.TabIndex = 0
        Me.txtCreditNoteWdl.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dgvSalePaymentDetails
        '
        Me.dgvSalePaymentDetails.AllowUserToAddRows = False
        Me.dgvSalePaymentDetails.AllowUserToDeleteRows = False
        Me.dgvSalePaymentDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvSalePaymentDetails.BackgroundColor = System.Drawing.Color.WhiteSmoke
        Me.dgvSalePaymentDetails.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvSalePaymentDetails.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvSalePaymentDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvSalePaymentDetails.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.PaymentType, Me.Amount, Me.PaymentType_id})
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvSalePaymentDetails.DefaultCellStyle = DataGridViewCellStyle4
        Me.dgvSalePaymentDetails.GridColor = System.Drawing.SystemColors.ControlLight
        Me.dgvSalePaymentDetails.Location = New System.Drawing.Point(2, 40)
        Me.dgvSalePaymentDetails.MultiSelect = False
        Me.dgvSalePaymentDetails.Name = "dgvSalePaymentDetails"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.WhiteSmoke
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvSalePaymentDetails.RowHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.dgvSalePaymentDetails.RowHeadersWidth = 20
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvSalePaymentDetails.RowsDefaultCellStyle = DataGridViewCellStyle6
        Me.dgvSalePaymentDetails.RowTemplate.Height = 17
        Me.dgvSalePaymentDetails.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgvSalePaymentDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.dgvSalePaymentDetails.Size = New System.Drawing.Size(236, 147)
        Me.dgvSalePaymentDetails.StandardTab = True
        Me.dgvSalePaymentDetails.TabIndex = 1
        '
        'PaymentType
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PaymentType.DefaultCellStyle = DataGridViewCellStyle2
        Me.PaymentType.HeaderText = "PaymentType"
        Me.PaymentType.Name = "PaymentType"
        Me.PaymentType.ReadOnly = True
        Me.PaymentType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Amount
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Amount.DefaultCellStyle = DataGridViewCellStyle3
        Me.Amount.FillWeight = 60.0!
        Me.Amount.HeaderText = "Amount"
        Me.Amount.Name = "Amount"
        Me.Amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'PaymentType_id
        '
        Me.PaymentType_id.HeaderText = "PaymentType_id"
        Me.PaymentType_id.Name = "PaymentType_id"
        Me.PaymentType_id.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PaymentType_id.Visible = False
        '
        'labCreditNoteLab
        '
        Me.labCreditNoteLab.BackColor = System.Drawing.Color.GhostWhite
        Me.labCreditNoteLab.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labCreditNoteLab.Location = New System.Drawing.Point(1, 16)
        Me.labCreditNoteLab.Name = "labCreditNoteLab"
        Me.labCreditNoteLab.Size = New System.Drawing.Size(145, 15)
        Me.labCreditNoteLab.TabIndex = 40
        Me.labCreditNoteLab.Text = "Credit Note Amount  to use-"
        Me.labCreditNoteLab.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'LabSalePayments
        '
        Me.LabSalePayments.BackColor = System.Drawing.Color.Lavender
        Me.LabSalePayments.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabSalePayments.ImageAlign = System.Drawing.ContentAlignment.TopRight
        Me.LabSalePayments.Location = New System.Drawing.Point(6, 192)
        Me.LabSalePayments.Name = "LabSalePayments"
        Me.LabSalePayments.Size = New System.Drawing.Size(178, 18)
        Me.LabSalePayments.TabIndex = 7
        Me.LabSalePayments.Text = "-- Till Payments -- "
        Me.LabSalePayments.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Gray
        Me.Label2.Location = New System.Drawing.Point(199, 192)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 12)
        Me.Label2.TabIndex = 39
        Me.Label2.Text = "F2 Edit Cell"
        '
        'chkOnAccount
        '
        Me.chkOnAccount.BackColor = System.Drawing.Color.WhiteSmoke
        Me.chkOnAccount.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkOnAccount.Location = New System.Drawing.Point(268, 15)
        Me.chkOnAccount.Name = "chkOnAccount"
        Me.chkOnAccount.Size = New System.Drawing.Size(86, 40)
        Me.chkOnAccount.TabIndex = 1
        Me.chkOnAccount.Text = "Charge to Account"
        Me.chkOnAccount.UseVisualStyleBackColor = False
        '
        'grpBoxRefundType
        '
        Me.grpBoxRefundType.Controls.Add(Me.cboRefundOtherDetails)
        Me.grpBoxRefundType.Controls.Add(Me.optRefundOther)
        Me.grpBoxRefundType.Controls.Add(Me.optRefundEftPosCr)
        Me.grpBoxRefundType.Controls.Add(Me.optRefundEftPosDr)
        Me.grpBoxRefundType.Controls.Add(Me.optRefundCredit)
        Me.grpBoxRefundType.Controls.Add(Me.optRefundCash)
        Me.grpBoxRefundType.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpBoxRefundType.Location = New System.Drawing.Point(263, 96)
        Me.grpBoxRefundType.Name = "grpBoxRefundType"
        Me.grpBoxRefundType.Size = New System.Drawing.Size(268, 80)
        Me.grpBoxRefundType.TabIndex = 5
        Me.grpBoxRefundType.TabStop = False
        Me.grpBoxRefundType.Text = "RefundType"
        '
        'cboRefundOtherDetails
        '
        Me.cboRefundOtherDetails.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRefundOtherDetails.FormattingEnabled = True
        Me.cboRefundOtherDetails.Location = New System.Drawing.Point(175, 48)
        Me.cboRefundOtherDetails.Name = "cboRefundOtherDetails"
        Me.cboRefundOtherDetails.Size = New System.Drawing.Size(88, 21)
        Me.cboRefundOtherDetails.TabIndex = 5
        '
        'optRefundOther
        '
        Me.optRefundOther.Location = New System.Drawing.Point(183, 19)
        Me.optRefundOther.Name = "optRefundOther"
        Me.optRefundOther.Size = New System.Drawing.Size(56, 15)
        Me.optRefundOther.TabIndex = 4
        Me.optRefundOther.TabStop = True
        Me.optRefundOther.Text = "Other"
        Me.ToolTip1.SetToolTip(Me.optRefundOther, "Other Type- Choose from List.")
        Me.optRefundOther.UseVisualStyleBackColor = True
        '
        'optRefundEftPosCr
        '
        Me.optRefundEftPosCr.Location = New System.Drawing.Point(92, 43)
        Me.optRefundEftPosCr.Name = "optRefundEftPosCr"
        Me.optRefundEftPosCr.Size = New System.Drawing.Size(71, 15)
        Me.optRefundEftPosCr.TabIndex = 3
        Me.optRefundEftPosCr.TabStop = True
        Me.optRefundEftPosCr.Text = "EftPos Cr"
        Me.ToolTip1.SetToolTip(Me.optRefundEftPosCr, "EftPos Cr")
        Me.optRefundEftPosCr.UseVisualStyleBackColor = True
        '
        'optRefundEftPosDr
        '
        Me.optRefundEftPosDr.Location = New System.Drawing.Point(11, 44)
        Me.optRefundEftPosDr.Name = "optRefundEftPosDr"
        Me.optRefundEftPosDr.Size = New System.Drawing.Size(70, 15)
        Me.optRefundEftPosDr.TabIndex = 2
        Me.optRefundEftPosDr.TabStop = True
        Me.optRefundEftPosDr.Text = "EftPos Dr"
        Me.ToolTip1.SetToolTip(Me.optRefundEftPosDr, "EftPosDr")
        Me.optRefundEftPosDr.UseVisualStyleBackColor = True
        '
        'optRefundCredit
        '
        Me.optRefundCredit.Location = New System.Drawing.Point(92, 19)
        Me.optRefundCredit.Name = "optRefundCredit"
        Me.optRefundCredit.Size = New System.Drawing.Size(85, 15)
        Me.optRefundCredit.TabIndex = 1
        Me.optRefundCredit.TabStop = True
        Me.optRefundCredit.Text = "Credit Note"
        Me.ToolTip1.SetToolTip(Me.optRefundCredit, "Credit Note")
        Me.optRefundCredit.UseVisualStyleBackColor = True
        '
        'optRefundCash
        '
        Me.optRefundCash.Location = New System.Drawing.Point(11, 19)
        Me.optRefundCash.Name = "optRefundCash"
        Me.optRefundCash.Size = New System.Drawing.Size(56, 15)
        Me.optRefundCash.TabIndex = 0
        Me.optRefundCash.TabStop = True
        Me.optRefundCash.Text = "Cash"
        Me.optRefundCash.UseVisualStyleBackColor = True
        '
        'labSaleChargeBalance
        '
        Me.labSaleChargeBalance.BackColor = System.Drawing.Color.WhiteSmoke
        Me.labSaleChargeBalance.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labSaleChargeBalance.Location = New System.Drawing.Point(264, 59)
        Me.labSaleChargeBalance.Name = "labSaleChargeBalance"
        Me.labSaleChargeBalance.Padding = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.labSaleChargeBalance.Size = New System.Drawing.Size(233, 33)
        Me.labSaleChargeBalance.TabIndex = 3
        Me.labSaleChargeBalance.Text = "labSaleChargeBalance"
        '
        'labSaleChange
        '
        Me.labSaleChange.BackColor = System.Drawing.Color.Transparent
        Me.labSaleChange.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labSaleChange.Location = New System.Drawing.Point(267, 191)
        Me.labSaleChange.Name = "labSaleChange"
        Me.labSaleChange.Size = New System.Drawing.Size(110, 20)
        Me.labSaleChange.TabIndex = 37
        Me.labSaleChange.Text = "Change/Refund:"
        Me.labSaleChange.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'LabSaleBalance
        '
        Me.LabSaleBalance.BackColor = System.Drawing.Color.Transparent
        Me.LabSaleBalance.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabSaleBalance.Location = New System.Drawing.Point(376, 10)
        Me.LabSaleBalance.Name = "LabSaleBalance"
        Me.LabSaleBalance.Size = New System.Drawing.Size(58, 19)
        Me.LabSaleBalance.TabIndex = 12
        Me.LabSaleBalance.Text = "Balance:"
        Me.LabSaleBalance.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'txtSaleChange
        '
        Me.txtSaleChange.BackColor = System.Drawing.Color.Lavender
        Me.txtSaleChange.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSaleChange.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleChange.Location = New System.Drawing.Point(377, 190)
        Me.txtSaleChange.Name = "txtSaleChange"
        Me.txtSaleChange.ReadOnly = True
        Me.txtSaleChange.Size = New System.Drawing.Size(154, 21)
        Me.txtSaleChange.TabIndex = 4
        Me.txtSaleChange.TabStop = False
        Me.txtSaleChange.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtSalePaymentBalance
        '
        Me.txtSalePaymentBalance.BackColor = System.Drawing.Color.Lavender
        Me.txtSalePaymentBalance.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSalePaymentBalance.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSalePaymentBalance.Location = New System.Drawing.Point(377, 32)
        Me.txtSalePaymentBalance.Name = "txtSalePaymentBalance"
        Me.txtSalePaymentBalance.ReadOnly = True
        Me.txtSalePaymentBalance.Size = New System.Drawing.Size(95, 19)
        Me.txtSalePaymentBalance.TabIndex = 2
        Me.txtSalePaymentBalance.TabStop = False
        Me.txtSalePaymentBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'labSaleCrBal
        '
        Me.labSaleCrBal.BackColor = System.Drawing.Color.Lavender
        Me.labSaleCrBal.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labSaleCrBal.Location = New System.Drawing.Point(474, 33)
        Me.labSaleCrBal.Name = "labSaleCrBal"
        Me.labSaleCrBal.Size = New System.Drawing.Size(28, 19)
        Me.labSaleCrBal.TabIndex = 32
        Me.labSaleCrBal.Text = "CR"
        '
        'panelSaleTotals
        '
        Me.panelSaleTotals.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.panelSaleTotals.Controls.Add(Me.btnDiscountPC)
        Me.panelSaleTotals.Controls.Add(Me.cboSaleDiscountPercent)
        Me.panelSaleTotals.Controls.Add(Me.txtSaleSubTotal2)
        Me.panelSaleTotals.Controls.Add(Me.LabSaleSubTotal2)
        Me.panelSaleTotals.Controls.Add(Me.txtSaleNettTax)
        Me.panelSaleTotals.Controls.Add(Me.LabSaleNettTax)
        Me.panelSaleTotals.Controls.Add(Me.LabSaleDiscAnalysis)
        Me.panelSaleTotals.Controls.Add(Me.txtSaleDiscountAnalysis)
        Me.panelSaleTotals.Controls.Add(Me.LabSaleIncludesTax)
        Me.panelSaleTotals.Controls.Add(Me.txtSaleTotalTax)
        Me.panelSaleTotals.Controls.Add(Me.txtSaleSubTotal)
        Me.panelSaleTotals.Controls.Add(Me.LabSaleSubTotal)
        Me.panelSaleTotals.Controls.Add(Me.LabSaleDiscount)
        Me.panelSaleTotals.Controls.Add(Me.txtSaleDiscount)
        Me.panelSaleTotals.Controls.Add(Me.txtSaleRounding)
        Me.panelSaleTotals.Controls.Add(Me.LabSaleRounding)
        Me.panelSaleTotals.Controls.Add(Me.LabSaleInvTotal)
        Me.panelSaleTotals.Controls.Add(Me.txtSaleTotal)
        Me.panelSaleTotals.Location = New System.Drawing.Point(548, 37)
        Me.panelSaleTotals.Name = "panelSaleTotals"
        Me.panelSaleTotals.Size = New System.Drawing.Size(298, 188)
        Me.panelSaleTotals.TabIndex = 0
        Me.panelSaleTotals.TabStop = True
        '
        'btnDiscountPC
        '
        Me.btnDiscountPC.Enabled = False
        Me.btnDiscountPC.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDiscountPC.Location = New System.Drawing.Point(204, 37)
        Me.btnDiscountPC.Name = "btnDiscountPC"
        Me.btnDiscountPC.Size = New System.Drawing.Size(25, 23)
        Me.btnDiscountPC.TabIndex = 1
        Me.btnDiscountPC.TabStop = False
        Me.btnDiscountPC.Text = "%"
        Me.btnDiscountPC.UseVisualStyleBackColor = True
        '
        'cboSaleDiscountPercent
        '
        Me.cboSaleDiscountPercent.BackColor = System.Drawing.Color.AliceBlue
        Me.cboSaleDiscountPercent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSaleDiscountPercent.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboSaleDiscountPercent.FormattingEnabled = True
        Me.cboSaleDiscountPercent.Location = New System.Drawing.Point(233, 37)
        Me.cboSaleDiscountPercent.Name = "cboSaleDiscountPercent"
        Me.cboSaleDiscountPercent.Size = New System.Drawing.Size(47, 21)
        Me.cboSaleDiscountPercent.TabIndex = 2
        Me.cboSaleDiscountPercent.TabStop = False
        '
        'txtSaleSubTotal2
        '
        Me.txtSaleSubTotal2.BackColor = System.Drawing.Color.LightGray
        Me.txtSaleSubTotal2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSaleSubTotal2.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleSubTotal2.Location = New System.Drawing.Point(127, 88)
        Me.txtSaleSubTotal2.Name = "txtSaleSubTotal2"
        Me.txtSaleSubTotal2.ReadOnly = True
        Me.txtSaleSubTotal2.Size = New System.Drawing.Size(117, 15)
        Me.txtSaleSubTotal2.TabIndex = 37
        Me.txtSaleSubTotal2.TabStop = False
        Me.txtSaleSubTotal2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LabSaleSubTotal2
        '
        Me.LabSaleSubTotal2.Location = New System.Drawing.Point(41, 89)
        Me.LabSaleSubTotal2.Name = "LabSaleSubTotal2"
        Me.LabSaleSubTotal2.Size = New System.Drawing.Size(58, 14)
        Me.LabSaleSubTotal2.TabIndex = 39
        Me.LabSaleSubTotal2.Text = "Total:"
        Me.LabSaleSubTotal2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtSaleNettTax
        '
        Me.txtSaleNettTax.BackColor = System.Drawing.Color.LightGray
        Me.txtSaleNettTax.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSaleNettTax.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleNettTax.ForeColor = System.Drawing.Color.Gray
        Me.txtSaleNettTax.Location = New System.Drawing.Point(127, 110)
        Me.txtSaleNettTax.Name = "txtSaleNettTax"
        Me.txtSaleNettTax.ReadOnly = True
        Me.txtSaleNettTax.Size = New System.Drawing.Size(117, 15)
        Me.txtSaleNettTax.TabIndex = 38
        Me.txtSaleNettTax.TabStop = False
        Me.txtSaleNettTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LabSaleNettTax
        '
        Me.LabSaleNettTax.Location = New System.Drawing.Point(30, 111)
        Me.LabSaleNettTax.Name = "LabSaleNettTax"
        Me.LabSaleNettTax.Size = New System.Drawing.Size(68, 14)
        Me.LabSaleNettTax.TabIndex = 37
        Me.LabSaleNettTax.Text = "(Nett Tax:)"
        Me.LabSaleNettTax.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LabSaleDiscAnalysis
        '
        Me.LabSaleDiscAnalysis.ForeColor = System.Drawing.Color.Gray
        Me.LabSaleDiscAnalysis.Location = New System.Drawing.Point(22, 60)
        Me.LabSaleDiscAnalysis.Name = "LabSaleDiscAnalysis"
        Me.LabSaleDiscAnalysis.Size = New System.Drawing.Size(79, 14)
        Me.LabSaleDiscAnalysis.TabIndex = 36
        Me.LabSaleDiscAnalysis.Text = "(-Items/Tax)"
        Me.LabSaleDiscAnalysis.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtSaleDiscountAnalysis
        '
        Me.txtSaleDiscountAnalysis.BackColor = System.Drawing.Color.LightGray
        Me.txtSaleDiscountAnalysis.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSaleDiscountAnalysis.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleDiscountAnalysis.ForeColor = System.Drawing.Color.Gray
        Me.txtSaleDiscountAnalysis.Location = New System.Drawing.Point(127, 59)
        Me.txtSaleDiscountAnalysis.Name = "txtSaleDiscountAnalysis"
        Me.txtSaleDiscountAnalysis.ReadOnly = True
        Me.txtSaleDiscountAnalysis.Size = New System.Drawing.Size(117, 12)
        Me.txtSaleDiscountAnalysis.TabIndex = 35
        Me.txtSaleDiscountAnalysis.TabStop = False
        Me.txtSaleDiscountAnalysis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LabSaleIncludesTax
        '
        Me.LabSaleIncludesTax.ForeColor = System.Drawing.Color.Gray
        Me.LabSaleIncludesTax.Location = New System.Drawing.Point(19, 7)
        Me.LabSaleIncludesTax.Name = "LabSaleIncludesTax"
        Me.LabSaleIncludesTax.Size = New System.Drawing.Size(82, 14)
        Me.LabSaleIncludesTax.TabIndex = 32
        Me.LabSaleIncludesTax.Text = "(Includes Tax)"
        Me.LabSaleIncludesTax.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtSaleTotalTax
        '
        Me.txtSaleTotalTax.BackColor = System.Drawing.Color.LightGray
        Me.txtSaleTotalTax.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSaleTotalTax.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleTotalTax.ForeColor = System.Drawing.Color.Gray
        Me.txtSaleTotalTax.Location = New System.Drawing.Point(127, 6)
        Me.txtSaleTotalTax.Name = "txtSaleTotalTax"
        Me.txtSaleTotalTax.ReadOnly = True
        Me.txtSaleTotalTax.Size = New System.Drawing.Size(117, 13)
        Me.txtSaleTotalTax.TabIndex = 31
        Me.txtSaleTotalTax.TabStop = False
        Me.txtSaleTotalTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtSaleSubTotal
        '
        Me.txtSaleSubTotal.BackColor = System.Drawing.Color.LightGray
        Me.txtSaleSubTotal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSaleSubTotal.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleSubTotal.Location = New System.Drawing.Point(127, 22)
        Me.txtSaleSubTotal.Name = "txtSaleSubTotal"
        Me.txtSaleSubTotal.ReadOnly = True
        Me.txtSaleSubTotal.Size = New System.Drawing.Size(117, 15)
        Me.txtSaleSubTotal.TabIndex = 32
        Me.txtSaleSubTotal.TabStop = False
        Me.txtSaleSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LabSaleSubTotal
        '
        Me.LabSaleSubTotal.Location = New System.Drawing.Point(41, 23)
        Me.LabSaleSubTotal.Name = "LabSaleSubTotal"
        Me.LabSaleSubTotal.Size = New System.Drawing.Size(58, 14)
        Me.LabSaleSubTotal.TabIndex = 14
        Me.LabSaleSubTotal.Text = "Sub-total:"
        Me.LabSaleSubTotal.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LabSaleDiscount
        '
        Me.LabSaleDiscount.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabSaleDiscount.Location = New System.Drawing.Point(30, 41)
        Me.LabSaleDiscount.Name = "LabSaleDiscount"
        Me.LabSaleDiscount.Size = New System.Drawing.Size(57, 14)
        Me.LabSaleDiscount.TabIndex = 16
        Me.LabSaleDiscount.Text = "Discount "
        Me.LabSaleDiscount.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtSaleDiscount
        '
        Me.txtSaleDiscount.BackColor = System.Drawing.SystemColors.Window
        Me.txtSaleDiscount.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSaleDiscount.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleDiscount.Location = New System.Drawing.Point(129, 43)
        Me.txtSaleDiscount.Name = "txtSaleDiscount"
        Me.txtSaleDiscount.Size = New System.Drawing.Size(69, 15)
        Me.txtSaleDiscount.TabIndex = 0
        Me.txtSaleDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtSaleRounding
        '
        Me.txtSaleRounding.BackColor = System.Drawing.Color.LightGray
        Me.txtSaleRounding.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSaleRounding.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleRounding.Location = New System.Drawing.Point(127, 136)
        Me.txtSaleRounding.Name = "txtSaleRounding"
        Me.txtSaleRounding.ReadOnly = True
        Me.txtSaleRounding.Size = New System.Drawing.Size(117, 15)
        Me.txtSaleRounding.TabIndex = 39
        Me.txtSaleRounding.TabStop = False
        Me.txtSaleRounding.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LabSaleRounding
        '
        Me.LabSaleRounding.Location = New System.Drawing.Point(41, 136)
        Me.LabSaleRounding.Name = "LabSaleRounding"
        Me.LabSaleRounding.Size = New System.Drawing.Size(58, 14)
        Me.LabSaleRounding.TabIndex = 20
        Me.LabSaleRounding.Text = "Rounding:"
        Me.LabSaleRounding.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LabSaleInvTotal
        '
        Me.LabSaleInvTotal.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabSaleInvTotal.Location = New System.Drawing.Point(16, 159)
        Me.LabSaleInvTotal.Margin = New System.Windows.Forms.Padding(0)
        Me.LabSaleInvTotal.Name = "LabSaleInvTotal"
        Me.LabSaleInvTotal.Size = New System.Drawing.Size(85, 14)
        Me.LabSaleInvTotal.TabIndex = 21
        Me.LabSaleInvTotal.Text = "Invoice Total:"
        Me.LabSaleInvTotal.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtSaleTotal
        '
        Me.txtSaleTotal.BackColor = System.Drawing.Color.LightGray
        Me.txtSaleTotal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSaleTotal.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleTotal.Location = New System.Drawing.Point(127, 158)
        Me.txtSaleTotal.Name = "txtSaleTotal"
        Me.txtSaleTotal.ReadOnly = True
        Me.txtSaleTotal.Size = New System.Drawing.Size(117, 15)
        Me.txtSaleTotal.TabIndex = 40
        Me.txtSaleTotal.TabStop = False
        Me.txtSaleTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dgvSaleItems
        '
        Me.dgvSaleItems.AllowUserToAddRows = False
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.WhiteSmoke
        Me.dgvSaleItems.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle7
        Me.dgvSaleItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvSaleItems.BackgroundColor = System.Drawing.Color.WhiteSmoke
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvSaleItems.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle8
        Me.dgvSaleItems.ColumnHeadersHeight = 22
        Me.dgvSaleItems.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Barcode, Me.SerialNo, Me.Cat1, Me.Cat2, Me.Description, Me.Tax, Me.Sell_inc, Me.Sell_Actual_inc, Me.Qty, Me.SellActual_Inc_Extended, Me.Stock_id, Me.Track_serial, Me.SERIAL_AUDIT_ID, Me.isServiceItem, Me.Cost_Ex, Me.Cost_Inc, Me.Sell_ex, Me.SellActual_Ex, Me.SellActual_Tax, Me.SellActual_Ex_Extended, Me.SellActual_tax_Extended})
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvSaleItems.DefaultCellStyle = DataGridViewCellStyle13
        Me.dgvSaleItems.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.dgvSaleItems.GridColor = System.Drawing.SystemColors.ControlLight
        Me.dgvSaleItems.Location = New System.Drawing.Point(4, 209)
        Me.dgvSaleItems.MultiSelect = False
        Me.dgvSaleItems.Name = "dgvSaleItems"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.Color.Gainsboro
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle14.Padding = New System.Windows.Forms.Padding(2, 0, 0, 0)
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvSaleItems.RowHeadersDefaultCellStyle = DataGridViewCellStyle14
        Me.dgvSaleItems.RowHeadersWidth = 31
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvSaleItems.RowsDefaultCellStyle = DataGridViewCellStyle15
        Me.dgvSaleItems.RowTemplate.Height = 17
        Me.dgvSaleItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvSaleItems.Size = New System.Drawing.Size(851, 173)
        Me.dgvSaleItems.TabIndex = 3
        Me.dgvSaleItems.TabStop = False
        Me.ToolTip1.SetToolTip(Me.dgvSaleItems, "NB- You can click on any item in the Grid to re-edit the item..")
        '
        'panelSaleHdr
        '
        Me.panelSaleHdr.BackColor = System.Drawing.Color.WhiteSmoke
        Me.panelSaleHdr.CausesValidation = False
        Me.panelSaleHdr.Controls.Add(Me.labSaleCustTags)
        Me.panelSaleHdr.Controls.Add(Me.chkOnAccount2)
        Me.panelSaleHdr.Controls.Add(Me.Label4)
        Me.panelSaleHdr.Controls.Add(Me.labSaleStaffName)
        Me.panelSaleHdr.Controls.Add(Me.listViewSaleAvailCredit)
        Me.panelSaleHdr.Controls.Add(Me.txtSaleStaffBarcode)
        Me.panelSaleHdr.Controls.Add(Me.labSaleStaff)
        Me.panelSaleHdr.Controls.Add(Me.labSaleTranType)
        Me.panelSaleHdr.Controls.Add(Me.Label22)
        Me.panelSaleHdr.Controls.Add(Me.btnCancelSale2)
        Me.panelSaleHdr.Controls.Add(Me.panelOptTranType)
        Me.panelSaleHdr.Controls.Add(Me.panelSaleInvoiceList)
        Me.panelSaleHdr.Controls.Add(Me.txtSaleJobNo)
        Me.panelSaleHdr.Controls.Add(Me.labSaleJobDelivery)
        Me.panelSaleHdr.Controls.Add(Me.txtSaleCustName)
        Me.panelSaleHdr.Controls.Add(Me.LabSaleCust)
        Me.panelSaleHdr.Controls.Add(Me.txtSaleCustBarcode)
        Me.panelSaleHdr.Location = New System.Drawing.Point(4, 5)
        Me.panelSaleHdr.Name = "panelSaleHdr"
        Me.panelSaleHdr.Size = New System.Drawing.Size(851, 147)
        Me.panelSaleHdr.TabIndex = 1
        Me.panelSaleHdr.TabStop = True
        '
        'labSaleCustTags
        '
        Me.labSaleCustTags.BackColor = System.Drawing.Color.Snow
        Me.labSaleCustTags.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labSaleCustTags.ForeColor = System.Drawing.Color.Blue
        Me.labSaleCustTags.Location = New System.Drawing.Point(312, 69)
        Me.labSaleCustTags.Name = "labSaleCustTags"
        Me.labSaleCustTags.Padding = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.labSaleCustTags.Size = New System.Drawing.Size(222, 32)
        Me.labSaleCustTags.TabIndex = 87
        Me.labSaleCustTags.Text = "labSaleCustTags"
        '
        'chkOnAccount2
        '
        Me.chkOnAccount2.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.chkOnAccount2.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkOnAccount2.Location = New System.Drawing.Point(319, 112)
        Me.chkOnAccount2.Name = "chkOnAccount2"
        Me.chkOnAccount2.Size = New System.Drawing.Size(83, 30)
        Me.chkOnAccount2.TabIndex = 3
        Me.chkOnAccount2.Text = "Charge to Account"
        Me.chkOnAccount2.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.LightYellow
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.GrayText
        Me.Label4.Location = New System.Drawing.Point(742, 4)
        Me.Label4.Name = "Label4"
        Me.Label4.Padding = New System.Windows.Forms.Padding(3, 1, 0, 0)
        Me.Label4.Size = New System.Drawing.Size(103, 27)
        Me.Label4.TabIndex = 53
        Me.Label4.Text = "To See/print the Last Transaction..."
        Me.ToolTip1.SetToolTip(Me.Label4, "To See/print Last Trans., " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "  Goto the Till Dropdown on Main Toolbar.")
        '
        'labSaleStaffName
        '
        Me.labSaleStaffName.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.labSaleStaffName.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labSaleStaffName.Location = New System.Drawing.Point(101, 51)
        Me.labSaleStaffName.Name = "labSaleStaffName"
        Me.labSaleStaffName.Size = New System.Drawing.Size(82, 18)
        Me.labSaleStaffName.TabIndex = 52
        Me.labSaleStaffName.Text = "labSaleStaffName"
        '
        'listViewSaleAvailCredit
        '
        Me.listViewSaleAvailCredit.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.listViewSaleAvailCredit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.listViewSaleAvailCredit.CausesValidation = False
        Me.listViewSaleAvailCredit.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.itemLabel, Me.itemValue})
        Me.listViewSaleAvailCredit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.listViewSaleAvailCredit.GridLines = True
        Me.listViewSaleAvailCredit.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.listViewSaleAvailCredit.Location = New System.Drawing.Point(551, 10)
        Me.listViewSaleAvailCredit.MultiSelect = False
        Me.listViewSaleAvailCredit.Name = "listViewSaleAvailCredit"
        Me.listViewSaleAvailCredit.Size = New System.Drawing.Size(179, 49)
        Me.listViewSaleAvailCredit.TabIndex = 24
        Me.listViewSaleAvailCredit.TabStop = False
        Me.listViewSaleAvailCredit.UseCompatibleStateImageBehavior = False
        Me.listViewSaleAvailCredit.View = System.Windows.Forms.View.Details
        '
        'itemLabel
        '
        Me.itemLabel.Text = "Item"
        Me.itemLabel.Width = 76
        '
        'itemValue
        '
        Me.itemValue.Text = "Value"
        Me.itemValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.itemValue.Width = 84
        '
        'txtSaleStaffBarcode
        '
        Me.txtSaleStaffBarcode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSaleStaffBarcode.CausesValidation = False
        Me.txtSaleStaffBarcode.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleStaffBarcode.Location = New System.Drawing.Point(107, 29)
        Me.txtSaleStaffBarcode.Name = "txtSaleStaffBarcode"
        Me.txtSaleStaffBarcode.Size = New System.Drawing.Size(55, 21)
        Me.txtSaleStaffBarcode.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtSaleStaffBarcode, "Staff Barcode-    This transaction.")
        '
        'labSaleStaff
        '
        Me.labSaleStaff.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labSaleStaff.ForeColor = System.Drawing.Color.Blue
        Me.labSaleStaff.Location = New System.Drawing.Point(104, 12)
        Me.labSaleStaff.Name = "labSaleStaff"
        Me.labSaleStaff.Size = New System.Drawing.Size(55, 13)
        Me.labSaleStaff.TabIndex = 51
        Me.labSaleStaff.Text = "Staff"
        Me.ToolTip1.SetToolTip(Me.labSaleStaff, "Enter customer barcode, ot press ""Lookup""..")
        '
        'labSaleTranType
        '
        Me.labSaleTranType.Font = New System.Drawing.Font("Tahoma", 16.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labSaleTranType.Location = New System.Drawing.Point(10, 87)
        Me.labSaleTranType.Name = "labSaleTranType"
        Me.labSaleTranType.Size = New System.Drawing.Size(81, 57)
        Me.labSaleTranType.TabIndex = 0
        Me.labSaleTranType.Text = "Sale"
        Me.labSaleTranType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.SaddleBrown
        Me.Label22.Location = New System.Drawing.Point(10, 10)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(79, 79)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Sales, Refunds, Quotes, Layby's"
        '
        'btnCancelSale2
        '
        Me.btnCancelSale2.BackColor = System.Drawing.Color.LavenderBlush
        Me.btnCancelSale2.CausesValidation = False
        Me.btnCancelSale2.FlatAppearance.BorderColor = System.Drawing.Color.Gray
        Me.btnCancelSale2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCancelSale2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancelSale2.Location = New System.Drawing.Point(411, 111)
        Me.btnCancelSale2.Name = "btnCancelSale2"
        Me.btnCancelSale2.Size = New System.Drawing.Size(63, 29)
        Me.btnCancelSale2.TabIndex = 4
        Me.btnCancelSale2.TabStop = False
        Me.btnCancelSale2.Text = "Cancel"
        Me.ToolTip1.SetToolTip(Me.btnCancelSale2, "Cancel this Transaction and Clear..")
        Me.btnCancelSale2.UseVisualStyleBackColor = False
        '
        'panelOptTranType
        '
        Me.panelOptTranType.BackColor = System.Drawing.Color.Transparent
        Me.panelOptTranType.Controls.Add(Me.labImportQuote)
        Me.panelOptTranType.Controls.Add(Me.optSaleLayby)
        Me.panelOptTranType.Controls.Add(Me.optSaleQuote)
        Me.panelOptTranType.Controls.Add(Me.optSaleRefund)
        Me.panelOptTranType.Controls.Add(Me.optSaleSale)
        Me.panelOptTranType.Controls.Add(Me.Label10)
        Me.panelOptTranType.Location = New System.Drawing.Point(95, 74)
        Me.panelOptTranType.Name = "panelOptTranType"
        Me.panelOptTranType.Size = New System.Drawing.Size(205, 70)
        Me.panelOptTranType.TabIndex = 2
        Me.panelOptTranType.TabStop = True
        '
        'labImportQuote
        '
        Me.labImportQuote.BackColor = System.Drawing.Color.BlanchedAlmond
        Me.labImportQuote.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labImportQuote.Location = New System.Drawing.Point(152, 26)
        Me.labImportQuote.Name = "labImportQuote"
        Me.labImportQuote.Size = New System.Drawing.Size(43, 40)
        Me.labImportQuote.TabIndex = 5
        Me.labImportQuote.Text = "Import Quote"
        Me.labImportQuote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.labImportQuote, "Click to Import (Convert) Quote into Sale..")
        '
        'optSaleLayby
        '
        Me.optSaleLayby.Appearance = System.Windows.Forms.Appearance.Button
        Me.optSaleLayby.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.optSaleLayby.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optSaleLayby.Location = New System.Drawing.Point(82, 43)
        Me.optSaleLayby.Name = "optSaleLayby"
        Me.optSaleLayby.Padding = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.optSaleLayby.Size = New System.Drawing.Size(60, 23)
        Me.optSaleLayby.TabIndex = 3
        Me.optSaleLayby.TabStop = True
        Me.optSaleLayby.Text = "Layby"
        Me.ToolTip1.SetToolTip(Me.optSaleLayby, "Make New Layby")
        Me.optSaleLayby.UseVisualStyleBackColor = False
        '
        'optSaleQuote
        '
        Me.optSaleQuote.Appearance = System.Windows.Forms.Appearance.Button
        Me.optSaleQuote.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.optSaleQuote.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optSaleQuote.Location = New System.Drawing.Point(8, 43)
        Me.optSaleQuote.Name = "optSaleQuote"
        Me.optSaleQuote.Padding = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.optSaleQuote.Size = New System.Drawing.Size(60, 23)
        Me.optSaleQuote.TabIndex = 2
        Me.optSaleQuote.TabStop = True
        Me.optSaleQuote.Text = "Quote"
        Me.optSaleQuote.UseVisualStyleBackColor = False
        '
        'optSaleRefund
        '
        Me.optSaleRefund.Appearance = System.Windows.Forms.Appearance.Button
        Me.optSaleRefund.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.optSaleRefund.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optSaleRefund.Location = New System.Drawing.Point(82, 17)
        Me.optSaleRefund.Name = "optSaleRefund"
        Me.optSaleRefund.Padding = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.optSaleRefund.Size = New System.Drawing.Size(60, 23)
        Me.optSaleRefund.TabIndex = 1
        Me.optSaleRefund.TabStop = True
        Me.optSaleRefund.Text = "Refund"
        Me.optSaleRefund.UseVisualStyleBackColor = False
        '
        'optSaleSale
        '
        Me.optSaleSale.Appearance = System.Windows.Forms.Appearance.Button
        Me.optSaleSale.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.optSaleSale.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optSaleSale.Location = New System.Drawing.Point(8, 16)
        Me.optSaleSale.Name = "optSaleSale"
        Me.optSaleSale.Padding = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.optSaleSale.Size = New System.Drawing.Size(60, 23)
        Me.optSaleSale.TabIndex = 0
        Me.optSaleSale.TabStop = True
        Me.optSaleSale.Text = "Sale"
        Me.optSaleSale.UseVisualStyleBackColor = False
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(9, 1)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(133, 13)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Select Trans., Press Enter ."
        '
        'panelSaleInvoiceList
        '
        Me.panelSaleInvoiceList.CausesValidation = False
        Me.panelSaleInvoiceList.Controls.Add(Me.btnSaleSelectLayby)
        Me.panelSaleInvoiceList.Controls.Add(Me.btnSaleSelectQuote)
        Me.panelSaleInvoiceList.Controls.Add(Me.btnSaleSelectInvoice)
        Me.panelSaleInvoiceList.Controls.Add(Me.LabSalePrevious)
        Me.panelSaleInvoiceList.Location = New System.Drawing.Point(752, 34)
        Me.panelSaleInvoiceList.Name = "panelSaleInvoiceList"
        Me.panelSaleInvoiceList.Size = New System.Drawing.Size(91, 107)
        Me.panelSaleInvoiceList.TabIndex = 8
        '
        'btnSaleSelectLayby
        '
        Me.btnSaleSelectLayby.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnSaleSelectLayby.CausesValidation = False
        Me.btnSaleSelectLayby.Location = New System.Drawing.Point(24, 78)
        Me.btnSaleSelectLayby.Name = "btnSaleSelectLayby"
        Me.btnSaleSelectLayby.Size = New System.Drawing.Size(57, 21)
        Me.btnSaleSelectLayby.TabIndex = 2
        Me.btnSaleSelectLayby.TabStop = False
        Me.btnSaleSelectLayby.Text = "Layby's"
        Me.btnSaleSelectLayby.UseVisualStyleBackColor = False
        '
        'btnSaleSelectQuote
        '
        Me.btnSaleSelectQuote.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnSaleSelectQuote.CausesValidation = False
        Me.btnSaleSelectQuote.Location = New System.Drawing.Point(24, 50)
        Me.btnSaleSelectQuote.Name = "btnSaleSelectQuote"
        Me.btnSaleSelectQuote.Size = New System.Drawing.Size(57, 21)
        Me.btnSaleSelectQuote.TabIndex = 1
        Me.btnSaleSelectQuote.TabStop = False
        Me.btnSaleSelectQuote.Text = "Quotes"
        Me.btnSaleSelectQuote.UseVisualStyleBackColor = False
        '
        'btnSaleSelectInvoice
        '
        Me.btnSaleSelectInvoice.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnSaleSelectInvoice.CausesValidation = False
        Me.btnSaleSelectInvoice.Location = New System.Drawing.Point(24, 23)
        Me.btnSaleSelectInvoice.Name = "btnSaleSelectInvoice"
        Me.btnSaleSelectInvoice.Size = New System.Drawing.Size(57, 21)
        Me.btnSaleSelectInvoice.TabIndex = 0
        Me.btnSaleSelectInvoice.Text = "Invoices"
        Me.btnSaleSelectInvoice.UseVisualStyleBackColor = False
        '
        'LabSalePrevious
        '
        Me.LabSalePrevious.Location = New System.Drawing.Point(9, 5)
        Me.LabSalePrevious.Name = "LabSalePrevious"
        Me.LabSalePrevious.Size = New System.Drawing.Size(65, 16)
        Me.LabSalePrevious.TabIndex = 30
        Me.LabSalePrevious.Text = "Previous:"
        Me.LabSalePrevious.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ToolTip1.SetToolTip(Me.LabSalePrevious, "Show previous sales this Customer..")
        '
        'txtSaleJobNo
        '
        Me.txtSaleJobNo.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.txtSaleJobNo.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSaleJobNo.CausesValidation = False
        Me.txtSaleJobNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleJobNo.Location = New System.Drawing.Point(548, 112)
        Me.txtSaleJobNo.Multiline = True
        Me.txtSaleJobNo.Name = "txtSaleJobNo"
        Me.txtSaleJobNo.ReadOnly = True
        Me.txtSaleJobNo.Size = New System.Drawing.Size(192, 24)
        Me.txtSaleJobNo.TabIndex = 10
        Me.txtSaleJobNo.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtSaleJobNo, "Delivering Job No.")
        '
        'labSaleJobDelivery
        '
        Me.labSaleJobDelivery.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labSaleJobDelivery.ForeColor = System.Drawing.Color.DarkBlue
        Me.labSaleJobDelivery.Location = New System.Drawing.Point(485, 105)
        Me.labSaleJobDelivery.Name = "labSaleJobDelivery"
        Me.labSaleJobDelivery.Size = New System.Drawing.Size(57, 36)
        Me.labSaleJobDelivery.TabIndex = 27
        Me.labSaleJobDelivery.Text = "Delivering Job:"
        Me.labSaleJobDelivery.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtSaleCustName
        '
        Me.txtSaleCustName.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.txtSaleCustName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSaleCustName.CausesValidation = False
        Me.txtSaleCustName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleCustName.Location = New System.Drawing.Point(310, 10)
        Me.txtSaleCustName.Multiline = True
        Me.txtSaleCustName.Name = "txtSaleCustName"
        Me.txtSaleCustName.ReadOnly = True
        Me.txtSaleCustName.Size = New System.Drawing.Size(228, 56)
        Me.txtSaleCustName.TabIndex = 50
        Me.txtSaleCustName.TabStop = False
        '
        'LabSaleCust
        '
        Me.LabSaleCust.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabSaleCust.ForeColor = System.Drawing.Color.MediumBlue
        Me.LabSaleCust.Location = New System.Drawing.Point(200, 12)
        Me.LabSaleCust.Name = "LabSaleCust"
        Me.LabSaleCust.Size = New System.Drawing.Size(67, 13)
        Me.LabSaleCust.TabIndex = 1
        Me.LabSaleCust.Text = "Customer:"
        Me.ToolTip1.SetToolTip(Me.LabSaleCust, "Enter customer barcode, ot press ""Lookup""..")
        '
        'txtSaleCustBarcode
        '
        Me.txtSaleCustBarcode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSaleCustBarcode.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleCustBarcode.Location = New System.Drawing.Point(203, 29)
        Me.txtSaleCustBarcode.Name = "txtSaleCustBarcode"
        Me.txtSaleCustBarcode.Size = New System.Drawing.Size(55, 21)
        Me.txtSaleCustBarcode.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.txtSaleCustBarcode, "Customer Barcode-   " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "--  F2 to Search." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "--  F3 Same Customer." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "--  F5 Add New Cu" & _
        "stomer." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'ToolTip1
        '
        Me.ToolTip1.AutoPopDelay = 7000
        Me.ToolTip1.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.ToolTip1.InitialDelay = 300
        Me.ToolTip1.ReshowDelay = 100
        '
        'Barcode
        '
        Me.Barcode.FillWeight = 90.0!
        Me.Barcode.HeaderText = "Barcode"
        Me.Barcode.Name = "Barcode"
        Me.Barcode.ReadOnly = True
        '
        'SerialNo
        '
        Me.SerialNo.FillWeight = 94.86343!
        Me.SerialNo.HeaderText = "Serial No"
        Me.SerialNo.Name = "SerialNo"
        Me.SerialNo.ReadOnly = True
        '
        'Cat1
        '
        Me.Cat1.FillWeight = 47.43171!
        Me.Cat1.HeaderText = "Cat1"
        Me.Cat1.Name = "Cat1"
        Me.Cat1.ReadOnly = True
        '
        'Cat2
        '
        Me.Cat2.FillWeight = 47.43171!
        Me.Cat2.HeaderText = "Cat2"
        Me.Cat2.Name = "Cat2"
        Me.Cat2.ReadOnly = True
        '
        'Description
        '
        Me.Description.FillWeight = 180.0!
        Me.Description.HeaderText = "Description"
        Me.Description.Name = "Description"
        Me.Description.ReadOnly = True
        '
        'Tax
        '
        Me.Tax.FillWeight = 37.94537!
        Me.Tax.HeaderText = "Tax"
        Me.Tax.Name = "Tax"
        Me.Tax.ReadOnly = True
        '
        'Sell_inc
        '
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Sell_inc.DefaultCellStyle = DataGridViewCellStyle9
        Me.Sell_inc.FillWeight = 75.89074!
        Me.Sell_inc.HeaderText = "RRP"
        Me.Sell_inc.Name = "Sell_inc"
        Me.Sell_inc.ReadOnly = True
        Me.Sell_inc.ToolTipText = "Normal Sell Inc Tax"
        '
        'Sell_Actual_inc
        '
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Sell_Actual_inc.DefaultCellStyle = DataGridViewCellStyle10
        Me.Sell_Actual_inc.FillWeight = 75.89074!
        Me.Sell_Actual_inc.HeaderText = "Sell Actual"
        Me.Sell_Actual_inc.Name = "Sell_Actual_inc"
        Me.Sell_Actual_inc.ReadOnly = True
        '
        'Qty
        '
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Qty.DefaultCellStyle = DataGridViewCellStyle11
        Me.Qty.FillWeight = 40.0!
        Me.Qty.HeaderText = "Qty"
        Me.Qty.Name = "Qty"
        Me.Qty.ReadOnly = True
        '
        'SellActual_Inc_Extended
        '
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.SellActual_Inc_Extended.DefaultCellStyle = DataGridViewCellStyle12
        Me.SellActual_Inc_Extended.HeaderText = "Extension"
        Me.SellActual_Inc_Extended.Name = "SellActual_Inc_Extended"
        Me.SellActual_Inc_Extended.ReadOnly = True
        '
        'Stock_id
        '
        Me.Stock_id.HeaderText = "Stock_id"
        Me.Stock_id.Name = "Stock_id"
        Me.Stock_id.ReadOnly = True
        Me.Stock_id.Visible = False
        '
        'Track_serial
        '
        Me.Track_serial.HeaderText = "Track_serial"
        Me.Track_serial.Name = "Track_serial"
        Me.Track_serial.ReadOnly = True
        Me.Track_serial.Visible = False
        '
        'SERIAL_AUDIT_ID
        '
        Me.SERIAL_AUDIT_ID.HeaderText = "SERIAL_AUDIT_ID"
        Me.SERIAL_AUDIT_ID.Name = "SERIAL_AUDIT_ID"
        Me.SERIAL_AUDIT_ID.ReadOnly = True
        Me.SERIAL_AUDIT_ID.Visible = False
        '
        'isServiceItem
        '
        Me.isServiceItem.HeaderText = "isServiceItem"
        Me.isServiceItem.Name = "isServiceItem"
        Me.isServiceItem.ReadOnly = True
        Me.isServiceItem.Visible = False
        '
        'Cost_Ex
        '
        Me.Cost_Ex.HeaderText = "Cost_Ex"
        Me.Cost_Ex.Name = "Cost_Ex"
        Me.Cost_Ex.ReadOnly = True
        Me.Cost_Ex.Visible = False
        '
        'Cost_Inc
        '
        Me.Cost_Inc.HeaderText = "Cost_Inc"
        Me.Cost_Inc.Name = "Cost_Inc"
        Me.Cost_Inc.ReadOnly = True
        Me.Cost_Inc.Visible = False
        '
        'Sell_ex
        '
        Me.Sell_ex.HeaderText = "Sell_ex"
        Me.Sell_ex.Name = "Sell_ex"
        Me.Sell_ex.ReadOnly = True
        Me.Sell_ex.Visible = False
        '
        'SellActual_Ex
        '
        Me.SellActual_Ex.HeaderText = "SellActual_Ex"
        Me.SellActual_Ex.Name = "SellActual_Ex"
        Me.SellActual_Ex.ReadOnly = True
        Me.SellActual_Ex.Visible = False
        '
        'SellActual_Tax
        '
        Me.SellActual_Tax.HeaderText = "SellActual_Tax"
        Me.SellActual_Tax.Name = "SellActual_Tax"
        Me.SellActual_Tax.ReadOnly = True
        Me.SellActual_Tax.Visible = False
        '
        'SellActual_Ex_Extended
        '
        Me.SellActual_Ex_Extended.HeaderText = "SellActual_Ex_Extended"
        Me.SellActual_Ex_Extended.Name = "SellActual_Ex_Extended"
        Me.SellActual_Ex_Extended.ReadOnly = True
        Me.SellActual_Ex_Extended.Visible = False
        '
        'SellActual_tax_Extended
        '
        Me.SellActual_tax_Extended.HeaderText = "SellActual_tax_extended"
        Me.SellActual_tax_Extended.Name = "SellActual_tax_Extended"
        Me.SellActual_tax_Extended.ReadOnly = True
        Me.SellActual_tax_Extended.Visible = False
        '
        'ucPosSaleChild
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange
        Me.BackColor = System.Drawing.Color.White
        Me.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.CausesValidation = False
        Me.Controls.Add(Me.grpboxSale)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "ucPosSaleChild"
        Me.Size = New System.Drawing.Size(1008, 644)
        Me.grpboxSale.ResumeLayout(False)
        Me.panelCommit.ResumeLayout(False)
        Me.panelSalesCurrentHdr.ResumeLayout(False)
        CType(Me.picSaleItem, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelSaleLineEntry.ResumeLayout(False)
        Me.panelSaleLineEntry.PerformLayout()
        Me.panelSaleFooter.ResumeLayout(False)
        Me.panelPayment.ResumeLayout(False)
        Me.panelPayment.PerformLayout()
        Me.grpBoxSalePayments.ResumeLayout(False)
        Me.grpBoxSalePayments.PerformLayout()
        CType(Me.dgvSalePaymentDetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpBoxRefundType.ResumeLayout(False)
        Me.panelSaleTotals.ResumeLayout(False)
        Me.panelSaleTotals.PerformLayout()
        CType(Me.dgvSaleItems, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelSaleHdr.ResumeLayout(False)
        Me.panelSaleHdr.PerformLayout()
        Me.panelOptTranType.ResumeLayout(False)
        Me.panelSaleInvoiceList.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grpboxSale As System.Windows.Forms.GroupBox
    Friend WithEvents panelSaleFooter As System.Windows.Forms.Panel
    Friend WithEvents btnCancelSale As System.Windows.Forms.Button
    Friend WithEvents LabSalePayments As System.Windows.Forms.Label
    Friend WithEvents btnCommitSale As System.Windows.Forms.Button
    Friend WithEvents dgvSaleItems As System.Windows.Forms.DataGridView
    Friend WithEvents panelSaleHdr As System.Windows.Forms.Panel
    Friend WithEvents txtSaleCustName As System.Windows.Forms.TextBox
    Friend WithEvents labSaleTranType As System.Windows.Forms.Label
    Friend WithEvents LabSaleCust As System.Windows.Forms.Label
    Friend WithEvents txtSaleCustBarcode As System.Windows.Forms.TextBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents LabSaleBalance As System.Windows.Forms.Label
    Friend WithEvents txtSaleChange As System.Windows.Forms.TextBox
    Friend WithEvents txtSalePaymentBalance As System.Windows.Forms.TextBox
    Friend WithEvents txtSaleSubTotal As System.Windows.Forms.TextBox
    Friend WithEvents LabSaleSubTotal As System.Windows.Forms.Label
    Friend WithEvents txtSaleRounding As System.Windows.Forms.TextBox
    Friend WithEvents txtSaleDiscount As System.Windows.Forms.TextBox
    Friend WithEvents LabSaleDiscount As System.Windows.Forms.Label
    Friend WithEvents LabSaleInvTotal As System.Windows.Forms.Label
    Friend WithEvents LabSaleRounding As System.Windows.Forms.Label
    Friend WithEvents txtSaleTotal As System.Windows.Forms.TextBox
    Friend WithEvents picSaleItem As System.Windows.Forms.PictureBox
    Friend WithEvents labSaleCrBal As System.Windows.Forms.Label
    Friend WithEvents panelSaleTotals As System.Windows.Forms.Panel
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents labSaleJobDelivery As System.Windows.Forms.Label
    Friend WithEvents labSaleChange As System.Windows.Forms.Label
    Friend WithEvents labSaleHelp As System.Windows.Forms.Label
    Friend WithEvents labSaleHelp2 As System.Windows.Forms.Label
    Friend WithEvents LabSalePrevious As System.Windows.Forms.Label
    Friend WithEvents txtSaleTotalTax As System.Windows.Forms.TextBox
    Friend WithEvents LabSaleIncludesTax As System.Windows.Forms.Label
    Friend WithEvents panelPayment As System.Windows.Forms.Panel
    Friend WithEvents txtSaleNettTax As System.Windows.Forms.TextBox
    Friend WithEvents LabSaleNettTax As System.Windows.Forms.Label
    Friend WithEvents LabSaleDiscAnalysis As System.Windows.Forms.Label
    Friend WithEvents txtSaleDiscountAnalysis As System.Windows.Forms.TextBox
    Friend WithEvents txtSaleSubTotal2 As System.Windows.Forms.TextBox
    Friend WithEvents LabSaleSubTotal2 As System.Windows.Forms.Label
    Friend WithEvents txtSaleJobNo As System.Windows.Forms.TextBox
    Friend WithEvents labSaleChargeBalance As System.Windows.Forms.Label
    Friend WithEvents panelSaleInvoiceList As System.Windows.Forms.Panel
    Friend WithEvents panelOptTranType As System.Windows.Forms.Panel
    Friend WithEvents btnCancelSale2 As System.Windows.Forms.Button
    Friend WithEvents cboSaleDiscountPercent As System.Windows.Forms.ComboBox
    Friend WithEvents btnDiscountPC As System.Windows.Forms.Button
    Friend WithEvents btnSaleSelectInvoice As System.Windows.Forms.Button
    Friend WithEvents panelSaleLineEntry As System.Windows.Forms.Panel
    Friend WithEvents txtSaleItemBarcode As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtSaleItemSerialNo As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtSaleItemDescription As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtSaleItemSellPrice As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtSaleItemExtension As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtSaleItemQty As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnSaleLineOk As System.Windows.Forms.Button
    Friend WithEvents grpBoxRefundType As System.Windows.Forms.GroupBox
    Friend WithEvents optRefundCredit As System.Windows.Forms.RadioButton
    Friend WithEvents optRefundCash As System.Windows.Forms.RadioButton
    Friend WithEvents listViewSaleAvailCredit As System.Windows.Forms.ListView
    Friend WithEvents itemLabel As System.Windows.Forms.ColumnHeader
    Friend WithEvents itemValue As System.Windows.Forms.ColumnHeader
    Friend WithEvents labSaleStaffName As System.Windows.Forms.Label
    Friend WithEvents txtSaleStaffBarcode As System.Windows.Forms.TextBox
    Friend WithEvents labSaleStaff As System.Windows.Forms.Label
    Friend WithEvents panelSalesCurrentHdr As System.Windows.Forms.Panel
    Friend WithEvents btnSaleItemLineClear As System.Windows.Forms.Button
    Friend WithEvents btnSaleItemLineClear2 As System.Windows.Forms.Button
    Friend WithEvents labSaleAccountSalesInfo As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents btnSaleSelectQuote As System.Windows.Forms.Button
    Friend WithEvents optRefundEftPosCr As System.Windows.Forms.RadioButton
    Friend WithEvents optRefundEftPosDr As System.Windows.Forms.RadioButton
    Friend WithEvents btnSaleSelectLayby As System.Windows.Forms.Button
    Friend WithEvents btnSaleComments As System.Windows.Forms.Button
    Friend WithEvents panelCommit As System.Windows.Forms.Panel
    Friend WithEvents chkOnAccount As System.Windows.Forms.CheckBox
    Friend WithEvents btnMainExit As System.Windows.Forms.Button
    Friend WithEvents optSaleSale As System.Windows.Forms.RadioButton
    Friend WithEvents optSaleRefund As System.Windows.Forms.RadioButton
    Friend WithEvents optSaleLayby As System.Windows.Forms.RadioButton
    Friend WithEvents optSaleQuote As System.Windows.Forms.RadioButton
    Friend WithEvents labShortcuts As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents chkOnAccount2 As System.Windows.Forms.CheckBox
    Friend WithEvents grpBoxSalePayments As System.Windows.Forms.GroupBox
    Friend WithEvents txtCreditNoteWdl As System.Windows.Forms.TextBox
    Friend WithEvents labCreditNoteLab As System.Windows.Forms.Label
    Friend WithEvents dgvSalePaymentDetails As System.Windows.Forms.DataGridView
    Friend WithEvents labImportQuote As System.Windows.Forms.Label
    Friend WithEvents PaymentType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Amount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PaymentType_id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents labSaleCustTags As System.Windows.Forms.Label
    Friend WithEvents cboRefundOtherDetails As System.Windows.Forms.ComboBox
    Friend WithEvents optRefundOther As System.Windows.Forms.RadioButton
    Friend WithEvents Barcode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SerialNo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cat1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cat2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Description As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Tax As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Sell_inc As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Sell_Actual_inc As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Qty As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SellActual_Inc_Extended As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Stock_id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Track_serial As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SERIAL_AUDIT_ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents isServiceItem As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cost_Ex As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cost_Inc As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Sell_ex As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SellActual_Ex As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SellActual_Tax As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SellActual_Ex_Extended As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SellActual_tax_Extended As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
