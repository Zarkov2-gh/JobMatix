<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ucChildCustomer
    Inherits System.Windows.Forms.UserControl  '= System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle29 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle30 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle26 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle27 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle28 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle31 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle34 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle35 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle32 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle33 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelBanner = New System.Windows.Forms.Panel()
        Me.labGettingData = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.grpBoxCustomer = New System.Windows.Forms.GroupBox()
        Me.btnTagRef = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.panelCustHdr = New System.Windows.Forms.Panel()
        Me.labItemHeader = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.FrameBrowse = New System.Windows.Forms.GroupBox()
        Me.chkIncludeInactiveCust = New System.Windows.Forms.CheckBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.cmdClearCustomerSearch = New System.Windows.Forms.Button()
        Me.cmdCustomerSearch = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtCustomerSearch = New System.Windows.Forms.TextBox()
        Me.dgvCustomerList = New System.Windows.Forms.DataGridView()
        Me.txtFind = New System.Windows.Forms.TextBox()
        Me.labRecCount = New System.Windows.Forms.Label()
        Me.LabFind = New System.Windows.Forms.Label()
        Me.TabControlCustomer = New System.Windows.Forms.TabControl()
        Me.TabPageCustomerDetail = New System.Windows.Forms.TabPage()
        Me.btnTagEdit = New System.Windows.Forms.Button()
        Me.labEditing = New System.Windows.Forms.Label()
        Me.labAddingNew = New System.Windows.Forms.Label()
        Me.panelCustomerDetail = New System.Windows.Forms.Panel()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.labCustTags = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtPricingGrade = New System.Windows.Forms.TextBox()
        Me.cboPricingGrade = New System.Windows.Forms.ComboBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtMobile = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtFax = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtABN = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.txtPostCode = New System.Windows.Forms.TextBox()
        Me.cboState = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtCreditDays = New System.Windows.Forms.TextBox()
        Me.chkIsAccountCust = New System.Windows.Forms.CheckBox()
        Me.txtIsAccountCust = New System.Windows.Forms.TextBox()
        Me.labRequiredFields = New System.Windows.Forms.Label()
        Me.txtInactive = New System.Windows.Forms.TextBox()
        Me.btnCustomerCancel = New System.Windows.Forms.Button()
        Me.btnCustomerCommit = New System.Windows.Forms.Button()
        Me.txtCountry = New System.Windows.Forms.TextBox()
        Me.txtSuburb = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtComments = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtCreditLimit = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.chkInactive = New System.Windows.Forms.CheckBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtCustomer_id = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtCompanyName = New System.Windows.Forms.TextBox()
        Me.BarcodeLabel = New System.Windows.Forms.Label()
        Me.DescriptionLabel = New System.Windows.Forms.Label()
        Me.txtBarcode = New System.Windows.Forms.TextBox()
        Me.btnNew = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.TabPageInvoices = New System.Windows.Forms.TabPage()
        Me.labInvoiceReversed = New System.Windows.Forms.Label()
        Me.chkOutstanding = New System.Windows.Forms.CheckBox()
        Me.btnShowInvoice = New System.Windows.Forms.Button()
        Me.dgvInvoices = New System.Windows.Forms.DataGridView()
        Me.invoice_no = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.invoices_invoice_date = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tranType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.isOnAccount = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.inv_total = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.prev_paid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.outstanding = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TabPageItemSales = New System.Windows.Forms.TabPage()
        Me.dgvSales = New System.Windows.Forms.DataGridView()
        Me.sale_invoice_no = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.invoice_date = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.barcode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Description = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.sale_qty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.sale_value = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.TabPageAccountPayments = New System.Windows.Forms.TabPage()
        Me.btnShowPayment = New System.Windows.Forms.Button()
        Me.dgvPayments = New System.Windows.Forms.DataGridView()
        Me.payment_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.payment_date = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.amount_received = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.credit_note_contribution = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.invoice_nos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tran_type = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.docket_name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPageQuotes = New System.Windows.Forms.TabPage()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.dgvQuotes = New System.Windows.Forms.DataGridView()
        Me.salesorder_date = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.salesorder_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.total_inc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.staff_docket_name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPageJobs = New System.Windows.Forms.TabPage()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.btnOnSiteJob = New System.Windows.Forms.Button()
        Me.btnAcceptJob = New System.Windows.Forms.Button()
        Me.dgvJobs = New System.Windows.Forms.DataGridView()
        Me.job_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.jobstatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dateupdated = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NominatedTech = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.timerGrid = New System.Windows.Forms.Timer(Me.components)
        Me.timerFind = New System.Windows.Forms.Timer(Me.components)
        Me.panelBanner.SuspendLayout()
        Me.grpBoxCustomer.SuspendLayout()
        Me.panelCustHdr.SuspendLayout()
        Me.FrameBrowse.SuspendLayout()
        CType(Me.dgvCustomerList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControlCustomer.SuspendLayout()
        Me.TabPageCustomerDetail.SuspendLayout()
        Me.panelCustomerDetail.SuspendLayout()
        Me.TabPageInvoices.SuspendLayout()
        CType(Me.dgvInvoices, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPageItemSales.SuspendLayout()
        CType(Me.dgvSales, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPageAccountPayments.SuspendLayout()
        CType(Me.dgvPayments, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPageQuotes.SuspendLayout()
        CType(Me.dgvQuotes, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPageJobs.SuspendLayout()
        CType(Me.dgvJobs, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelBanner
        '
        Me.panelBanner.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.panelBanner.Controls.Add(Me.labGettingData)
        Me.panelBanner.Controls.Add(Me.Label5)
        Me.panelBanner.Location = New System.Drawing.Point(3, 7)
        Me.panelBanner.Name = "panelBanner"
        Me.panelBanner.Size = New System.Drawing.Size(410, 40)
        Me.panelBanner.TabIndex = 22
        '
        'labGettingData
        '
        Me.labGettingData.BackColor = System.Drawing.Color.Transparent
        Me.labGettingData.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labGettingData.ForeColor = System.Drawing.Color.MediumBlue
        Me.labGettingData.Location = New System.Drawing.Point(203, 3)
        Me.labGettingData.Name = "labGettingData"
        Me.labGettingData.Padding = New System.Windows.Forms.Padding(3, 3, 0, 0)
        Me.labGettingData.Size = New System.Drawing.Size(193, 33)
        Me.labGettingData.TabIndex = 2
        Me.labGettingData.Text = "Wait-" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Getting Data.."
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(13, 8)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(137, 23)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Customer Admin"
        '
        'grpBoxCustomer
        '
        Me.grpBoxCustomer.BackColor = System.Drawing.Color.WhiteSmoke
        Me.grpBoxCustomer.Controls.Add(Me.btnTagRef)
        Me.grpBoxCustomer.Controls.Add(Me.btnExit)
        Me.grpBoxCustomer.Controls.Add(Me.panelCustHdr)
        Me.grpBoxCustomer.Controls.Add(Me.FrameBrowse)
        Me.grpBoxCustomer.Controls.Add(Me.TabControlCustomer)
        Me.grpBoxCustomer.Controls.Add(Me.panelBanner)
        Me.grpBoxCustomer.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpBoxCustomer.Location = New System.Drawing.Point(2, 0)
        Me.grpBoxCustomer.Name = "grpBoxCustomer"
        Me.grpBoxCustomer.Size = New System.Drawing.Size(1004, 621)
        Me.grpBoxCustomer.TabIndex = 23
        Me.grpBoxCustomer.TabStop = False
        Me.grpBoxCustomer.Text = "grpBoxCustomer"
        '
        'btnTagRef
        '
        Me.btnTagRef.BackColor = System.Drawing.Color.Azure
        Me.btnTagRef.Location = New System.Drawing.Point(422, 8)
        Me.btnTagRef.Name = "btnTagRef"
        Me.btnTagRef.Size = New System.Drawing.Size(57, 40)
        Me.btnTagRef.TabIndex = 1
        Me.btnTagRef.Text = "Tag Ref."
        Me.ToolTip1.SetToolTip(Me.btnTagRef, "View/Update Reference List for ALL Customer Tags.")
        Me.btnTagRef.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.WhiteSmoke
        Me.btnExit.CausesValidation = False
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnExit.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(935, 10)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(54, 28)
        Me.btnExit.TabIndex = 45
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'panelCustHdr
        '
        Me.panelCustHdr.Controls.Add(Me.labItemHeader)
        Me.panelCustHdr.Controls.Add(Me.Label14)
        Me.panelCustHdr.Location = New System.Drawing.Point(488, 7)
        Me.panelCustHdr.Name = "panelCustHdr"
        Me.panelCustHdr.Size = New System.Drawing.Size(428, 40)
        Me.panelCustHdr.TabIndex = 24
        '
        'labItemHeader
        '
        Me.labItemHeader.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labItemHeader.Location = New System.Drawing.Point(83, 12)
        Me.labItemHeader.Name = "labItemHeader"
        Me.labItemHeader.Size = New System.Drawing.Size(235, 20)
        Me.labItemHeader.TabIndex = 22
        Me.labItemHeader.Text = "labItemHeader"
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(3, 12)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(74, 18)
        Me.Label14.TabIndex = 23
        Me.Label14.Text = "Customer: "
        '
        'FrameBrowse
        '
        Me.FrameBrowse.BackColor = System.Drawing.Color.WhiteSmoke
        Me.FrameBrowse.Controls.Add(Me.chkIncludeInactiveCust)
        Me.FrameBrowse.Controls.Add(Me.Label22)
        Me.FrameBrowse.Controls.Add(Me.Label21)
        Me.FrameBrowse.Controls.Add(Me.cmdClearCustomerSearch)
        Me.FrameBrowse.Controls.Add(Me.cmdCustomerSearch)
        Me.FrameBrowse.Controls.Add(Me.Label3)
        Me.FrameBrowse.Controls.Add(Me.txtCustomerSearch)
        Me.FrameBrowse.Controls.Add(Me.dgvCustomerList)
        Me.FrameBrowse.Controls.Add(Me.txtFind)
        Me.FrameBrowse.Controls.Add(Me.labRecCount)
        Me.FrameBrowse.Controls.Add(Me.LabFind)
        Me.FrameBrowse.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FrameBrowse.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FrameBrowse.Location = New System.Drawing.Point(4, 51)
        Me.FrameBrowse.Name = "FrameBrowse"
        Me.FrameBrowse.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FrameBrowse.Size = New System.Drawing.Size(477, 562)
        Me.FrameBrowse.TabIndex = 0
        Me.FrameBrowse.TabStop = False
        Me.FrameBrowse.Text = "FrameBrowse"
        '
        'chkIncludeInactiveCust
        '
        Me.chkIncludeInactiveCust.Location = New System.Drawing.Point(273, 13)
        Me.chkIncludeInactiveCust.Name = "chkIncludeInactiveCust"
        Me.chkIncludeInactiveCust.Size = New System.Drawing.Size(112, 31)
        Me.chkIncludeInactiveCust.TabIndex = 83
        Me.chkIncludeInactiveCust.Text = "Include Inactive Customers"
        Me.chkIncludeInactiveCust.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label22.Font = New System.Drawing.Font("Tahoma", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label22.Location = New System.Drawing.Point(184, 17)
        Me.Label22.Name = "Label22"
        Me.Label22.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label22.Size = New System.Drawing.Size(83, 13)
        Me.Label22.TabIndex = 82
        Me.Label22.Text = "Records found."
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(169, 46)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(121, 12)
        Me.Label21.TabIndex = 81
        Me.Label21.Text = "Full Text Filter (Srch):"
        '
        'cmdClearCustomerSearch
        '
        Me.cmdClearCustomerSearch.BackColor = System.Drawing.Color.Gainsboro
        Me.cmdClearCustomerSearch.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClearCustomerSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdClearCustomerSearch.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClearCustomerSearch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClearCustomerSearch.Location = New System.Drawing.Point(394, 29)
        Me.cmdClearCustomerSearch.Name = "cmdClearCustomerSearch"
        Me.cmdClearCustomerSearch.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClearCustomerSearch.Size = New System.Drawing.Size(68, 23)
        Me.cmdClearCustomerSearch.TabIndex = 80
        Me.cmdClearCustomerSearch.Text = "Clear"
        Me.cmdClearCustomerSearch.UseVisualStyleBackColor = False
        '
        'cmdCustomerSearch
        '
        Me.cmdCustomerSearch.BackColor = System.Drawing.Color.Gainsboro
        Me.cmdCustomerSearch.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCustomerSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdCustomerSearch.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCustomerSearch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCustomerSearch.Location = New System.Drawing.Point(394, 59)
        Me.cmdCustomerSearch.Name = "cmdCustomerSearch"
        Me.cmdCustomerSearch.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCustomerSearch.Size = New System.Drawing.Size(68, 23)
        Me.cmdCustomerSearch.TabIndex = 79
        Me.cmdCustomerSearch.Text = "Search"
        Me.cmdCustomerSearch.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdCustomerSearch.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(123, 20)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Customer List"
        '
        'txtCustomerSearch
        '
        Me.txtCustomerSearch.AcceptsReturn = True
        Me.txtCustomerSearch.BackColor = System.Drawing.Color.Gainsboro
        Me.txtCustomerSearch.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCustomerSearch.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCustomerSearch.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomerSearch.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCustomerSearch.Location = New System.Drawing.Point(171, 63)
        Me.txtCustomerSearch.MaxLength = 0
        Me.txtCustomerSearch.Name = "txtCustomerSearch"
        Me.txtCustomerSearch.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCustomerSearch.Size = New System.Drawing.Size(194, 19)
        Me.txtCustomerSearch.TabIndex = 78
        Me.txtCustomerSearch.Text = "txtCustomerSearch"
        '
        'dgvCustomerList
        '
        Me.dgvCustomerList.AllowUserToAddRows = False
        Me.dgvCustomerList.AllowUserToDeleteRows = False
        Me.dgvCustomerList.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.dgvCustomerList.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvCustomerList.ColumnHeadersHeight = 18
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvCustomerList.DefaultCellStyle = DataGridViewCellStyle1
        Me.dgvCustomerList.GridColor = System.Drawing.SystemColors.ControlLight
        Me.dgvCustomerList.Location = New System.Drawing.Point(4, 88)
        Me.dgvCustomerList.MultiSelect = False
        Me.dgvCustomerList.Name = "dgvCustomerList"
        Me.dgvCustomerList.ReadOnly = True
        Me.dgvCustomerList.RowHeadersWidth = 17
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvCustomerList.RowsDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvCustomerList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvCustomerList.Size = New System.Drawing.Size(467, 443)
        Me.dgvCustomerList.StandardTab = True
        Me.dgvCustomerList.TabIndex = 4
        '
        'txtFind
        '
        Me.txtFind.AcceptsReturn = True
        Me.txtFind.BackColor = System.Drawing.Color.Gainsboro
        Me.txtFind.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtFind.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFind.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFind.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFind.Location = New System.Drawing.Point(6, 67)
        Me.txtFind.MaxLength = 0
        Me.txtFind.Name = "txtFind"
        Me.txtFind.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtFind.Size = New System.Drawing.Size(136, 14)
        Me.txtFind.TabIndex = 2
        '
        'labRecCount
        '
        Me.labRecCount.BackColor = System.Drawing.Color.Transparent
        Me.labRecCount.Cursor = System.Windows.Forms.Cursors.Default
        Me.labRecCount.Font = New System.Drawing.Font("Tahoma", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labRecCount.ForeColor = System.Drawing.SystemColors.ControlText
        Me.labRecCount.Location = New System.Drawing.Point(134, 15)
        Me.labRecCount.Name = "labRecCount"
        Me.labRecCount.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.labRecCount.Size = New System.Drawing.Size(44, 15)
        Me.labRecCount.TabIndex = 19
        Me.labRecCount.Text = "labRecCount"
        Me.labRecCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'LabFind
        '
        Me.LabFind.BackColor = System.Drawing.Color.LightGray
        Me.LabFind.Cursor = System.Windows.Forms.Cursors.Default
        Me.LabFind.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabFind.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LabFind.Location = New System.Drawing.Point(7, 40)
        Me.LabFind.Name = "LabFind"
        Me.LabFind.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LabFind.Size = New System.Drawing.Size(135, 25)
        Me.LabFind.TabIndex = 18
        Me.LabFind.Text = "LabFind"
        '
        'TabControlCustomer
        '
        Me.TabControlCustomer.Controls.Add(Me.TabPageCustomerDetail)
        Me.TabControlCustomer.Controls.Add(Me.TabPageInvoices)
        Me.TabControlCustomer.Controls.Add(Me.TabPageItemSales)
        Me.TabControlCustomer.Controls.Add(Me.TabPageAccountPayments)
        Me.TabControlCustomer.Controls.Add(Me.TabPageQuotes)
        Me.TabControlCustomer.Controls.Add(Me.TabPageJobs)
        Me.TabControlCustomer.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControlCustomer.Location = New System.Drawing.Point(487, 51)
        Me.TabControlCustomer.Name = "TabControlCustomer"
        Me.TabControlCustomer.SelectedIndex = 0
        Me.TabControlCustomer.Size = New System.Drawing.Size(513, 566)
        Me.TabControlCustomer.TabIndex = 3
        '
        'TabPageCustomerDetail
        '
        Me.TabPageCustomerDetail.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPageCustomerDetail.Controls.Add(Me.btnTagEdit)
        Me.TabPageCustomerDetail.Controls.Add(Me.labEditing)
        Me.TabPageCustomerDetail.Controls.Add(Me.labAddingNew)
        Me.TabPageCustomerDetail.Controls.Add(Me.panelCustomerDetail)
        Me.TabPageCustomerDetail.Controls.Add(Me.btnNew)
        Me.TabPageCustomerDetail.Controls.Add(Me.btnEdit)
        Me.TabPageCustomerDetail.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPageCustomerDetail.Location = New System.Drawing.Point(4, 25)
        Me.TabPageCustomerDetail.Name = "TabPageCustomerDetail"
        Me.TabPageCustomerDetail.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageCustomerDetail.Size = New System.Drawing.Size(505, 537)
        Me.TabPageCustomerDetail.TabIndex = 0
        Me.TabPageCustomerDetail.Text = "Customer Details"
        Me.TabPageCustomerDetail.UseVisualStyleBackColor = True
        '
        'btnTagEdit
        '
        Me.btnTagEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTagEdit.Location = New System.Drawing.Point(448, 9)
        Me.btnTagEdit.Name = "btnTagEdit"
        Me.btnTagEdit.Size = New System.Drawing.Size(40, 23)
        Me.btnTagEdit.TabIndex = 5
        Me.btnTagEdit.Text = "Tags"
        Me.ToolTip1.SetToolTip(Me.btnTagEdit, "Edit Customer Tags")
        Me.btnTagEdit.UseVisualStyleBackColor = True
        '
        'labEditing
        '
        Me.labEditing.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.labEditing.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labEditing.ForeColor = System.Drawing.Color.SaddleBrown
        Me.labEditing.Location = New System.Drawing.Point(105, 9)
        Me.labEditing.Name = "labEditing"
        Me.labEditing.Size = New System.Drawing.Size(76, 22)
        Me.labEditing.TabIndex = 4
        Me.labEditing.Text = "Editing.."
        Me.labEditing.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'labAddingNew
        '
        Me.labAddingNew.BackColor = System.Drawing.Color.LavenderBlush
        Me.labAddingNew.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labAddingNew.ForeColor = System.Drawing.Color.DarkMagenta
        Me.labAddingNew.Location = New System.Drawing.Point(279, 9)
        Me.labAddingNew.Name = "labAddingNew"
        Me.labAddingNew.Size = New System.Drawing.Size(152, 22)
        Me.labAddingNew.TabIndex = 3
        Me.labAddingNew.Text = "Adding New Customer.."
        Me.labAddingNew.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'panelCustomerDetail
        '
        Me.panelCustomerDetail.BackColor = System.Drawing.Color.WhiteSmoke
        Me.panelCustomerDetail.CausesValidation = False
        Me.panelCustomerDetail.Controls.Add(Me.Label34)
        Me.panelCustomerDetail.Controls.Add(Me.labCustTags)
        Me.panelCustomerDetail.Controls.Add(Me.Label20)
        Me.panelCustomerDetail.Controls.Add(Me.txtPricingGrade)
        Me.panelCustomerDetail.Controls.Add(Me.cboPricingGrade)
        Me.panelCustomerDetail.Controls.Add(Me.Label19)
        Me.panelCustomerDetail.Controls.Add(Me.Label18)
        Me.panelCustomerDetail.Controls.Add(Me.Label2)
        Me.panelCustomerDetail.Controls.Add(Me.txtEmail)
        Me.panelCustomerDetail.Controls.Add(Me.Label29)
        Me.panelCustomerDetail.Controls.Add(Me.txtMobile)
        Me.panelCustomerDetail.Controls.Add(Me.Label28)
        Me.panelCustomerDetail.Controls.Add(Me.txtFax)
        Me.panelCustomerDetail.Controls.Add(Me.Label27)
        Me.panelCustomerDetail.Controls.Add(Me.txtPhone)
        Me.panelCustomerDetail.Controls.Add(Me.Label26)
        Me.panelCustomerDetail.Controls.Add(Me.txtABN)
        Me.panelCustomerDetail.Controls.Add(Me.Label24)
        Me.panelCustomerDetail.Controls.Add(Me.txtState)
        Me.panelCustomerDetail.Controls.Add(Me.txtPostCode)
        Me.panelCustomerDetail.Controls.Add(Me.cboState)
        Me.panelCustomerDetail.Controls.Add(Me.Label13)
        Me.panelCustomerDetail.Controls.Add(Me.Label16)
        Me.panelCustomerDetail.Controls.Add(Me.Label12)
        Me.panelCustomerDetail.Controls.Add(Me.txtTitle)
        Me.panelCustomerDetail.Controls.Add(Me.Label11)
        Me.panelCustomerDetail.Controls.Add(Me.txtAddress)
        Me.panelCustomerDetail.Controls.Add(Me.Label25)
        Me.panelCustomerDetail.Controls.Add(Me.txtCreditDays)
        Me.panelCustomerDetail.Controls.Add(Me.chkIsAccountCust)
        Me.panelCustomerDetail.Controls.Add(Me.txtIsAccountCust)
        Me.panelCustomerDetail.Controls.Add(Me.labRequiredFields)
        Me.panelCustomerDetail.Controls.Add(Me.txtInactive)
        Me.panelCustomerDetail.Controls.Add(Me.btnCustomerCancel)
        Me.panelCustomerDetail.Controls.Add(Me.btnCustomerCommit)
        Me.panelCustomerDetail.Controls.Add(Me.txtCountry)
        Me.panelCustomerDetail.Controls.Add(Me.txtSuburb)
        Me.panelCustomerDetail.Controls.Add(Me.Label15)
        Me.panelCustomerDetail.Controls.Add(Me.txtComments)
        Me.panelCustomerDetail.Controls.Add(Me.Label10)
        Me.panelCustomerDetail.Controls.Add(Me.txtCreditLimit)
        Me.panelCustomerDetail.Controls.Add(Me.Label9)
        Me.panelCustomerDetail.Controls.Add(Me.Label8)
        Me.panelCustomerDetail.Controls.Add(Me.chkInactive)
        Me.panelCustomerDetail.Controls.Add(Me.Label7)
        Me.panelCustomerDetail.Controls.Add(Me.txtFirstName)
        Me.panelCustomerDetail.Controls.Add(Me.Label6)
        Me.panelCustomerDetail.Controls.Add(Me.txtLastName)
        Me.panelCustomerDetail.Controls.Add(Me.txtCustomer_id)
        Me.panelCustomerDetail.Controls.Add(Me.Label4)
        Me.panelCustomerDetail.Controls.Add(Me.txtCompanyName)
        Me.panelCustomerDetail.Controls.Add(Me.BarcodeLabel)
        Me.panelCustomerDetail.Controls.Add(Me.DescriptionLabel)
        Me.panelCustomerDetail.Controls.Add(Me.txtBarcode)
        Me.panelCustomerDetail.Location = New System.Drawing.Point(2, 38)
        Me.panelCustomerDetail.Name = "panelCustomerDetail"
        Me.panelCustomerDetail.Size = New System.Drawing.Size(500, 495)
        Me.panelCustomerDetail.TabIndex = 2
        '
        'Label34
        '
        Me.Label34.ForeColor = System.Drawing.Color.DarkGray
        Me.Label34.Location = New System.Drawing.Point(302, 65)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(115, 15)
        Me.Label34.TabIndex = 87
        Me.Label34.Text = "Tags (Click to Edit..)"
        '
        'labCustTags
        '
        Me.labCustTags.BackColor = System.Drawing.Color.Snow
        Me.labCustTags.Font = New System.Drawing.Font("Lucida Sans Unicode", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labCustTags.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.labCustTags.Location = New System.Drawing.Point(299, 84)
        Me.labCustTags.Name = "labCustTags"
        Me.labCustTags.Padding = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.labCustTags.Size = New System.Drawing.Size(172, 56)
        Me.labCustTags.TabIndex = 86
        Me.labCustTags.Text = "labCustTags"
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Gray
        Me.Label20.Location = New System.Drawing.Point(80, 369)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(115, 32)
        Me.Label20.TabIndex = 85
        Me.Label20.Text = "Cost + x% (Only Admin can change)."
        '
        'txtPricingGrade
        '
        Me.txtPricingGrade.BackColor = System.Drawing.Color.Gainsboro
        Me.txtPricingGrade.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtPricingGrade.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPricingGrade.Location = New System.Drawing.Point(191, 350)
        Me.txtPricingGrade.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtPricingGrade.Name = "txtPricingGrade"
        Me.txtPricingGrade.ReadOnly = True
        Me.txtPricingGrade.Size = New System.Drawing.Size(59, 14)
        Me.txtPricingGrade.TabIndex = 22
        Me.txtPricingGrade.TabStop = False
        '
        'cboPricingGrade
        '
        Me.cboPricingGrade.BackColor = System.Drawing.Color.Lavender
        Me.cboPricingGrade.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboPricingGrade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPricingGrade.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboPricingGrade.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboPricingGrade.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboPricingGrade.Location = New System.Drawing.Point(77, 348)
        Me.cboPricingGrade.Name = "cboPricingGrade"
        Me.cboPricingGrade.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboPricingGrade.Size = New System.Drawing.Size(105, 21)
        Me.cboPricingGrade.TabIndex = 21
        Me.ToolTip1.SetToolTip(Me.cboPricingGrade, "Pricing Grades (Cost-plus percentages) are set up in the POS Options Setup Form.)" &
        "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(NB: Only Admin user can change for Customer)..")
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.SystemColors.Control
        Me.Label19.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label19.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label19.Location = New System.Drawing.Point(15, 347)
        Me.Label19.Name = "Label19"
        Me.Label19.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label19.Size = New System.Drawing.Size(55, 32)
        Me.Label19.TabIndex = 84
        Me.Label19.Text = "Pricing          Grade:"
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(136, 41)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(46, 13)
        Me.Label18.TabIndex = 81
        Me.Label18.Text = "(Auto)"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(136, 17)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 13)
        Me.Label2.TabIndex = 80
        Me.Label2.Text = "(Auto)"
        '
        'txtEmail
        '
        Me.txtEmail.BackColor = System.Drawing.Color.Lavender
        Me.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmail.Location = New System.Drawing.Point(77, 321)
        Me.txtEmail.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtEmail.MaxLength = 200
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(360, 13)
        Me.txtEmail.TabIndex = 20
        Me.txtEmail.Text = "txtEmail"
        '
        'Label29
        '
        Me.Label29.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(14, 321)
        Me.Label29.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(61, 17)
        Me.Label29.TabIndex = 79
        Me.Label29.Text = "Email"
        '
        'txtMobile
        '
        Me.txtMobile.BackColor = System.Drawing.Color.Lavender
        Me.txtMobile.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtMobile.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMobile.Location = New System.Drawing.Point(77, 300)
        Me.txtMobile.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtMobile.MaxLength = 20
        Me.txtMobile.Name = "txtMobile"
        Me.txtMobile.Size = New System.Drawing.Size(167, 13)
        Me.txtMobile.TabIndex = 19
        Me.txtMobile.Text = "txtMobile"
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(13, 300)
        Me.Label28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(65, 17)
        Me.Label28.TabIndex = 78
        Me.Label28.Text = "Mobile"
        '
        'txtFax
        '
        Me.txtFax.BackColor = System.Drawing.Color.Lavender
        Me.txtFax.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtFax.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFax.Location = New System.Drawing.Point(298, 280)
        Me.txtFax.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtFax.MaxLength = 20
        Me.txtFax.Name = "txtFax"
        Me.txtFax.Size = New System.Drawing.Size(139, 13)
        Me.txtFax.TabIndex = 18
        Me.txtFax.Text = "txtFax"
        '
        'Label27
        '
        Me.Label27.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(269, 279)
        Me.Label27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(29, 17)
        Me.Label27.TabIndex = 76
        Me.Label27.Text = "Fax"
        '
        'txtPhone
        '
        Me.txtPhone.BackColor = System.Drawing.Color.Lavender
        Me.txtPhone.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtPhone.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPhone.Location = New System.Drawing.Point(77, 279)
        Me.txtPhone.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtPhone.MaxLength = 20
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(167, 13)
        Me.txtPhone.TabIndex = 17
        Me.txtPhone.Text = "txtPhone"
        '
        'Label26
        '
        Me.Label26.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(13, 279)
        Me.Label26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(65, 17)
        Me.Label26.TabIndex = 74
        Me.Label26.Text = "Phone"
        '
        'txtABN
        '
        Me.txtABN.BackColor = System.Drawing.Color.Lavender
        Me.txtABN.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtABN.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtABN.Location = New System.Drawing.Point(78, 132)
        Me.txtABN.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtABN.MaxLength = 20
        Me.txtABN.Name = "txtABN"
        Me.txtABN.Size = New System.Drawing.Size(169, 13)
        Me.txtABN.TabIndex = 9
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(14, 132)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(61, 17)
        Me.Label24.TabIndex = 71
        Me.Label24.Text = "ABN"
        '
        'txtState
        '
        Me.txtState.BackColor = System.Drawing.Color.Gainsboro
        Me.txtState.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtState.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtState.Location = New System.Drawing.Point(159, 234)
        Me.txtState.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtState.Name = "txtState"
        Me.txtState.ReadOnly = True
        Me.txtState.Size = New System.Drawing.Size(47, 13)
        Me.txtState.TabIndex = 14
        Me.txtState.TabStop = False
        '
        'txtPostCode
        '
        Me.txtPostCode.AcceptsReturn = True
        Me.txtPostCode.BackColor = System.Drawing.Color.Lavender
        Me.txtPostCode.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtPostCode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPostCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPostCode.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPostCode.Location = New System.Drawing.Point(312, 234)
        Me.txtPostCode.MaxLength = 4
        Me.txtPostCode.Name = "txtPostCode"
        Me.txtPostCode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPostCode.Size = New System.Drawing.Size(49, 13)
        Me.txtPostCode.TabIndex = 15
        Me.txtPostCode.Text = "txtPostCode"
        Me.txtPostCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cboState
        '
        Me.cboState.BackColor = System.Drawing.Color.Lavender
        Me.cboState.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboState.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboState.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboState.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboState.Location = New System.Drawing.Point(77, 232)
        Me.cboState.Name = "cboState"
        Me.cboState.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboState.Size = New System.Drawing.Size(73, 21)
        Me.cboState.TabIndex = 13
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label13.Location = New System.Drawing.Point(250, 234)
        Me.Label13.Name = "Label13"
        Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label13.Size = New System.Drawing.Size(59, 17)
        Me.Label13.TabIndex = 69
        Me.Label13.Text = "PostCode:"
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.SystemColors.Control
        Me.Label16.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label16.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label16.Location = New System.Drawing.Point(15, 231)
        Me.Label16.Name = "Label16"
        Me.Label16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label16.Size = New System.Drawing.Size(41, 17)
        Me.Label16.TabIndex = 68
        Me.Label16.Text = "State:"
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(14, 66)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(36, 17)
        Me.Label12.TabIndex = 65
        Me.Label12.Text = "Title"
        '
        'txtTitle
        '
        Me.txtTitle.BackColor = System.Drawing.Color.Lavender
        Me.txtTitle.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTitle.Location = New System.Drawing.Point(84, 67)
        Me.txtTitle.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtTitle.MaxLength = 10
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(104, 13)
        Me.txtTitle.TabIndex = 6
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(14, 173)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(61, 17)
        Me.Label11.TabIndex = 63
        Me.Label11.Text = "Address"
        '
        'txtAddress
        '
        Me.txtAddress.BackColor = System.Drawing.Color.Lavender
        Me.txtAddress.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtAddress.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddress.Location = New System.Drawing.Point(78, 173)
        Me.txtAddress.MaxLength = 150
        Me.txtAddress.Multiline = True
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtAddress.Size = New System.Drawing.Size(283, 34)
        Me.txtAddress.TabIndex = 11
        '
        'Label25
        '
        Me.Label25.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(268, 373)
        Me.Label25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(69, 17)
        Me.Label25.TabIndex = 60
        Me.Label25.Text = "Credit Days"
        '
        'txtCreditDays
        '
        Me.txtCreditDays.BackColor = System.Drawing.Color.Lavender
        Me.txtCreditDays.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCreditDays.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCreditDays.Location = New System.Drawing.Point(382, 374)
        Me.txtCreditDays.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtCreditDays.MaxLength = 5
        Me.txtCreditDays.Name = "txtCreditDays"
        Me.txtCreditDays.Size = New System.Drawing.Size(41, 13)
        Me.txtCreditDays.TabIndex = 24
        Me.txtCreditDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chkIsAccountCust
        '
        Me.chkIsAccountCust.BackColor = System.Drawing.Color.Gainsboro
        Me.chkIsAccountCust.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkIsAccountCust.Location = New System.Drawing.Point(190, 16)
        Me.chkIsAccountCust.Name = "chkIsAccountCust"
        Me.chkIsAccountCust.Size = New System.Drawing.Size(120, 17)
        Me.chkIsAccountCust.TabIndex = 1
        Me.chkIsAccountCust.TabStop = False
        Me.chkIsAccountCust.Text = "Is Account Cust."
        Me.chkIsAccountCust.UseVisualStyleBackColor = False
        '
        'txtIsAccountCust
        '
        Me.txtIsAccountCust.BackColor = System.Drawing.Color.Gainsboro
        Me.txtIsAccountCust.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtIsAccountCust.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIsAccountCust.Location = New System.Drawing.Point(313, 18)
        Me.txtIsAccountCust.Name = "txtIsAccountCust"
        Me.txtIsAccountCust.ReadOnly = True
        Me.txtIsAccountCust.Size = New System.Drawing.Size(19, 13)
        Me.txtIsAccountCust.TabIndex = 2
        Me.txtIsAccountCust.TabStop = False
        '
        'labRequiredFields
        '
        Me.labRequiredFields.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labRequiredFields.ForeColor = System.Drawing.Color.DarkMagenta
        Me.labRequiredFields.Location = New System.Drawing.Point(16, 463)
        Me.labRequiredFields.Name = "labRequiredFields"
        Me.labRequiredFields.Size = New System.Drawing.Size(441, 30)
        Me.labRequiredFields.TabIndex = 54
        Me.labRequiredFields.Text = "labRequiredFields"
        '
        'txtInactive
        '
        Me.txtInactive.BackColor = System.Drawing.Color.Gainsboro
        Me.txtInactive.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtInactive.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtInactive.Location = New System.Drawing.Point(262, 42)
        Me.txtInactive.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtInactive.Name = "txtInactive"
        Me.txtInactive.ReadOnly = True
        Me.txtInactive.Size = New System.Drawing.Size(25, 13)
        Me.txtInactive.TabIndex = 5
        Me.txtInactive.TabStop = False
        '
        'btnCustomerCancel
        '
        Me.btnCustomerCancel.BackColor = System.Drawing.Color.Thistle
        Me.btnCustomerCancel.CausesValidation = False
        Me.btnCustomerCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCustomerCancel.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCustomerCancel.Location = New System.Drawing.Point(298, 420)
        Me.btnCustomerCancel.Name = "btnCustomerCancel"
        Me.btnCustomerCancel.Size = New System.Drawing.Size(67, 32)
        Me.btnCustomerCancel.TabIndex = 26
        Me.btnCustomerCancel.Text = "Cancel"
        Me.btnCustomerCancel.UseVisualStyleBackColor = False
        '
        'btnCustomerCommit
        '
        Me.btnCustomerCommit.BackColor = System.Drawing.Color.LawnGreen
        Me.btnCustomerCommit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCustomerCommit.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCustomerCommit.Location = New System.Drawing.Point(390, 420)
        Me.btnCustomerCommit.Name = "btnCustomerCommit"
        Me.btnCustomerCommit.Size = New System.Drawing.Size(67, 32)
        Me.btnCustomerCommit.TabIndex = 27
        Me.btnCustomerCommit.Text = "Commit"
        Me.btnCustomerCommit.UseVisualStyleBackColor = False
        '
        'txtCountry
        '
        Me.txtCountry.BackColor = System.Drawing.Color.Lavender
        Me.txtCountry.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCountry.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCountry.Location = New System.Drawing.Point(78, 258)
        Me.txtCountry.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtCountry.MaxLength = 20
        Me.txtCountry.Name = "txtCountry"
        Me.txtCountry.Size = New System.Drawing.Size(167, 13)
        Me.txtCountry.TabIndex = 16
        Me.txtCountry.Text = "txtCountry"
        '
        'txtSuburb
        '
        Me.txtSuburb.BackColor = System.Drawing.Color.Lavender
        Me.txtSuburb.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSuburb.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSuburb.Location = New System.Drawing.Point(78, 211)
        Me.txtSuburb.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtSuburb.MaxLength = 40
        Me.txtSuburb.Name = "txtSuburb"
        Me.txtSuburb.Size = New System.Drawing.Size(167, 13)
        Me.txtSuburb.TabIndex = 12
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(13, 398)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(61, 13)
        Me.Label15.TabIndex = 44
        Me.Label15.Text = "Comments:"
        '
        'txtComments
        '
        Me.txtComments.BackColor = System.Drawing.Color.Lavender
        Me.txtComments.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtComments.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtComments.Location = New System.Drawing.Point(17, 412)
        Me.txtComments.Multiline = True
        Me.txtComments.Name = "txtComments"
        Me.txtComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtComments.Size = New System.Drawing.Size(242, 44)
        Me.txtComments.TabIndex = 25
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(269, 347)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(69, 17)
        Me.Label10.TabIndex = 32
        Me.Label10.Text = "Credit Limit"
        '
        'txtCreditLimit
        '
        Me.txtCreditLimit.BackColor = System.Drawing.Color.Lavender
        Me.txtCreditLimit.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCreditLimit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCreditLimit.Location = New System.Drawing.Point(334, 347)
        Me.txtCreditLimit.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtCreditLimit.MaxLength = 9
        Me.txtCreditLimit.Name = "txtCreditLimit"
        Me.txtCreditLimit.Size = New System.Drawing.Size(89, 13)
        Me.txtCreditLimit.TabIndex = 23
        Me.txtCreditLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(14, 258)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(65, 17)
        Me.Label9.TabIndex = 30
        Me.Label9.Text = "Country"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(14, 210)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(60, 17)
        Me.Label8.TabIndex = 27
        Me.Label8.Text = "Suburb"
        '
        'chkInactive
        '
        Me.chkInactive.Location = New System.Drawing.Point(190, 39)
        Me.chkInactive.Name = "chkInactive"
        Me.chkInactive.Size = New System.Drawing.Size(66, 19)
        Me.chkInactive.TabIndex = 4
        Me.chkInactive.Text = "Inactive"
        Me.chkInactive.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(15, 104)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 17)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "First Name"
        '
        'txtFirstName
        '
        Me.txtFirstName.BackColor = System.Drawing.Color.Lavender
        Me.txtFirstName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtFirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFirstName.Location = New System.Drawing.Point(84, 105)
        Me.txtFirstName.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtFirstName.MaxLength = 50
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(166, 13)
        Me.txtFirstName.TabIndex = 8
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(14, 85)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(69, 17)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "Last Name"
        '
        'txtLastName
        '
        Me.txtLastName.BackColor = System.Drawing.Color.Lavender
        Me.txtLastName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtLastName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLastName.Location = New System.Drawing.Point(84, 86)
        Me.txtLastName.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtLastName.MaxLength = 50
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(166, 13)
        Me.txtLastName.TabIndex = 7
        '
        'txtCustomer_id
        '
        Me.txtCustomer_id.BackColor = System.Drawing.Color.LightGray
        Me.txtCustomer_id.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCustomer_id.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustomer_id.Location = New System.Drawing.Point(78, 42)
        Me.txtCustomer_id.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtCustomer_id.Name = "txtCustomer_id"
        Me.txtCustomer_id.ReadOnly = True
        Me.txtCustomer_id.Size = New System.Drawing.Size(53, 13)
        Me.txtCustomer_id.TabIndex = 3
        Me.txtCustomer_id.TabStop = False
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Gray
        Me.Label4.Location = New System.Drawing.Point(14, 41)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 17)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "Cust._id"
        '
        'txtCompanyName
        '
        Me.txtCompanyName.BackColor = System.Drawing.Color.Lavender
        Me.txtCompanyName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCompanyName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCompanyName.Location = New System.Drawing.Point(78, 154)
        Me.txtCompanyName.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtCompanyName.MaxLength = 50
        Me.txtCompanyName.Name = "txtCompanyName"
        Me.txtCompanyName.Size = New System.Drawing.Size(262, 13)
        Me.txtCompanyName.TabIndex = 10
        '
        'BarcodeLabel
        '
        Me.BarcodeLabel.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BarcodeLabel.ForeColor = System.Drawing.Color.Gray
        Me.BarcodeLabel.Location = New System.Drawing.Point(14, 16)
        Me.BarcodeLabel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.BarcodeLabel.Name = "BarcodeLabel"
        Me.BarcodeLabel.Size = New System.Drawing.Size(54, 17)
        Me.BarcodeLabel.TabIndex = 9
        Me.BarcodeLabel.Text = "Barcode"
        '
        'DescriptionLabel
        '
        Me.DescriptionLabel.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DescriptionLabel.Location = New System.Drawing.Point(13, 153)
        Me.DescriptionLabel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DescriptionLabel.Name = "DescriptionLabel"
        Me.DescriptionLabel.Size = New System.Drawing.Size(61, 17)
        Me.DescriptionLabel.TabIndex = 13
        Me.DescriptionLabel.Text = "Company"
        '
        'txtBarcode
        '
        Me.txtBarcode.BackColor = System.Drawing.Color.LightGray
        Me.txtBarcode.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtBarcode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBarcode.Location = New System.Drawing.Point(78, 18)
        Me.txtBarcode.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtBarcode.MaxLength = 15
        Me.txtBarcode.Name = "txtBarcode"
        Me.txtBarcode.ReadOnly = True
        Me.txtBarcode.Size = New System.Drawing.Size(53, 13)
        Me.txtBarcode.TabIndex = 0
        Me.txtBarcode.TabStop = False
        '
        'btnNew
        '
        Me.btnNew.BackColor = System.Drawing.Color.LavenderBlush
        Me.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNew.Location = New System.Drawing.Point(195, 9)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.Size = New System.Drawing.Size(67, 23)
        Me.btnNew.TabIndex = 1
        Me.btnNew.Text = "New"
        Me.ToolTip1.SetToolTip(Me.btnNew, "Create new customer record.")
        Me.btnNew.UseVisualStyleBackColor = False
        '
        'btnEdit
        '
        Me.btnEdit.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnEdit.Location = New System.Drawing.Point(18, 10)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(67, 23)
        Me.btnEdit.TabIndex = 0
        Me.btnEdit.Text = "Edit"
        Me.ToolTip1.SetToolTip(Me.btnEdit, "Make changes to this Customer..")
        Me.btnEdit.UseVisualStyleBackColor = False
        '
        'TabPageInvoices
        '
        Me.TabPageInvoices.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPageInvoices.Controls.Add(Me.labInvoiceReversed)
        Me.TabPageInvoices.Controls.Add(Me.chkOutstanding)
        Me.TabPageInvoices.Controls.Add(Me.btnShowInvoice)
        Me.TabPageInvoices.Controls.Add(Me.dgvInvoices)
        Me.TabPageInvoices.Controls.Add(Me.Label17)
        Me.TabPageInvoices.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPageInvoices.Location = New System.Drawing.Point(4, 25)
        Me.TabPageInvoices.Name = "TabPageInvoices"
        Me.TabPageInvoices.Size = New System.Drawing.Size(505, 537)
        Me.TabPageInvoices.TabIndex = 2
        Me.TabPageInvoices.Text = "Invoices"
        Me.TabPageInvoices.UseVisualStyleBackColor = True
        '
        'labInvoiceReversed
        '
        Me.labInvoiceReversed.Location = New System.Drawing.Point(23, 515)
        Me.labInvoiceReversed.Name = "labInvoiceReversed"
        Me.labInvoiceReversed.Size = New System.Drawing.Size(112, 13)
        Me.labInvoiceReversed.TabIndex = 15
        Me.labInvoiceReversed.Text = "* Invoice Reversed."
        '
        'chkOutstanding
        '
        Me.chkOutstanding.BackColor = System.Drawing.Color.White
        Me.chkOutstanding.Location = New System.Drawing.Point(282, 10)
        Me.chkOutstanding.Name = "chkOutstanding"
        Me.chkOutstanding.Size = New System.Drawing.Size(91, 36)
        Me.chkOutstanding.TabIndex = 13
        Me.chkOutstanding.Text = "Outstanding Inv. Only"
        Me.chkOutstanding.UseVisualStyleBackColor = False
        '
        'btnShowInvoice
        '
        Me.btnShowInvoice.BackColor = System.Drawing.Color.Snow
        Me.btnShowInvoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowInvoice.Location = New System.Drawing.Point(400, 10)
        Me.btnShowInvoice.Name = "btnShowInvoice"
        Me.btnShowInvoice.Size = New System.Drawing.Size(68, 36)
        Me.btnShowInvoice.TabIndex = 12
        Me.btnShowInvoice.Text = "Show this Invoice"
        Me.btnShowInvoice.UseVisualStyleBackColor = False
        '
        'dgvInvoices
        '
        Me.dgvInvoices.AllowUserToAddRows = False
        Me.dgvInvoices.AllowUserToDeleteRows = False
        Me.dgvInvoices.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvInvoices.BackgroundColor = System.Drawing.Color.WhiteSmoke
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.Gainsboro
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvInvoices.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgvInvoices.ColumnHeadersHeight = 36
        Me.dgvInvoices.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.invoice_no, Me.invoices_invoice_date, Me.tranType, Me.isOnAccount, Me.inv_total, Me.prev_paid, Me.outstanding})
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvInvoices.DefaultCellStyle = DataGridViewCellStyle11
        Me.dgvInvoices.GridColor = System.Drawing.SystemColors.ControlLight
        Me.dgvInvoices.Location = New System.Drawing.Point(6, 52)
        Me.dgvInvoices.Name = "dgvInvoices"
        Me.dgvInvoices.RowHeadersWidth = 27
        DataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        DataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvInvoices.RowsDefaultCellStyle = DataGridViewCellStyle12
        Me.dgvInvoices.RowTemplate.Height = 17
        Me.dgvInvoices.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvInvoices.Size = New System.Drawing.Size(477, 454)
        Me.dgvInvoices.TabIndex = 11
        '
        'invoice_no
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight
        Me.invoice_no.DefaultCellStyle = DataGridViewCellStyle4
        Me.invoice_no.FillWeight = 40.0!
        Me.invoice_no.HeaderText = "Inv.No"
        Me.invoice_no.Name = "invoice_no"
        Me.invoice_no.ReadOnly = True
        '
        'invoices_invoice_date
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft
        Me.invoices_invoice_date.DefaultCellStyle = DataGridViewCellStyle5
        Me.invoices_invoice_date.FillWeight = 70.0!
        Me.invoices_invoice_date.HeaderText = "Invoice Date"
        Me.invoices_invoice_date.Name = "invoices_invoice_date"
        Me.invoices_invoice_date.ReadOnly = True
        '
        'tranType
        '
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft
        Me.tranType.DefaultCellStyle = DataGridViewCellStyle6
        Me.tranType.FillWeight = 70.0!
        Me.tranType.HeaderText = "tranType"
        Me.tranType.Name = "tranType"
        Me.tranType.ReadOnly = True
        '
        'isOnAccount
        '
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        DataGridViewCellStyle7.NullValue = False
        Me.isOnAccount.DefaultCellStyle = DataGridViewCellStyle7
        Me.isOnAccount.FillWeight = 50.0!
        Me.isOnAccount.HeaderText = "OnAcct"
        Me.isOnAccount.Name = "isOnAccount"
        Me.isOnAccount.ReadOnly = True
        '
        'inv_total
        '
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight
        Me.inv_total.DefaultCellStyle = DataGridViewCellStyle8
        Me.inv_total.FillWeight = 60.0!
        Me.inv_total.HeaderText = "Inv.Total"
        Me.inv_total.Name = "inv_total"
        Me.inv_total.ReadOnly = True
        '
        'prev_paid
        '
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Lucida Console", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.prev_paid.DefaultCellStyle = DataGridViewCellStyle9
        Me.prev_paid.FillWeight = 120.0!
        Me.prev_paid.HeaderText = "Prev.Paid"
        Me.prev_paid.Name = "prev_paid"
        Me.prev_paid.ReadOnly = True
        '
        'outstanding
        '
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight
        Me.outstanding.DefaultCellStyle = DataGridViewCellStyle10
        Me.outstanding.FillWeight = 60.0!
        Me.outstanding.HeaderText = "Outstanding"
        Me.outstanding.Name = "outstanding"
        Me.outstanding.ReadOnly = True
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.MistyRose
        Me.Label17.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(17, 20)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(239, 17)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "Customer Invoices and Payments History.. "
        '
        'TabPageItemSales
        '
        Me.TabPageItemSales.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPageItemSales.Controls.Add(Me.dgvSales)
        Me.TabPageItemSales.Controls.Add(Me.Label23)
        Me.TabPageItemSales.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPageItemSales.Location = New System.Drawing.Point(4, 25)
        Me.TabPageItemSales.Name = "TabPageItemSales"
        Me.TabPageItemSales.Size = New System.Drawing.Size(505, 537)
        Me.TabPageItemSales.TabIndex = 3
        Me.TabPageItemSales.Text = "Item Sales"
        Me.TabPageItemSales.UseVisualStyleBackColor = True
        '
        'dgvSales
        '
        Me.dgvSales.AllowUserToAddRows = False
        Me.dgvSales.AllowUserToDeleteRows = False
        Me.dgvSales.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvSales.BackgroundColor = System.Drawing.Color.WhiteSmoke
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvSales.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.dgvSales.ColumnHeadersHeight = 36
        Me.dgvSales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvSales.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.sale_invoice_no, Me.invoice_date, Me.barcode, Me.Description, Me.sale_qty, Me.sale_value})
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvSales.DefaultCellStyle = DataGridViewCellStyle17
        Me.dgvSales.GridColor = System.Drawing.SystemColors.ControlLight
        Me.dgvSales.Location = New System.Drawing.Point(6, 52)
        Me.dgvSales.Name = "dgvSales"
        Me.dgvSales.ReadOnly = True
        Me.dgvSales.RowHeadersWidth = 30
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvSales.RowsDefaultCellStyle = DataGridViewCellStyle18
        Me.dgvSales.RowTemplate.Height = 17
        Me.dgvSales.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvSales.Size = New System.Drawing.Size(462, 456)
        Me.dgvSales.TabIndex = 11
        '
        'sale_invoice_no
        '
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.sale_invoice_no.DefaultCellStyle = DataGridViewCellStyle14
        Me.sale_invoice_no.FillWeight = 40.0!
        Me.sale_invoice_no.HeaderText = "Invoice No"
        Me.sale_invoice_no.Name = "sale_invoice_no"
        Me.sale_invoice_no.ReadOnly = True
        '
        'invoice_date
        '
        Me.invoice_date.FillWeight = 60.0!
        Me.invoice_date.HeaderText = "Date"
        Me.invoice_date.Name = "invoice_date"
        Me.invoice_date.ReadOnly = True
        '
        'barcode
        '
        Me.barcode.FillWeight = 70.0!
        Me.barcode.HeaderText = "Barcode"
        Me.barcode.Name = "barcode"
        Me.barcode.ReadOnly = True
        '
        'Description
        '
        Me.Description.HeaderText = "Description"
        Me.Description.Name = "Description"
        Me.Description.ReadOnly = True
        '
        'sale_qty
        '
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.sale_qty.DefaultCellStyle = DataGridViewCellStyle15
        Me.sale_qty.FillWeight = 40.0!
        Me.sale_qty.HeaderText = "Qty"
        Me.sale_qty.Name = "sale_qty"
        Me.sale_qty.ReadOnly = True
        '
        'sale_value
        '
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.sale_value.DefaultCellStyle = DataGridViewCellStyle16
        Me.sale_value.FillWeight = 70.0!
        Me.sale_value.HeaderText = "Value"
        Me.sale_value.Name = "sale_value"
        Me.sale_value.ReadOnly = True
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.Lavender
        Me.Label23.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(17, 20)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(133, 25)
        Me.Label23.TabIndex = 7
        Me.Label23.Text = "Item Sales History-"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabPageAccountPayments
        '
        Me.TabPageAccountPayments.Controls.Add(Me.btnShowPayment)
        Me.TabPageAccountPayments.Controls.Add(Me.dgvPayments)
        Me.TabPageAccountPayments.Controls.Add(Me.Label1)
        Me.TabPageAccountPayments.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPageAccountPayments.Location = New System.Drawing.Point(4, 25)
        Me.TabPageAccountPayments.Name = "TabPageAccountPayments"
        Me.TabPageAccountPayments.Size = New System.Drawing.Size(505, 537)
        Me.TabPageAccountPayments.TabIndex = 4
        Me.TabPageAccountPayments.Text = "Payments"
        Me.TabPageAccountPayments.UseVisualStyleBackColor = True
        '
        'btnShowPayment
        '
        Me.btnShowPayment.BackColor = System.Drawing.Color.Snow
        Me.btnShowPayment.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnShowPayment.Location = New System.Drawing.Point(365, 12)
        Me.btnShowPayment.Name = "btnShowPayment"
        Me.btnShowPayment.Size = New System.Drawing.Size(68, 36)
        Me.btnShowPayment.TabIndex = 13
        Me.btnShowPayment.Text = "Show this Payment"
        Me.btnShowPayment.UseVisualStyleBackColor = False
        '
        'dgvPayments
        '
        Me.dgvPayments.AllowUserToAddRows = False
        Me.dgvPayments.AllowUserToDeleteRows = False
        Me.dgvPayments.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvPayments.BackgroundColor = System.Drawing.Color.WhiteSmoke
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle19.BackColor = System.Drawing.Color.Gainsboro
        DataGridViewCellStyle19.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvPayments.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle19
        Me.dgvPayments.ColumnHeadersHeight = 36
        Me.dgvPayments.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.payment_id, Me.payment_date, Me.amount_received, Me.credit_note_contribution, Me.invoice_nos, Me.tran_type, Me.docket_name})
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle23.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvPayments.DefaultCellStyle = DataGridViewCellStyle23
        Me.dgvPayments.GridColor = System.Drawing.SystemColors.ControlLight
        Me.dgvPayments.Location = New System.Drawing.Point(6, 52)
        Me.dgvPayments.Name = "dgvPayments"
        Me.dgvPayments.RowHeadersWidth = 27
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        DataGridViewCellStyle24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle24.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvPayments.RowsDefaultCellStyle = DataGridViewCellStyle24
        Me.dgvPayments.RowTemplate.Height = 17
        Me.dgvPayments.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvPayments.Size = New System.Drawing.Size(480, 462)
        Me.dgvPayments.TabIndex = 12
        '
        'payment_id
        '
        Me.payment_id.FillWeight = 40.0!
        Me.payment_id.HeaderText = "ID"
        Me.payment_id.Name = "payment_id"
        '
        'payment_date
        '
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.payment_date.DefaultCellStyle = DataGridViewCellStyle20
        Me.payment_date.FillWeight = 80.0!
        Me.payment_date.HeaderText = "Date"
        Me.payment_date.Name = "payment_date"
        Me.payment_date.ReadOnly = True
        '
        'amount_received
        '
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.amount_received.DefaultCellStyle = DataGridViewCellStyle21
        Me.amount_received.FillWeight = 80.0!
        Me.amount_received.HeaderText = "New Payment Rcvd"
        Me.amount_received.Name = "amount_received"
        Me.amount_received.ReadOnly = True
        '
        'credit_note_contribution
        '
        Me.credit_note_contribution.HeaderText = "Credit Note Contrib."
        Me.credit_note_contribution.Name = "credit_note_contribution"
        '
        'invoice_nos
        '
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.invoice_nos.DefaultCellStyle = DataGridViewCellStyle22
        Me.invoice_nos.FillWeight = 70.0!
        Me.invoice_nos.HeaderText = "Inv. Nos"
        Me.invoice_nos.Name = "invoice_nos"
        Me.invoice_nos.ReadOnly = True
        '
        'tran_type
        '
        Me.tran_type.FillWeight = 70.0!
        Me.tran_type.HeaderText = "trans.Type"
        Me.tran_type.Name = "tran_type"
        Me.tran_type.ReadOnly = True
        '
        'docket_name
        '
        Me.docket_name.FillWeight = 60.0!
        Me.docket_name.HeaderText = "Staff"
        Me.docket_name.Name = "docket_name"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.AliceBlue
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(17, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(182, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Account Payments History.. "
        '
        'TabPageQuotes
        '
        Me.TabPageQuotes.Controls.Add(Me.Label32)
        Me.TabPageQuotes.Controls.Add(Me.Label30)
        Me.TabPageQuotes.Controls.Add(Me.dgvQuotes)
        Me.TabPageQuotes.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPageQuotes.Location = New System.Drawing.Point(4, 25)
        Me.TabPageQuotes.Name = "TabPageQuotes"
        Me.TabPageQuotes.Size = New System.Drawing.Size(505, 537)
        Me.TabPageQuotes.TabIndex = 5
        Me.TabPageQuotes.Text = "Quotes"
        Me.TabPageQuotes.UseVisualStyleBackColor = True
        '
        'Label32
        '
        Me.Label32.Location = New System.Drawing.Point(297, 15)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(156, 34)
        Me.Label32.TabIndex = 14
        Me.Label32.Text = "Double-click on Grid row to show selected Quote"
        '
        'Label30
        '
        Me.Label30.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Label30.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(31, 8)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(98, 39)
        Me.Label30.TabIndex = 13
        Me.Label30.Text = "Quotes for this Customer"
        '
        'dgvQuotes
        '
        Me.dgvQuotes.AllowUserToAddRows = False
        Me.dgvQuotes.AllowUserToDeleteRows = False
        Me.dgvQuotes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvQuotes.BackgroundColor = System.Drawing.Color.WhiteSmoke
        DataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle25.BackColor = System.Drawing.Color.Gainsboro
        DataGridViewCellStyle25.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvQuotes.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle25
        Me.dgvQuotes.ColumnHeadersHeight = 36
        Me.dgvQuotes.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.salesorder_date, Me.salesorder_id, Me.total_inc, Me.staff_docket_name})
        DataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle29.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvQuotes.DefaultCellStyle = DataGridViewCellStyle29
        Me.dgvQuotes.GridColor = System.Drawing.SystemColors.ControlLight
        Me.dgvQuotes.Location = New System.Drawing.Point(6, 52)
        Me.dgvQuotes.Name = "dgvQuotes"
        Me.dgvQuotes.RowHeadersWidth = 27
        DataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle30.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        DataGridViewCellStyle30.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle30.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle30.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle30.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvQuotes.RowsDefaultCellStyle = DataGridViewCellStyle30
        Me.dgvQuotes.RowTemplate.Height = 17
        Me.dgvQuotes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvQuotes.Size = New System.Drawing.Size(477, 462)
        Me.dgvQuotes.TabIndex = 12
        '
        'salesorder_date
        '
        DataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.salesorder_date.DefaultCellStyle = DataGridViewCellStyle26
        Me.salesorder_date.FillWeight = 70.0!
        Me.salesorder_date.HeaderText = "Quote Date"
        Me.salesorder_date.Name = "salesorder_date"
        Me.salesorder_date.ReadOnly = True
        '
        'salesorder_id
        '
        DataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.salesorder_id.DefaultCellStyle = DataGridViewCellStyle27
        Me.salesorder_id.FillWeight = 40.0!
        Me.salesorder_id.HeaderText = "Quote. No"
        Me.salesorder_id.Name = "salesorder_id"
        Me.salesorder_id.ReadOnly = True
        '
        'total_inc
        '
        DataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.total_inc.DefaultCellStyle = DataGridViewCellStyle28
        Me.total_inc.FillWeight = 60.0!
        Me.total_inc.HeaderText = "Inv.Total"
        Me.total_inc.Name = "total_inc"
        Me.total_inc.ReadOnly = True
        '
        'staff_docket_name
        '
        Me.staff_docket_name.HeaderText = "Staff"
        Me.staff_docket_name.Name = "staff_docket_name"
        '
        'TabPageJobs
        '
        Me.TabPageJobs.Controls.Add(Me.Label33)
        Me.TabPageJobs.Controls.Add(Me.btnOnSiteJob)
        Me.TabPageJobs.Controls.Add(Me.btnAcceptJob)
        Me.TabPageJobs.Controls.Add(Me.dgvJobs)
        Me.TabPageJobs.Controls.Add(Me.Label31)
        Me.TabPageJobs.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPageJobs.Location = New System.Drawing.Point(4, 25)
        Me.TabPageJobs.Name = "TabPageJobs"
        Me.TabPageJobs.Size = New System.Drawing.Size(505, 537)
        Me.TabPageJobs.TabIndex = 6
        Me.TabPageJobs.Text = "Active Jobs"
        Me.TabPageJobs.UseVisualStyleBackColor = True
        '
        'Label33
        '
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(128, 19)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(105, 34)
        Me.Label33.TabIndex = 18
        Me.Label33.Text = "Right-Click on Job for Check-in, Amend"
        '
        'btnOnSiteJob
        '
        Me.btnOnSiteJob.BackColor = System.Drawing.Color.Goldenrod
        Me.btnOnSiteJob.Location = New System.Drawing.Point(374, 20)
        Me.btnOnSiteJob.Name = "btnOnSiteJob"
        Me.btnOnSiteJob.Size = New System.Drawing.Size(108, 32)
        Me.btnOnSiteJob.TabIndex = 17
        Me.btnOnSiteJob.Text = "New OnSite Job"
        Me.ToolTip1.SetToolTip(Me.btnOnSiteJob, "Create and schedule a new OnSite Job Booking")
        Me.btnOnSiteJob.UseVisualStyleBackColor = False
        '
        'btnAcceptJob
        '
        Me.btnAcceptJob.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnAcceptJob.Location = New System.Drawing.Point(250, 20)
        Me.btnAcceptJob.Name = "btnAcceptJob"
        Me.btnAcceptJob.Size = New System.Drawing.Size(108, 32)
        Me.btnAcceptJob.TabIndex = 16
        Me.btnAcceptJob.Text = "New Workshop Job"
        Me.ToolTip1.SetToolTip(Me.btnAcceptJob, "Create new Workshop Job-  Accept now or Book-in.")
        Me.btnAcceptJob.UseVisualStyleBackColor = False
        '
        'dgvJobs
        '
        Me.dgvJobs.AllowUserToAddRows = False
        Me.dgvJobs.AllowUserToDeleteRows = False
        Me.dgvJobs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvJobs.BackgroundColor = System.Drawing.Color.WhiteSmoke
        DataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle31.BackColor = System.Drawing.Color.Gainsboro
        DataGridViewCellStyle31.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle31.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle31.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvJobs.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle31
        Me.dgvJobs.ColumnHeadersHeight = 36
        Me.dgvJobs.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.job_id, Me.jobstatus, Me.dateupdated, Me.NominatedTech})
        DataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle34.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvJobs.DefaultCellStyle = DataGridViewCellStyle34
        Me.dgvJobs.GridColor = System.Drawing.SystemColors.ControlLight
        Me.dgvJobs.Location = New System.Drawing.Point(5, 58)
        Me.dgvJobs.Name = "dgvJobs"
        Me.dgvJobs.RowHeadersWidth = 27
        DataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle35.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        DataGridViewCellStyle35.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle35.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle35.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle35.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvJobs.RowsDefaultCellStyle = DataGridViewCellStyle35
        Me.dgvJobs.RowTemplate.Height = 17
        Me.dgvJobs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvJobs.Size = New System.Drawing.Size(477, 462)
        Me.dgvJobs.TabIndex = 15
        '
        'job_id
        '
        DataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.job_id.DefaultCellStyle = DataGridViewCellStyle32
        Me.job_id.FillWeight = 40.0!
        Me.job_id.HeaderText = "Job No"
        Me.job_id.Name = "job_id"
        Me.job_id.ReadOnly = True
        '
        'jobstatus
        '
        Me.jobstatus.FillWeight = 90.0!
        Me.jobstatus.HeaderText = "JobStatus"
        Me.jobstatus.Name = "jobstatus"
        '
        'dateupdated
        '
        DataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.dateupdated.DefaultCellStyle = DataGridViewCellStyle33
        Me.dateupdated.HeaderText = "Date Updated"
        Me.dateupdated.Name = "dateupdated"
        Me.dateupdated.ReadOnly = True
        '
        'NominatedTech
        '
        Me.NominatedTech.HeaderText = "Tech"
        Me.NominatedTech.Name = "NominatedTech"
        '
        'Label31
        '
        Me.Label31.BackColor = System.Drawing.Color.Lavender
        Me.Label31.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(17, 15)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(105, 35)
        Me.Label31.TabIndex = 14
        Me.Label31.Text = "Active Jobs for this Customer"
        '
        'timerGrid
        '
        '
        'timerFind
        '
        '
        'ucChildCustomer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(218, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Controls.Add(Me.grpBoxCustomer)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "ucChildCustomer"
        Me.Size = New System.Drawing.Size(1011, 634)
        Me.panelBanner.ResumeLayout(False)
        Me.grpBoxCustomer.ResumeLayout(False)
        Me.panelCustHdr.ResumeLayout(False)
        Me.FrameBrowse.ResumeLayout(False)
        Me.FrameBrowse.PerformLayout()
        CType(Me.dgvCustomerList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControlCustomer.ResumeLayout(False)
        Me.TabPageCustomerDetail.ResumeLayout(False)
        Me.panelCustomerDetail.ResumeLayout(False)
        Me.panelCustomerDetail.PerformLayout()
        Me.TabPageInvoices.ResumeLayout(False)
        CType(Me.dgvInvoices, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPageItemSales.ResumeLayout(False)
        CType(Me.dgvSales, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPageAccountPayments.ResumeLayout(False)
        CType(Me.dgvPayments, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPageQuotes.ResumeLayout(False)
        CType(Me.dgvQuotes, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPageJobs.ResumeLayout(False)
        CType(Me.dgvJobs, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelBanner As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents grpBoxCustomer As System.Windows.Forms.GroupBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents labItemHeader As System.Windows.Forms.Label
    Public WithEvents FrameBrowse As System.Windows.Forms.GroupBox
    Public WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Public WithEvents cmdClearCustomerSearch As System.Windows.Forms.Button
    Public WithEvents cmdCustomerSearch As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents txtCustomerSearch As System.Windows.Forms.TextBox
    Friend WithEvents dgvCustomerList As System.Windows.Forms.DataGridView
    Public WithEvents txtFind As System.Windows.Forms.TextBox
    Public WithEvents labRecCount As System.Windows.Forms.Label
    Public WithEvents LabFind As System.Windows.Forms.Label
    Friend WithEvents TabControlCustomer As System.Windows.Forms.TabControl
    Friend WithEvents TabPageCustomerDetail As System.Windows.Forms.TabPage
    Friend WithEvents panelCustomerDetail As System.Windows.Forms.Panel
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtCreditDays As System.Windows.Forms.TextBox
    Friend WithEvents chkIsAccountCust As System.Windows.Forms.CheckBox
    Friend WithEvents txtIsAccountCust As System.Windows.Forms.TextBox
    Friend WithEvents labRequiredFields As System.Windows.Forms.Label
    Friend WithEvents txtInactive As System.Windows.Forms.TextBox
    Friend WithEvents btnCustomerCancel As System.Windows.Forms.Button
    Friend WithEvents btnCustomerCommit As System.Windows.Forms.Button
    Friend WithEvents txtCountry As System.Windows.Forms.TextBox
    Friend WithEvents txtSuburb As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtComments As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtCreditLimit As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents chkInactive As System.Windows.Forms.CheckBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtCustomer_id As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtCompanyName As System.Windows.Forms.TextBox
    Friend WithEvents BarcodeLabel As System.Windows.Forms.Label
    Friend WithEvents DescriptionLabel As System.Windows.Forms.Label
    Friend WithEvents txtBarcode As System.Windows.Forms.TextBox
    Friend WithEvents btnNew As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents TabPageInvoices As System.Windows.Forms.TabPage
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents TabPageItemSales As System.Windows.Forms.TabPage
    Friend WithEvents dgvSales As System.Windows.Forms.DataGridView
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtTitle As System.Windows.Forms.TextBox
    Public WithEvents txtPostCode As System.Windows.Forms.TextBox
    Public WithEvents cboState As System.Windows.Forms.ComboBox
    Public WithEvents Label13 As System.Windows.Forms.Label
    Public WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtState As System.Windows.Forms.TextBox
    Friend WithEvents txtABN As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txtPhone As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txtFax As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents txtMobile As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents sale_invoice_no As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents invoice_date As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents barcode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Description As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents sale_qty As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents sale_value As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dgvInvoices As System.Windows.Forms.DataGridView
    Friend WithEvents btnShowInvoice As System.Windows.Forms.Button
    Friend WithEvents chkOutstanding As System.Windows.Forms.CheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents panelCustHdr As System.Windows.Forms.Panel
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents txtPricingGrade As System.Windows.Forms.TextBox
    Public WithEvents cboPricingGrade As System.Windows.Forms.ComboBox
    Public WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents labEditing As System.Windows.Forms.Label
    Friend WithEvents labAddingNew As System.Windows.Forms.Label
    Friend WithEvents TabPageAccountPayments As System.Windows.Forms.TabPage
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TabPageQuotes As System.Windows.Forms.TabPage
    Friend WithEvents dgvPayments As System.Windows.Forms.DataGridView
    Friend WithEvents btnShowPayment As System.Windows.Forms.Button
    Friend WithEvents payment_id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents payment_date As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents amount_received As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents credit_note_contribution As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents invoice_nos As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents tran_type As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents docket_name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dgvQuotes As System.Windows.Forms.DataGridView
    Friend WithEvents salesorder_date As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents salesorder_id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents total_inc As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents staff_docket_name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TabPageJobs As System.Windows.Forms.TabPage
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents dgvJobs As System.Windows.Forms.DataGridView
    Friend WithEvents job_id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents jobstatus As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dateupdated As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NominatedTech As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents labGettingData As System.Windows.Forms.Label
    Friend WithEvents timerGrid As System.Windows.Forms.Timer
    Friend WithEvents timerFind As System.Windows.Forms.Timer
    Friend WithEvents btnOnSiteJob As System.Windows.Forms.Button
    Friend WithEvents btnAcceptJob As System.Windows.Forms.Button
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents btnTagRef As System.Windows.Forms.Button
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents labCustTags As System.Windows.Forms.Label
    Friend WithEvents btnTagEdit As System.Windows.Forms.Button
    Friend WithEvents labInvoiceReversed As System.Windows.Forms.Label
    Friend WithEvents invoice_no As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents invoices_invoice_date As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents tranType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents isOnAccount As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents inv_total As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents prev_paid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents outstanding As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents chkIncludeInactiveCust As CheckBox
End Class
