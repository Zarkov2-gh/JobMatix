﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("JobMatixRAs62")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("grh")>
<Assembly: AssemblyProduct("JobMatixRAs62")>
<Assembly: AssemblyCopyright("Copyright © 2018..2021 grhaas@outlook.com")>
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("69a9580d-da61-4164-9e41-08560d92c7f6")>

'==
'== Updated 3411.0103  03Jan2018=  for Email Agent etc..
'==
'== Updated 3411.0108  08Jan2018=  Project Target CPU changed to x86...
'==
'== Updated 3411.0109  09Jan2018=  Fix DataDir logging path...
'==
''== RAS34-EXE Cloned from POS340ex..
'==   3411.0109  18Jan2018= 
'==   3411.112  22Jan2018=  Updates plus Icon
'==
'==   3411.0129  29Jan2018=  Tidy up plus Tooltip.
'==
'== = = = = = = = = = = =  = = = = = = = = = = = =\
'==
'==  New version to go with JobMatix 35..
'==
'==   3501.0808  08-August-2018= 
'==   --  Include the Combined Sql-FilesSubs module...
'==
'==   3501.0812  12-August-2018= 
'==   --  Update version no....
'==   3501.0814  14-August-2018= 
'==   --  Update Main form resizing.....
'==
'==   3501.1106  06-Nov-2018= 
'==   --  Import Latest clBrowse34.vb and frmBrowse33 FROM JobTracking......
'==   --  3510.1107- Import AGAIN Latest clBrowse34.vb FROM JobTracking......
'==   --  3510.1108- Import AGAIN Latest clBrowse34.vb FROM JobTracking......
'==
'==   4219.1130  24-Nov-2019= 
'==   --  Import NEW dll JMxRetalHost FROM JobTracking......
'==   --  Drop "modAllFileAndSqlSubs", as it's now in "JMxRetalHost.dll"..
'==   --  DROP module "modCreateJobs3" and Attachments Form and class 
'==                   They've gone into JMxRetailHost.dll so EVERyONE  (eg. RAs) can use it.
'==   
'==
'= = = = = = = = == = = = = = = == = = = = = = = = = = = = = = = = = == 

'= = = =  = = = = = = = = = = = = = = = = = = = = = = == = = = = = = = = = = == = = = == = = = = = = = = = = = = = 
'==
'==   Target-New-Build-6201 --  (26-June-2021)
'==   Target-New-Build-6201 --  (26-June-2021)
'==   Target-New-Build-6201 --  (26-June-2021)
'==
'==
'==  For JobMatix62Main- OPEN SOURCE version...
'==  For JobMatix62Main- OPEN SOURCE version...
'==  For JobMatix62Main- OPEN SOURCE version...
'==
'= = = =  = = = = = = = = = = = = = = = = = = = = = = == = = = = = = = = = = == = = = == = = = = = = = = = = = = = 


' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("6.2.6201.0718")>
'= <Assembly: AssemblyFileVersion("1.0.0.0")> 
'= = = = = = = = = = = == = = = = == = = = = = = = = =
