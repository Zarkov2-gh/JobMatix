﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("JMxKeyGen420_OS")>
<Assembly: AssemblyDescription("Dummy Licence Key Stuff")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("JMxKeyGen420_OS")>
<Assembly: AssemblyCopyright("Copyright ©  2021")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("b564435c-0aa7-428b-9183-57ef88680973")>

'== Target-New-Build-6201 --  (18-July-2021) for Open Source..
'== Target-New-Build-6201 --  (18-July-2021) for Open Source..

'-- DLL JMxKeyGen420_OS 
'==   This is the FREE licence compute routine for the Open Source JobMatix..
'-- DLL JMxKeyGen420_OS 
'==   This is the FREE licence compute routine for the Open Source JobMatix..

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("6.2.6201.0718")>
'==<Assembly: AssemblyFileVersion("1.0.0.0")>
